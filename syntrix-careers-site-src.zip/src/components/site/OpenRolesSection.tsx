import { Link } from "@tanstack/react-router";
import { Eyebrow, Section, SectionHeading } from "./primitives";
import { disclaimer, featuredJobs, featuredJobsNote } from "@/lib/site-content";

export function OpenRolesSection({
  id = "jobs",
  showPageIntro = false,
}: {
  id?: string;
  showPageIntro?: boolean;
}) {
  return (
    <Section id={id}>
      <SectionHeading
        as={showPageIntro ? "h1" : "h2"}
        eyebrow="Open roles"
        title={
          showPageIntro ? (
            <>
              Featured USA
              <br />
              Opportunities
            </>
          ) : (
            "Featured USA Opportunities"
          )
        }
        intro="Sample leading USA roles Syntrix places candidates into — software, data, cloud, healthcare IT, business analysis and cybersecurity."
      />
      <p className="mt-6 max-w-3xl rounded-xl border border-border/80 bg-card/40 px-4 py-3 text-sm leading-relaxed text-muted-foreground">
        {featuredJobsNote}
      </p>
      <div className="mt-12 grid gap-px bg-border sm:grid-cols-2 lg:grid-cols-3">
        {featuredJobs.map((job) => (
          <article
            key={job.title}
            className="group flex min-h-56 flex-col justify-between bg-background p-6 transition-colors duration-300 hover:bg-foreground hover:text-background"
          >
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <Eyebrow>{job.type}</Eyebrow>
                <span className="rounded-full border border-border px-2.5 py-0.5 text-[10px] uppercase tracking-wider text-muted-foreground group-hover:border-background/30 group-hover:text-background/70">
                  {job.location}
                </span>
              </div>
              <h3 className="mt-8 font-display text-2xl uppercase leading-tight">{job.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground group-hover:text-background/70">
                {job.blurb}
              </p>
            </div>
            <Link to={job.ctaTo} className="mt-8 inline-block text-sm underline">
              {job.ctaLabel} →
            </Link>
          </article>
        ))}
      </div>
      <p className="mt-8 max-w-3xl border-l-2 border-accent pl-4 text-sm text-muted-foreground">{disclaimer}</p>
    </Section>
  );
}
