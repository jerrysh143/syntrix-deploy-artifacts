import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { CtaLink, Section } from "@/components/site/primitives";
import { OpenRolesSection } from "@/components/site/OpenRolesSection";
import { disclaimer } from "@/lib/site-content";

const title = "Featured USA Roles & Career Opportunities | Syntrix Global";
const description =
  "Sample USA roles Syntrix commonly supports in software, data, cloud, healthcare IT, BA and cybersecurity. Not a live job board; placement is never guaranteed.";

export const Route = createFileRoute("/jobs")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://careers.syntrixglobal.in/jobs" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/careers-syntrixglobal-og-image.png" },
      { name: "twitter:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/careers-syntrixglobal-og-image.png" },
    ],
    links: [{ rel: "canonical", href: "https://careers.syntrixglobal.in/jobs" }],
  }),
  component: JobsPage,
});

function JobsPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />
      <main>
        <OpenRolesSection id="jobs" showPageIntro />
        <Section>
          <h2 className="display-lg">Ready to talk?</h2>
          <p className="mt-4 max-w-xl text-base leading-relaxed text-muted-foreground">
            Share your profile and target roles — we will discuss what fits and how we can support
            your search. Employment is never guaranteed.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <CtaLink to="/start-consultation">Start a Consultation</CtaLink>
            <CtaLink to="/contact" variant="outline">
              Register as a Candidate
            </CtaLink>
          </div>
          <p className="mt-6 max-w-2xl text-sm text-muted-foreground">{disclaimer}</p>
          <p className="mt-4 text-sm text-muted-foreground">
            Prefer the homepage view?{" "}
            <Link to="/" hash="jobs" className="underline underline-offset-4">
              Jump to Open Roles on Home
            </Link>
          </p>
        </Section>
      </main>
      <SiteFooter />
    </div>
  );
}
