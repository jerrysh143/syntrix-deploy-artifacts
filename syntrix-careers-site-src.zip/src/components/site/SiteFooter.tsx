import { useSubmission, SubmissionFields } from "./SubmissionFields";
import { Link } from "@tanstack/react-router";
import { brand } from "@/lib/site-content";

const columns = [
  {
    title: "Company",
    links: [
      { label: "About", to: "/about" },
      { label: "Contact", to: "/contact" },
      { label: "Start a Consultation", to: "/start-consultation" },
    ],
  },
  {
    title: "Career Services",
    links: [
      { label: "Career Consultation", to: "/career-services" },
      { label: "Resume Optimization", to: "/career-services" },
      { label: "LinkedIn Optimization", to: "/career-services" },
      { label: "Interview Preparation", to: "/career-services" },
      { label: "Placement Assistance", to: "/career-services" },
    ],
  },
  {
    title: "Candidates",
    links: [
      { label: "Open Roles", to: "/jobs" },
      { label: "Candidate Registration", to: "/contact" },
      { label: "Mock Interviews", to: "/career-services" },
      { label: "Recruiter Outreach", to: "/career-services" },
      { label: "Professional Branding", to: "/career-services" },
    ],
  },
  {
    title: "Legal",
    links: [
      { label: "Privacy Policy", to: "/privacy" },
      { label: "Terms", to: "/terms" },
      { label: "Disclaimer", to: "/disclaimer" },
    ],
  },
];

export function SiteFooter() {
  const {sent,pending,error,submit}=useSubmission("newsletter");
  return (
    <footer className="dark bg-background text-foreground">
      <div className="mx-auto w-full max-w-[1400px] px-5 py-16 sm:px-8">
        <div className="border-b border-border pb-12 text-center">
          <Link to="/" aria-label="Syntrix Global home" className="inline-block"><img src="/syntrix-logo-light.svg" alt={brand.name} width="520" height="136" className="mx-auto h-auto w-[260px] max-w-full sm:w-[340px]" /></Link>
          <p className="mt-4 text-[10px] uppercase tracking-[0.18em] text-muted-foreground sm:text-xs">People · Technology · Global Opportunities</p>
          <p className="label-xs mt-3 text-muted-foreground">
            U.S. placements, OPT/STEM OPT career support, healthcare &amp; IT staffing.
          </p>
          <a href="mailto:contact@syntrixglobal.in" className="mt-4 inline-block text-sm underline underline-offset-4">contact@syntrixglobal.in</a>
          <p className="mt-4 text-sm text-muted-foreground">
            Company site:{" "}
            <a
              href={brand.mainUrl}
              className="underline underline-offset-4 hover:text-foreground"
              rel="noopener noreferrer"
            >
              syntrixglobal.in
            </a>
          </p>
        </div>

        <div className="grid gap-10 border-b border-border py-12 sm:grid-cols-2 lg:grid-cols-4">
          {columns.map((col) => (
            <div key={col.title}>
              <h3 className="label-xs text-muted-foreground">{col.title}</h3>
              <ul className="mt-4 space-y-2">
                {col.links.map((link) => (
                  <li key={link.label}>
                    <Link
                      to={link.to}
                      className="text-sm text-foreground/80 transition-colors hover:text-foreground"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="grid gap-8 py-12 md:grid-cols-[minmax(0,1fr)_auto] md:items-end">
          <div className="max-w-md">
            <h3 className="font-display text-2xl uppercase">Stay in Touch</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              Request occasional updates about career preparation and our support services.
            </p>
            <form
              className="mt-5 flex flex-wrap gap-2"
              onSubmit={submit}
            >
              <label htmlFor="newsletter-email" className="sr-only">
                Email address
              </label>
              <input
                id="newsletter-email"
                name="email"
                type="email"
                required
                maxLength={255}
                placeholder="Your email address"
                className="min-w-0 flex-1 border border-border bg-transparent px-4 py-3 text-sm placeholder:text-muted-foreground"
              />
              <button type="submit" disabled={pending} className="bg-foreground px-5 py-3 label-xs text-background">
                Request updates
              </button>
              <SubmissionFields pending={pending} error={error} />
            </form>
            {sent && <p role="status" className="mt-3 text-sm">Your request for email updates has been sent.</p>}
          </div>

        </div>

        <p className="border-t border-border pt-8 text-center label-xs text-muted-foreground">
          © {new Date().getFullYear()} {brand.name}. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
