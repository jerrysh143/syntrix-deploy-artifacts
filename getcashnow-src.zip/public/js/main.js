(function () {
  const y = document.getElementById('y');
  if (y) y.textContent = String(new Date().getFullYear());

  const form = document.getElementById('leadForm');
  if (!form) return;

  const errorEl = document.getElementById('formError');
  function showError(msg) {
    errorEl.textContent = msg || '';
    errorEl.classList.toggle('show', !!msg);
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const firstName = form.firstName.value.trim();
    const lastName = form.lastName.value.trim();
    const zip = form.zip.value.trim();
    const phone = form.phone.value.trim();

    if (!firstName) return showError('Please enter your first name.');
    if (!lastName) return showError('Please enter your last name.');
    const zipDigits = zip.replace(/\D/g, '');
    if (zipDigits.length !== 5) return showError('Please enter a valid 5-digit ZIP code.');
    if (phone.replace(/\D/g, '').length < 10) return showError('Please enter a valid U.S. phone number.');
    if (!form.consentPrivacy.checked) return showError('Please agree to Privacy, Terms, and E-Consent.');
    if (!form.consentContact.checked) return showError('Contact consent is required to continue.');

    const submitBtn = document.getElementById('submitBtn');
    submitBtn.disabled = true;
    submitBtn.textContent = 'Submitting…';
    showError('');

    const payload = {
      firstName,
      lastName,
      zip: zipDigits,
      phone,
      consentPrivacy: true,
      consentContact: true,
      consentEsign: true,
    };

    try {
      const res = await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.ok) {
        const msg = (data.errors && data.errors.join(' ')) || data.error || 'Submission failed. Please try again.';
        showError(msg);
        submitBtn.disabled = false;
        submitBtn.textContent = 'Get Cash';
        return;
      }
      window.location.href = '/thank-you';
    } catch {
      showError('Network error. Please check your connection and try again.');
      submitBtn.disabled = false;
      submitBtn.textContent = 'Get Cash';
    }
  });
})();
