import { Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { brand, nav } from "@/lib/site-content";

function SearchInput() {
  const navigate = useNavigate();
  const [message, setMessage] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  const handleSearch = () => {
    const q = inputRef.current?.value.trim().toLowerCase() || "";
    if (!q) return;
    setMessage("");

    const itTerms = [
      "it",
      "software",
      "development",
      "developer",
      "web",
      "app",
      "application",
      "technology",
      "tech",
      "ai",
      "ml",
      "machine learning",
      "data",
      "cloud",
      "devops",
      "seo",
      "ecommerce",
      "commerce",
      "support",
      "website",
      "staffing",
      "staff",
      "recruit",
      "recruitment",
      "talent",
      "consult",
      "consulting",
      "placement",
      "hire",
      "hiring",
    ];

    if (q.includes("contact") || q.includes("reach") || q.includes("call")) {
      navigate({ to: "/contact" });
    } else if (q.includes("about") || q.includes("company")) {
      navigate({ to: "/about" });
    } else if (q.includes("work") || q.includes("portfolio") || q.includes("project")) {
      navigate({ to: "/work" });
    } else if (q.includes("staff") || q.includes("placement") || q.includes("recruit")) {
      navigate({ to: "/staffing" });
    } else if (q.includes("talent") || q.includes("workforce") || q.includes("consult")) {
      navigate({ to: "/talent-consulting" });
    } else if (itTerms.some((term) => q.includes(term))) {
      navigate({ to: "/services" });
    } else {
      setMessage("No matching page. Try staffing, consulting, projects, about or contact.");
      return;
    }

    if (inputRef.current) inputRef.current.value = "";
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleSearch();
    }
  };

  return (
    <div className="relative flex items-center">
      {message && <p role="status" className="absolute top-full right-0 z-50 w-64 border border-border bg-background p-3 text-sm">{message}</p>}
      <label htmlFor="site-search" className="sr-only">
        Search
      </label>
      <input
        id="site-search"
        ref={inputRef}
        type="text"
        defaultValue=""
        onKeyDown={handleKeyDown}
        placeholder="Search staffing..."
        className="h-9 w-36 border border-border bg-background pl-3 pr-8 text-sm placeholder:text-muted-foreground focus:border-ink focus:outline-none sm:w-44"
      />
      <button
        type="button"
        onClick={handleSearch}
        aria-label="Search"
        className="absolute right-0 top-0 grid h-9 w-9 place-items-center text-muted-foreground transition-colors hover:text-foreground"
      >
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6">
          <circle cx="7" cy="7" r="5.5" />
          <path d="M11.5 11.5L15 15" />
        </svg>
      </button>
    </div>
  );
}

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const cta = "Hire Talent";
  const ctaTo = "/start-project";

  return (
    <header
      id="top"
      className={`sticky top-0 z-50 border-b border-border transition-colors duration-300 ${
        scrolled ? "bg-background/90 backdrop-blur" : "bg-background"
      }`}
    >
      <div className="mx-auto grid w-full max-w-[1400px] grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-5 py-4 sm:px-8">
        <div className="flex min-w-0 items-center gap-6">
          <Link to="/" className="flex min-w-0 items-center">
            <span className="min-w-0">
              <img src="/syntrix-logo.svg" alt={brand.name} width="520" height="136" className="h-auto w-[174px] sm:w-[208px]" />
              <span className="sr-only">{brand.tagline}</span>
            </span>
          </Link>
        </div>

        <div className="flex items-center gap-5">
          <nav aria-label="Primary" className="hidden items-center gap-5 xl:flex">
            {nav.map((item) => (
              <Link
                key={item.label}
                to={item.to}
                activeProps={{ className: "text-foreground" }}
                className="label-xs text-muted-foreground transition-colors hover:text-foreground"
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="hidden md:block">
            <SearchInput />
          </div>
          <Link
            to={ctaTo}
            className="hidden bg-ink px-5 py-3 label-xs text-ivory transition-colors hover:bg-accent hover:text-accent-foreground md:inline-block"
          >
            {cta}
          </Link>
          <button
            type="button"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
            className="grid size-11 place-items-center border border-border xl:hidden"
          >
            <span className="sr-only">Menu</span>
            <svg width="18" height="18" viewBox="0 0 18 18" stroke="currentColor" strokeWidth="1.6" fill="none">
              {open ? <path d="M4 4l10 10M14 4L4 14" /> : <path d="M2 5h14M2 9h14M2 13h14" />}
            </svg>
          </button>
        </div>
      </div>

      {open ? (
        <div className="max-h-[calc(100dvh-90px)] overflow-y-auto border-t border-border bg-background xl:hidden">
          <div className="mx-auto flex min-h-full w-full max-w-[1400px] flex-col px-5 py-6 sm:px-8">
            <nav aria-label="Mobile" className="grid gap-1">
              {nav.map((item) => (
                <Link
                  key={item.label}
                  to={item.to}
                  onClick={() => setOpen(false)}
                  className="border-b border-border py-3 font-display text-xl uppercase"
                >
                  {item.label}
                </Link>
              ))}
            </nav>

            <div className="mt-4 md:hidden">
              <SearchInput />
            </div>

            <Link
              to={ctaTo}
              onClick={() => setOpen(false)}
              className="mt-6 block bg-ink px-5 py-4 text-center label-xs text-ivory"
            >
              {cta}
            </Link>
          </div>
        </div>
      ) : null}
    </header>
  );
}
