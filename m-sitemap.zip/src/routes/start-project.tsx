import { createFileRoute } from "@tanstack/react-router";
import { useSubmission, SubmissionFields } from "@/components/site/SubmissionFields";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { Eyebrow, Section, SectionHeading } from "@/components/site/primitives";
import { brand, itProcess, itServices } from "@/lib/site-content";

const title = "Request Staffing or Consulting Support | Syntrix Global";
const description =
  "Tell us the roles or consulting need. Syntrix replies within two business days with next steps for staffing, placement or supporting technology work.";

export const Route = createFileRoute("/start-project")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://syntrixglobal.in/start-project" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/syntrixglobal-og-image.png" },
      { name: "twitter:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/syntrixglobal-og-image.png" },
    ],
    links: [{ rel: "canonical", href: "https://syntrixglobal.in/start-project" }],
  }),
  component: StartProjectPage,
});

const field =
  "w-full border border-border bg-transparent px-4 py-3 text-sm placeholder:text-muted-foreground focus:border-ink focus:outline-none";
const labelCls = "label-xs block text-muted-foreground";

function StartProjectPage() {
  const { sent, pending, error, submit } = useSubmission("project-brief");

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />

      <Section>
        <SectionHeading as="h1"
          eyebrow="Request staffing support"
          title="Request Staffing or Consulting Support"
          intro="Share the roles, consulting question or supporting technology need below. We reply within two business days with next steps. Forms continue to submit as before."
        />
        <h2 className="mt-10 font-display text-3xl uppercase">Tell Us What You Need.</h2>

        <div className="mt-14 grid gap-12 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)]">
          <form className="grid gap-5" onSubmit={submit}>
            <SubmissionFields pending={pending} error={error} />
            <div className="grid gap-5 sm:grid-cols-2">
              <div>
                <label className={labelCls} htmlFor="sp-name">
                  Full name
                </label>
                <input
                  id="sp-name"
                  name="name"
                  required
                  maxLength={100}
                  className={`${field} mt-2`}
                  placeholder="Your name"
                />
              </div>
              <div>
                <label className={labelCls} htmlFor="sp-email">
                  Work email
                </label>
                <input
                  id="sp-email"
                  name="email"
                  type="email"
                  required
                  maxLength={255}
                  className={`${field} mt-2`}
                  placeholder="Your email address"
                />
              </div>
              <div>
                <label className={labelCls} htmlFor="sp-company">
                  Company
                </label>
                <input
                  id="sp-company"
                  name="company"
                  maxLength={120}
                  className={`${field} mt-2`}
                  placeholder="Company name"
                />
              </div>
              <div>
                <label className={labelCls} htmlFor="sp-phone">
                  Phone
                </label>
                <input
                  id="sp-phone"
                  name="phone"
                  maxLength={30}
                  className={`${field} mt-2`}
                  placeholder="Phone number with country code"
                />
              </div>
            </div>

            <div>
              <label className={labelCls} htmlFor="sp-service">
                Service needed
              </label>
              <select id="sp-service" name="service" className={`${field} mt-2`} defaultValue="">
                <option value="" disabled>
                  Select a service
                </option>
                {itServices.map((s) => (
                  <option key={s.no} value={s.title}>
                    {s.title}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid gap-5 sm:grid-cols-2">
              <div>
                <label className={labelCls} htmlFor="sp-budget">
                  Scope / budget range
                </label>
                <select id="sp-budget" name="budget" className={`${field} mt-2`} defaultValue="">
                  <option value="" disabled>
                    Select a range
                  </option>
                  <option>Exploring options</option>
                  <option>Under $10k</option>
                  <option>$10k – $25k</option>
                  <option>$25k – $50k</option>
                  <option>$50k – $100k</option>
                  <option>$100k+</option>
                </select>
              </div>
              <div>
                <label className={labelCls} htmlFor="sp-timeline">
                  Timeline
                </label>
                <select id="sp-timeline" name="timeline" className={`${field} mt-2`} defaultValue="">
                  <option value="" disabled>
                    Select a timeline
                  </option>
                  <option>ASAP</option>
                  <option>1 – 3 months</option>
                  <option>3 – 6 months</option>
                  <option>Exploring options</option>
                </select>
              </div>
            </div>

            <div>
              <label className={labelCls} htmlFor="sp-details">
                Details
              </label>
              <textarea
                id="sp-details"
                name="details"
                rows={6}
                maxLength={2000}
                className={`${field} mt-2`}
                placeholder="Roles to fill, skills needed, consulting question, current constraints..."
              />
            </div>

            <button
              type="submit"
              disabled={pending}
              className="justify-self-start bg-ink px-6 py-4 label-xs text-ivory transition-colors hover:bg-accent hover:text-accent-foreground"
            >
              Submit Enquiry
            </button>

            {sent ? (
              <p aria-live="polite" className="border border-border px-4 py-3 text-sm text-muted-foreground">
                Thanks — your enquiry has been received. We&apos;ll be in touch shortly.
              </p>
            ) : null}
          </form>

          <aside className="border border-border p-8">
            <Eyebrow>How engagement works</Eyebrow>
            <ul className="mt-6 space-y-5">
              {itProcess.map((p) => (
                <li key={p.no} className="flex gap-4 border-b border-border pb-4 last:border-0">
                  <span className="label-xs text-muted-foreground">{p.no}</span>
                  <span className="font-display text-lg uppercase">{p.title}</span>
                </li>
              ))}
            </ul>
            <p className="mt-8 text-sm text-muted-foreground">
              Looking for a career instead?{" "}
              <a href={brand.careersUrl} className="underline" rel="noopener noreferrer">
                Visit careers.syntrixglobal.in
              </a>
            </p>
          </aside>
        </div>
      </Section>

      <SiteFooter />
    </div>
  );
}
