import { createFileRoute } from "@tanstack/react-router";
import { useSubmission, SubmissionFields } from "@/components/site/SubmissionFields";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { Eyebrow, Section } from "@/components/site/primitives";

const title = "Contact — Candidate Registration & Career Consultation";
const description =
  "Register as a candidate or book a career consultation with Syntrix Global for resume, LinkedIn, interview and placement support across the United States.";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://careers.syntrixglobal.in/contact" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/careers-syntrixglobal-og-image.png" },
      { name: "twitter:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/careers-syntrixglobal-og-image.png" },
    ],
    links: [{ rel: "canonical", href: "https://careers.syntrixglobal.in/contact" }],
  }),
  component: ContactPage,
});

const field =
  "w-full border border-border bg-transparent px-4 py-3 text-sm placeholder:text-muted-foreground";
const labelCls = "label-xs block text-muted-foreground";

function Field({
  id,
  label,
  type = "text",
  required,
  maxLength = 200,
}: {
  id: string;
  label: string;
  type?: string;
  required?: boolean;
  maxLength?: number;
}) {
  return (
    <div className="grid gap-2">
      <label htmlFor={id} className={labelCls}>
        {label}
      </label>
      <input id={id} name={id} type={type} required={required} maxLength={maxLength} className={field} />
    </div>
  );
}

function CandidateForm() {
  const {sent,pending,error,submit} = useSubmission("candidate");
  if (sent) {
    return (
      <p role="status" className="border border-border p-6 text-sm">
        Thank you — your profile has been submitted. A consultant will review it and reach out.
      </p>
    );
  }
  return (
    <form
      className="grid gap-5 sm:grid-cols-2"
      onSubmit={submit}
    >
      <SubmissionFields pending={pending} error={error} />
      <Field id="firstName" label="First Name" required />
      <Field id="lastName" label="Last Name" required />
      <Field id="cemail" label="Email" type="email" required maxLength={255} />
      <Field id="cphone" label="Phone" type="tel" maxLength={30} />
      <Field id="location" label="Current Location" />
      <Field id="state" label="USA State" />
      <Field id="education" label="Highest Education" />
      <Field id="university" label="University" />
      <Field id="graduation" label="Graduation Date" type="month" />
      <Field id="experience" label="Experience" />
      <Field id="skill" label="Primary Skill" />
      <Field id="targetRole" label="Target Role" />
      <Field id="industry" label="Industry" />
      <div className="grid gap-2">
        <label htmlFor="status" className={labelCls}>
          Employment Status
        </label>
        <select id="status" name="status" className={field}>
          {["Student", "Recent Graduate", "Employed", "Seeking Opportunities"].map((o) => (
            <option key={o}>{o}</option>
          ))}
        </select>
      </div>
      <Field id="preferred" label="Preferred Location" />
      <Field id="linkedin" label="LinkedIn URL" type="url" maxLength={300} />
      <Field id="portfolio" label="Portfolio URL" type="url" maxLength={300} />
      <Field id="github" label="GitHub URL" type="url" maxLength={300} />
      <div className="grid gap-2 sm:col-span-2">
        <label htmlFor="resume" className={labelCls}>
          Resume Upload (PDF or DOCX, up to 5 MB)
        </label>
        <input
          id="resume"
          name="resume"
          type="file"
          accept=".pdf,.docx"
          className="w-full border border-border px-4 py-3 text-sm"
        />
      </div>
      <div className="grid gap-2 sm:col-span-2">
        <label htmlFor="message" className={labelCls}>
          Message
        </label>
        <textarea id="message" name="message" rows={4} maxLength={1000} className={field} />
      </div>
      <label className="flex items-start gap-3 text-sm sm:col-span-2">
        <input type="checkbox" name="consent" value="accepted" required className="mt-1 size-4" />
        <span className="text-muted-foreground">I agree to the <a href="/privacy" className="underline">Privacy Policy</a> and <a href="/terms" className="underline">Terms</a>.</span>
      </label>
      <button type="submit" disabled={pending} className="bg-ink px-6 py-4 label-xs text-ivory sm:col-span-2">
        Submit Profile
      </button>
    </form>
  );
}

function ContactPage() {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main>
        <Section>
          <Eyebrow>Contact</Eyebrow>
          <h1 className="display-lg mt-4">
            Tell Us
            <br />
            Where You're Headed.
          </h1>
          <p className="mt-6 max-w-xl text-base leading-relaxed text-muted-foreground">
            Share your background and target role. A consultant reviews every profile and replies
            with an assessment and suggested next steps.
          </p>

          <div className="mt-12 grid gap-12 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,0.6fr)]">
            <CandidateForm />
            <aside className="border-t border-border pt-8 lg:border-t-0 lg:border-l lg:pt-0 lg:pl-8">
              <h2 className="label-xs text-muted-foreground">Contact</h2>
              <a href="mailto:contact@syntrixglobal.in" className="mt-3 block text-sm underline">contact@syntrixglobal.in</a>
              <h2 className="label-xs mt-8 text-muted-foreground">What happens next</h2>
              <p className="mt-3 text-sm text-muted-foreground">We review your background and goals, then contact you to discuss suitable career support.</p>
            </aside>
          </div>
        </Section>
      </main>
      <SiteFooter />
    </div>
  );
}
