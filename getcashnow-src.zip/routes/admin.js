'use strict';

const express = require('express');
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const store = require('../lib/store');

const router = express.Router();

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { ok: false, error: 'Too many login attempts. Try again later.' },
});

function requireAuth(req, res, next) {
  if (req.session && req.session.adminAuthenticated) return next();
  return res.status(401).json({ ok: false, error: 'Unauthorized' });
}

router.post('/login', loginLimiter, (req, res) => {
  const username = String((req.body && req.body.username) || '').trim();
  const password = String((req.body && req.body.password) || '');
  const admin = store.getAdmin();

  if (!admin || !admin.passwordHash) {
    return res.status(503).json({ ok: false, error: 'Admin not configured' });
  }

  if (username !== admin.username || !bcrypt.compareSync(password, admin.passwordHash)) {
    return res.status(401).json({ ok: false, error: 'Invalid username or password' });
  }

  req.session.adminAuthenticated = true;
  req.session.adminUser = admin.username;
  return res.json({ ok: true, username: admin.username });
});

router.post('/logout', (req, res) => {
  req.session.destroy(() => {
    res.clearCookie('connect.sid');
    res.json({ ok: true });
  });
});

router.get('/me', (req, res) => {
  if (req.session && req.session.adminAuthenticated) {
    return res.json({ ok: true, username: req.session.adminUser || 'admin' });
  }
  return res.status(401).json({ ok: false });
});

router.get('/leads', requireAuth, (req, res) => {
  let leads = store.getLeads();
  const q = String(req.query.q || '').trim().toLowerCase();
  const status = String(req.query.status || '').trim().toLowerCase();

  if (status && ['new', 'contacted', 'qualified', 'rejected'].includes(status)) {
    leads = leads.filter((l) => l.status === status);
  }
  if (q) {
    leads = leads.filter((l) => {
      const hay = [l.firstName, l.lastName, l.fullName, l.zip, l.phone, l.notes]
        .join(' ')
        .toLowerCase();
      return hay.includes(q);
    });
  }

  return res.json({ ok: true, leads, total: leads.length });
});

router.get('/leads/:id', requireAuth, (req, res) => {
  const lead = store.getLead(req.params.id);
  if (!lead) return res.status(404).json({ ok: false, error: 'Not found' });
  return res.json({ ok: true, lead });
});

router.patch('/leads/:id', requireAuth, (req, res) => {
  const lead = store.getLead(req.params.id);
  if (!lead) return res.status(404).json({ ok: false, error: 'Not found' });

  const updates = {};
  if (req.body.status !== undefined) {
    const s = String(req.body.status).toLowerCase();
    if (!['new', 'contacted', 'qualified', 'rejected'].includes(s)) {
      return res.status(400).json({ ok: false, error: 'Invalid status' });
    }
    updates.status = s;
  }
  if (req.body.notes !== undefined) {
    updates.notes = String(req.body.notes).slice(0, 5000);
  }

  const updated = store.updateLead(req.params.id, updates);
  return res.json({ ok: true, lead: updated });
});

router.get('/export.csv', requireAuth, (req, res) => {
  const leads = store.getLeads();
  const header = [
    'id', 'createdAt', 'status', 'firstName', 'lastName', 'fullName',
    'zip', 'phone', 'notes',
  ];
  const escape = (v) => {
    const s = v == null ? '' : String(v);
    if (/[",\n\r]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
    return s;
  };
  const rows = [header.join(',')].concat(
    leads.map((l) =>
      header.map((h) => escape(l[h])).join(',')
    )
  );
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="leads-export.csv"');
  res.send(rows.join('\n'));
});

module.exports = router;
