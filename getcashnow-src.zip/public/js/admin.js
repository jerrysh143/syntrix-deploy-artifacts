(function () {
  const loginView = document.getElementById('loginView');
  const dashView = document.getElementById('dashView');
  const loginError = document.getElementById('loginError');
  const leadsBody = document.getElementById('leadsBody');
  const drawer = document.getElementById('drawer');
  let currentId = null;

  function fmtDate(iso) {
    try {
      return new Date(iso).toLocaleString('en-IN', { timeZone: 'Asia/Calcutta' });
    } catch {
      return iso || '';
    }
  }
  function badge(status) {
    const s = status || 'new';
    return `<span class="badge badge-${s}">${s}</span>`;
  }
  function showLoginErr(msg) {
    loginError.textContent = msg || '';
    loginError.classList.toggle('show', !!msg);
  }
  function escapeHtml(s) {
    return String(s || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  async function api(url, opts) {
    const res = await fetch(url, {
      credentials: 'same-origin',
      headers: { Accept: 'application/json', 'Content-Type': 'application/json', ...(opts && opts.headers) },
      ...opts,
    });
    const data = await res.json().catch(() => ({}));
    return { res, data };
  }

  async function checkAuth() {
    const { res, data } = await api('/api/admin/me');
    if (res.ok && data.ok) {
      document.getElementById('who').textContent = data.username || 'admin';
      loginView.classList.add('panel-hidden');
      dashView.classList.remove('panel-hidden');
      await loadLeads();
      return true;
    }
    loginView.classList.remove('panel-hidden');
    dashView.classList.add('panel-hidden');
    return false;
  }

  function renderStats(leads) {
    const counts = { new: 0, contacted: 0, qualified: 0, rejected: 0 };
    leads.forEach((l) => { if (counts[l.status] != null) counts[l.status]++; });
    document.getElementById('stats').innerHTML = [
      ['Total', leads.length],
      ['New', counts.new],
      ['Contacted', counts.contacted],
      ['Qualified', counts.qualified],
      ['Rejected', counts.rejected],
    ].map(([label, n]) => `<div class="stat"><b>${n}</b><span>${label}</span></div>`).join('');
  }

  function renderTable(leads) {
    if (!leads.length) {
      leadsBody.innerHTML = '<tr><td colspan="6">No leads found.</td></tr>';
      return;
    }
    leadsBody.innerHTML = leads.map((l) => {
      const name = l.fullName || [l.firstName, l.lastName].filter(Boolean).join(' ');
      return `
      <tr>
        <td>${fmtDate(l.createdAt)}</td>
        <td>${escapeHtml(name)}</td>
        <td>${escapeHtml(l.phone)}</td>
        <td>${escapeHtml(l.zip)}</td>
        <td>${badge(l.status)}</td>
        <td><button class="btn btn-ghost btn-sm" data-open="${l.id}" type="button">View</button></td>
      </tr>`;
    }).join('');
  }

  async function loadLeads() {
    const q = document.getElementById('searchQ').value.trim();
    const status = document.getElementById('statusFilter').value;
    const params = new URLSearchParams();
    if (q) params.set('q', q);
    if (status) params.set('status', status);
    const { res, data } = await api('/api/admin/leads?' + params.toString());
    if (!res.ok) {
      leadsBody.innerHTML = '<tr><td colspan="6">Failed to load leads.</td></tr>';
      return;
    }
    const leads = data.leads || [];
    renderStats(leads);
    renderTable(leads);
  }

  async function openLead(id) {
    const { res, data } = await api('/api/admin/leads/' + encodeURIComponent(id));
    if (!res.ok) return;
    const l = data.lead;
    currentId = l.id;
    const name = l.fullName || [l.firstName, l.lastName].filter(Boolean).join(' ');
    document.getElementById('dName').textContent = name || 'Lead';
    document.getElementById('dMeta').innerHTML = `
      <p class="meta"><strong>First:</strong> ${escapeHtml(l.firstName)}</p>
      <p class="meta"><strong>Last:</strong> ${escapeHtml(l.lastName)}</p>
      <p class="meta"><strong>Phone:</strong> ${escapeHtml(l.phone)}</p>
      <p class="meta"><strong>ZIP:</strong> ${escapeHtml(l.zip)}</p>
      <p class="meta"><strong>Created:</strong> ${fmtDate(l.createdAt)}</p>
      <p class="meta"><strong>ID:</strong> ${escapeHtml(l.id)}</p>
    `;
    document.getElementById('dStatus').value = l.status || 'new';
    document.getElementById('dNotes').value = l.notes || '';
    document.getElementById('saveMsg').classList.remove('show');
    drawer.classList.add('open');
  }

  document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    showLoginErr('');
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;
    const { res, data } = await api('/api/admin/login', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    });
    if (!res.ok || !data.ok) {
      showLoginErr(data.error || 'Login failed');
      return;
    }
    await checkAuth();
  });

  document.getElementById('logoutBtn').addEventListener('click', async () => {
    await api('/api/admin/logout', { method: 'POST', body: '{}' });
    currentId = null;
    drawer.classList.remove('open');
    await checkAuth();
  });

  document.getElementById('refreshBtn').addEventListener('click', loadLeads);
  document.getElementById('searchQ').addEventListener('input', () => {
    clearTimeout(window.__gcnSearch);
    window.__gcnSearch = setTimeout(loadLeads, 250);
  });
  document.getElementById('statusFilter').addEventListener('change', loadLeads);

  leadsBody.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-open]');
    if (btn) openLead(btn.getAttribute('data-open'));
  });

  document.getElementById('closeDrawer').addEventListener('click', () => drawer.classList.remove('open'));
  drawer.addEventListener('click', (e) => { if (e.target === drawer) drawer.classList.remove('open'); });

  document.getElementById('saveLead').addEventListener('click', async () => {
    if (!currentId) return;
    const saveMsg = document.getElementById('saveMsg');
    const { res, data } = await api('/api/admin/leads/' + encodeURIComponent(currentId), {
      method: 'PATCH',
      body: JSON.stringify({
        status: document.getElementById('dStatus').value,
        notes: document.getElementById('dNotes').value,
      }),
    });
    if (!res.ok) {
      saveMsg.textContent = data.error || 'Save failed';
      saveMsg.classList.add('show');
      return;
    }
    saveMsg.textContent = 'Saved.';
    saveMsg.style.color = 'var(--ok)';
    saveMsg.classList.add('show');
    await loadLeads();
  });

  checkAuth();
})();
