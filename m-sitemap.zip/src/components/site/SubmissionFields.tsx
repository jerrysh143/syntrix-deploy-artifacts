import { useRef, useState, type FormEvent } from "react";

export function useSubmission(formType: string) {
  const [sent, setSent] = useState(false);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState("");
  const busy = useRef(false);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy.current) return;
    const form = event.currentTarget;
    const data = new FormData(form);
    const resume = data.get("resume");
    if (resume instanceof File && resume.size > 5 * 1024 * 1024) { setError("Resume must be 5 MB or smaller."); return; }
    data.set("formType", formType);
    busy.current = true; setPending(true); setError(""); setSent(false);
    try {
      const response = await fetch("/api/submissions", {method:"POST", body:data, signal:AbortSignal.timeout(60000)});
      const result = await response.json();
      if (!response.ok || !result.ok) throw new Error(result.error || "Submission failed. Please try again.");
      setSent(true); form.reset();
    } catch (error) { setError(error instanceof Error && error.name !== "TimeoutError" ? error.message : "Delivery is taking longer than expected. Please check before submitting again."); }
    finally { busy.current=false; setPending(false); }
  }
  return {sent,pending,error,submit};
}

export function SubmissionFields({pending,error}: {pending:boolean;error:string}) {
 return <>
   <div className="hidden" aria-hidden="true"><label>Leave empty<input name="website" tabIndex={-1} autoComplete="off" /></label></div>
   {pending && <p role="status" className="text-sm sm:col-span-2">Sending…</p>}
   {error && <p role="alert" className="border border-border p-3 text-sm sm:col-span-2">{error}</p>}
 </>;
}
