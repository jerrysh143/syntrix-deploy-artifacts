export const brand = {
  name: "Syntrix Global",
  tagline: "Consultancy & Staffing Partners",
  location: "India",
  locationLine: "USA staffing (San Antonio primary) · India office for company contact",
  offices: [
    {
      label: "India",
      lines: [
        "3rd Floor, 312 RJD Arcade",
        "Near Khodiyar Temple, GST Railway Crossing Road",
        "New Ranip, Ahmedabad, Gujarat 382480",
        "India",
      ],
    },
    {
      label: "United States",
      lines: [
        "12370 Potranco Rd",
        "Ste 207",
        "San Antonio, TX 78253",
        "United States",
      ],
    },
  ],
  careersUrl: "https://careers.syntrixglobal.in",
  careersJobsUrl: "https://careers.syntrixglobal.in/jobs",
};

export const nav = [
  { label: "Home", to: "/" },
  { label: "About", to: "/about" },
  { label: "Services", to: "/services" },
  { label: "Staffing", to: "/staffing" },
  { label: "Talent Consulting", to: "/talent-consulting" },
  { label: "Projects", to: "/work" },
  { label: "Contact", to: "/contact" },
];

/** Primary consultancy & staffing offerings — lead the site. */
export const staffingServices = [
  {
    no: "01",
    title: "Placement & Staffing",
    desc: "Employers get contract, contract-to-hire and permanent placement support tied to role briefs, timelines and hiring standards — so shortlists stay usable for interview decisions.",
  },
  {
    no: "02",
    title: "Talent Consulting",
    desc: "Hiring teams get workforce planning, role definition and hiring strategy before interviews start — reducing unclear briefs and wasted interview cycles.",
  },
  {
    no: "03",
    title: "Recruitment Support",
    desc: "Employers get sourcing, screening and coordination that move qualified candidates through the pipeline with clear ownership and feedback — without invented fill metrics.",
  },
];

/** Secondary technology offerings — supporting, not the primary brand story. */
export const techServices = [
  {
    no: "01",
    title: "Software Development",
    desc: "Purpose-built custom software engineered for your unique business workflows.",
  },
  {
    no: "02",
    title: "Website Development",
    desc: "Modern responsive websites and high-performance web applications.",
  },
  {
    no: "03",
    title: "Mobile Apps",
    desc: "Native-quality iOS and Android apps with scalable backends.",
  },
  {
    no: "04",
    title: "AI & Machine Learning",
    desc: "Intelligent automation, predictive systems and generative AI.",
  },
  {
    no: "05",
    title: "Data Analytics",
    desc: "Dashboards, visualization, reporting and BI decision systems.",
  },
  {
    no: "06",
    title: "Cloud Services",
    desc: "Cloud infrastructure, migration, deployment automation and scale.",
  },
];

/** Flat list used by forms and legacy consumers — staffing first, then technology. */
export const itServices = [
  ...staffingServices,
  ...techServices.map((s, i) => ({
    ...s,
    no: String(staffingServices.length + i + 1).padStart(2, "0"),
  })),
];

const byTitle = Object.fromEntries(itServices.map((s) => [s.title, s]));

/** Clustered services — staffing leads; technology is secondary. */
export const serviceGroups = [
  {
    no: "01",
    title: "Staffing & Placement",
    desc: "Recruitment, placement and ongoing staffing support for employers who need the right people in seat.",
    ctaLabel: "Request staffing support",
    ctaTo: "/start-project" as const,
    services: [
      byTitle["Placement & Staffing"],
      byTitle["Talent Consulting"],
      byTitle["Recruitment Support"],
    ],
  },
  {
    no: "02",
    title: "Technology Services",
    desc: "Software, AI and cloud capability that supports delivery when your engagement needs build work.",
    ctaLabel: "Discuss technology needs",
    ctaTo: "/start-project" as const,
    services: [
      byTitle["Software Development"],
      byTitle["Website Development"],
      byTitle["Mobile Apps"],
      byTitle["AI & Machine Learning"],
      byTitle["Data Analytics"],
      byTitle["Cloud Services"],
    ],
  },
];

export const itIndustries = [
  "Information Technology",
  "Professional Services",
  "Healthcare",
  "Finance",
  "E-Commerce",
  "Logistics",
  "Education",
  "Manufacturing",
];

export const itProcess = [
  { no: "01", title: "Discovery" },
  { no: "02", title: "Role & Scope" },
  { no: "03", title: "Sourcing" },
  { no: "04", title: "Screening" },
  { no: "05", title: "Shortlist" },
  { no: "06", title: "Placement Support" },
];

export const work = [
  {
    title: "Contract IT capacity for a product employer",
    tag: "Staffing · Contract",
    desc: "Role type: mid-level engineers. Engagement: contract. Syntrix defined the brief with the hiring manager, sourced and screened candidates, and coordinated interviews through shortlist — no invented fill metrics.",
  },
  {
    title: "Permanent placement support for an ops team",
    tag: "Staffing · Permanent",
    desc: "Role type: IT operations and support. Engagement: permanent. Syntrix aligned screening criteria to the employer’s standards and supported shortlist-to-offer coordination.",
  },
  {
    title: "Workforce planning before a hiring surge",
    tag: "Consulting",
    desc: "Engagement: talent consulting. Syntrix helped the employer clarify role definitions, interview stages and near-term hiring priorities before staffing began.",
  },
  {
    title: "Recruitment / Career Platform",
    tag: "Technology · Supporting",
    desc: "Supporting build when an engagement needed product work — candidate profiles, role listings and application tracking workflows.",
  },
  {
    title: "E-Commerce Platform",
    tag: "Technology · Supporting",
    desc: "Supporting technology showcase — product catalogues, customer accounts and order-management workflows.",
  },
  {
    title: "YOMORA storefront (supporting)",
    tag: "Technology · Supporting",
    desc: "Featured technology showcase for silver jewellery ecommerce — labeled supporting/secondary to staffing and consulting work.",
  },
];


/** FAQ copy for /staffing — keep in sync with on-page FAQ + FAQPage JSON-LD. */
export const staffingFaqs = [
  {
    q: "Who is IT staffing for?",
    a: "Employers only. We support hiring managers and talent teams that need contract or permanent IT roles filled. Candidates should use careers.syntrixglobal.in.",
  },
  {
    q: "Do you support contract and permanent placements?",
    a: "Yes. We support contract, contract-to-hire and permanent IT placements based on the role brief and timeline you share.",
  },
  {
    q: "Do you guarantee placements or time-to-hire?",
    a: "No. We do not invent metrics or guarantee outcomes. We focus on a clear process, qualified shortlists and honest communication.",
  },
  {
    q: "Which markets do you cover?",
    a: "United States employers only. San Antonio, TX is our primary USA staffing presence. Our India office address is company contact only — not a staffing service market.",
  },
  {
    q: "How do we start?",
    a: "Share roles, engagement type and constraints via Start a Project. We review the enquiry and reply with next steps.",
  },
];


/** FAQ copy for /talent-consulting — keep in sync with on-page FAQ + FAQPage JSON-LD. */
export const talentConsultingFaqs = [
  {
    q: "Who is talent consulting for?",
    a: "Hiring teams and employers who need help defining roles, planning workforce needs, or designing interview processes before or alongside staffing.",
  },
  {
    q: "Is this the same as IT staffing?",
    a: "No. Talent consulting focuses on role definition, hiring strategy and workforce planning. Staffing focuses on sourcing and placement. Many employers use both.",
  },
  {
    q: "When is technology delivery secondary?",
    a: "When the primary need is people and process — not building software. Tech services stay available if an engagement later needs product or systems work.",
  },
  {
    q: "Do you invent hiring metrics or guarantees?",
    a: "No. We do not invent fill-rate metrics or guarantee interview or hire outcomes. Advice stays process-focused and honest.",
  },
  {
    q: "How do we start a consulting engagement?",
    a: "Share the hiring challenge, roles and constraints via Start a Project. We review and reply with suggested next steps.",
  },
];


/** FAQ copy for /services — keep in sync with on-page FAQ + FAQPage JSON-LD. */
export const servicesFaqs = [
  {
    q: "Should we choose staffing or talent consulting?",
    a: "Choose staffing when you need people placed into defined roles. Choose talent consulting when you need help defining roles, workforce plans or interview process first. Many employers use both.",
  },
  {
    q: "Are technology services the main offer?",
    a: "No. Staffing and consulting lead. Software, AI and cloud remain secondary supporting services when an engagement also needs build work.",
  },
  {
    q: "Do you guarantee placements or consulting outcomes?",
    a: "No. We do not invent metrics or guarantee hire outcomes. We focus on clear process and honest communication.",
  },
  {
    q: "Where do you operate?",
    a: "Staffing and talent consulting serve USA employers, with San Antonio as our primary geo page. India (Ahmedabad) remains a company contact office only — not a staffing service market.",
  },
  {
    q: "How do we start?",
    a: "Share the roles or consulting question via Start a Project. We review and reply with next steps.",
  },
];


/** Ahmedabad location page removed — office NAP stays on brand.offices / footer contact only. */


/** FAQ for /locations/san-antonio — sync with on-page FAQ + FAQPage JSON-LD. */
export const sanAntonioFaqs = [
  {
    q: "Does Syntrix Global have a USA address in San Antonio?",
    a: "Yes. Our United States address is 12370 Potranco Rd, Ste 207, San Antonio, TX 78253, United States.",
  },
  {
    q: "Who do you serve from San Antonio?",
    a: "USA employers seeking IT staffing, placement and talent consulting support. Candidates should use careers.syntrixglobal.in.",
  },
  {
    q: "Do you only hire locally in San Antonio?",
    a: "No. San Antonio is our primary USA geo for staffing and talent consulting. Scope depends on the roles you share — we do not position Ahmedabad as a staffing service city.",
  },
  {
    q: "How do USA employers start?",
    a: "Share roles or consulting needs via Start a Project. We review and reply with next steps.",
  },
];


/** /services/india-usa-staffing removed — 301 to /staffing (USA-only staffing). */

export const itFaqs = [
  {
    q: "What does Syntrix Global do?",
    a: "We are a consultancy and staffing firm. We help employers with recruitment, placement and talent consulting. Software, AI and cloud work remain available as supporting services when an engagement needs them.",
  },
  {
    q: "Do you hire for contract and permanent roles?",
    a: "Yes. We support contract, contract-to-hire and permanent placements based on the roles and timelines you share.",
  },
  {
    q: "Can you help define the role before we start hiring?",
    a: "Yes. Talent consulting covers workforce planning, role definition and hiring process design so sourcing starts from a clear brief.",
  },
  {
    q: "Is careers.syntrixglobal.in for employers or candidates?",
    a: "Careers.syntrixglobal.in is our USA candidate funnel. Employers should contact us on this site; candidates looking for career support can visit the careers site.",
  },
  {
    q: "Do you still build software and AI systems?",
    a: "Yes, as a secondary offering. When staffing or consulting work requires product or systems build-out, our technology services cover web, mobile, AI, data and cloud.",
  },
  {
    q: "Where are you based?",
    a: "Staffing services focus on USA employers (San Antonio primary). Company offices: India (Ahmedabad) and United States (San Antonio, Texas) — Ahmedabad is contact NAP only, not a staffing service market.",
  },
  {
    q: "How do engagements start?",
    a: "Share the roles, timeline and constraints you are hiring against — or the consulting question you need answered. We reply with next steps after reviewing your enquiry.",
  },
  {
    q: "Do you guarantee placements or interview outcomes?",
    a: "No. We do not invent metrics or guarantee outcomes. We focus on professional process, clear communication and qualified shortlists.",
  },
];
