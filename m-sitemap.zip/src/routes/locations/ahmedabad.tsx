import { createFileRoute, redirect } from "@tanstack/react-router";

/** Ahmedabad is company contact NAP only — not a staffing service city. */
export const Route = createFileRoute("/locations/ahmedabad")({
  beforeLoad: () => {
    throw redirect({ to: "/services", replace: true });
  },
  component: () => null,
});
