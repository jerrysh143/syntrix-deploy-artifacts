import { createFileRoute, redirect } from "@tanstack/react-router";

/** Preferred A: retire India–USA staffing market page → USA staffing. */
export const Route = createFileRoute("/services/india-usa-staffing")({
  beforeLoad: () => {
    throw redirect({ to: "/staffing", replace: true });
  },
  component: () => null,
});
