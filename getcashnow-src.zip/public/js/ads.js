/**
 * Get Cash Now — Google Ads / gtag + Meta Pixel (env-gated).
 *
 * Hostinger / local env (public pixel IDs only — never invent live IDs):
 *   GOOGLE_TAG_ID=              # e.g. AW-XXXXXXXXX or G-XXXXXXXX
 *   GOOGLE_ADS_ID=              # alias for GOOGLE_TAG_ID
 *   GOOGLE_ADS_CONVERSION_SEND_TO=  # e.g. AW-XXX/conversionLabel
 *   GOOGLE_ADS_CONVERSION_ID=   # optional split form
 *   GOOGLE_ADS_CONVERSION_LABEL=
 *   META_PIXEL_ID=
 *
 * When IDs are empty: no third-party scripts, no network calls; trackLead() is a no-op.
 */
(function () {
  'use strict';

  var LEAD_FLAG = 'gcn_lead';
  var config = { googleTagId: '', googleAdsSendTo: '', metaPixelId: '' };
  var readyPromise = null;

  function loadExternalScript(src) {
    return new Promise(function (resolve, reject) {
      var s = document.createElement('script');
      s.async = true;
      s.src = src;
      s.onload = function () { resolve(); };
      s.onerror = function () { reject(new Error('script load failed')); };
      document.head.appendChild(s);
    });
  }

  function initGtag(id) {
    window.dataLayer = window.dataLayer || [];
    function gtag() {
      window.dataLayer.push(arguments);
    }
    window.gtag = gtag;
    gtag('js', new Date());
    gtag('config', id);
    return loadExternalScript(
      'https://www.googletagmanager.com/gtag/js?id=' + encodeURIComponent(id)
    ).catch(function () { /* no-op if blocked */ });
  }

  function initMeta(id) {
    if (window.fbq) {
      window.fbq('init', id);
      window.fbq('track', 'PageView');
      return Promise.resolve();
    }
    !(function (f, b, e, v, n, t, s) {
      if (f.fbq) return;
      n = f.fbq = function () {
        n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments);
      };
      if (!f._fbq) f._fbq = n;
      n.push = n;
      n.loaded = true;
      n.version = '2.0';
      n.queue = [];
      t = b.createElement(e);
      t.async = true;
      t.src = v;
      s = b.getElementsByTagName(e)[0];
      s.parentNode.insertBefore(t, s);
    })(window, document, 'script', 'https://connect.facebook.net/en_US/fbevents.js');
    window.fbq('init', id);
    window.fbq('track', 'PageView');
    return Promise.resolve();
  }

  function trackLeadOnce() {
    if (config.googleTagId && config.googleAdsSendTo && typeof window.gtag === 'function') {
      window.gtag('event', 'conversion', { send_to: config.googleAdsSendTo });
    }
    if (config.metaPixelId && typeof window.fbq === 'function') {
      window.fbq('track', 'Lead');
    }
  }

  function loadConfig() {
    return fetch('/api/ads-config', { credentials: 'same-origin' })
      .then(function (res) {
        return res.ok ? res.json() : {};
      })
      .then(function (data) {
        config = {
          googleTagId: (data && data.googleTagId) || '',
          googleAdsSendTo: (data && data.googleAdsSendTo) || '',
          metaPixelId: (data && data.metaPixelId) || '',
        };
        var jobs = [];
        if (config.googleTagId) jobs.push(initGtag(config.googleTagId));
        if (config.metaPixelId) jobs.push(initMeta(config.metaPixelId));
        return Promise.all(jobs);
      })
      .catch(function () {
        /* empty config / offline — stay no-op */
      });
  }

  function maybeFireDeferredLead() {
    try {
      if (sessionStorage.getItem(LEAD_FLAG) === '1') {
        sessionStorage.removeItem(LEAD_FLAG);
        trackLeadOnce();
      }
    } catch (e) {
      /* private mode etc. */
    }
  }

  readyPromise = loadConfig().then(function () {
    maybeFireDeferredLead();
  });

  window.GcnAds = {
    /**
     * Fire Lead / Ads conversion when IDs are configured; otherwise no-op.
     * Returns a Promise so callers can await before redirect.
     */
    trackLead: function () {
      return readyPromise.then(function () {
        var configured = !!(
          (config.googleTagId && config.googleAdsSendTo) || config.metaPixelId
        );
        if (!configured) return; // no IDs: no-op, leave flag (harmless)
        trackLeadOnce();
        // Fired here, so clear the flag to avoid a duplicate on /offers.
        try { sessionStorage.removeItem(LEAD_FLAG); } catch (e) { /* ignore */ }
        // Brief window for beacons to leave before navigation.
        return new Promise(function (r) { setTimeout(r, 400); });
      });
    },
    /** Mark successful submit so /offers can fire conversion once if needed. */
    markLeadForOffers: function () {
      try {
        sessionStorage.setItem(LEAD_FLAG, '1');
      } catch (e) {
        /* ignore */
      }
    },
  };
})();
