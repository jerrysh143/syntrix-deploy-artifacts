import { useState } from "react";
import { Section } from "./primitives";
import type { FaqItem } from "@/lib/seo-schema";

export function FaqSection({
  faqs,
  title = "FAQs",
  intro,
}: {
  faqs: FaqItem[];
  title?: string;
  intro?: string;
}) {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <Section id="faq">
      <div className="grid gap-12 lg:grid-cols-[minmax(0,0.8fr)_minmax(0,1.2fr)]">
        <div>
          <h2 className="display-lg">{title}</h2>
          {intro ? <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{intro}</p> : null}
        </div>
        <div>
          {faqs.map((f, i) => {
            const isOpen = open === i;
            return (
              <div key={f.q} className="border-b border-border">
                <h3>
                  <button
                    type="button"
                    aria-expanded={isOpen}
                    onClick={() => setOpen(isOpen ? null : i)}
                    className="flex w-full items-center justify-between gap-6 py-5 text-left font-display text-lg uppercase leading-tight"
                  >
                    {f.q}
                    <span aria-hidden="true" className="text-muted-foreground">
                      {isOpen ? "–" : "+"}
                    </span>
                  </button>
                </h3>
                {isOpen ? (
                  <p className="pb-5 text-sm leading-relaxed text-muted-foreground">{f.a}</p>
                ) : null}
              </div>
            );
          })}
        </div>
      </div>
    </Section>
  );
}
