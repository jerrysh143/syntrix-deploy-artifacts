import { createFileRoute } from "@tanstack/react-router";
import { HomePage } from "@/components/site/HomePage";

const title = "Syntrix Global | Consultancy & Staffing for Employers (India & USA)";
const description =
  "USA employer staffing, placement and talent consulting from Syntrix Global — San Antonio primary. Technology delivery when your engagement needs build work.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://syntrixglobal.in/" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/syntrixglobal-og-image.png" },
      { name: "twitter:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/syntrixglobal-og-image.png" },
    ],
    links: [{ rel: "canonical", href: "https://syntrixglobal.in/" }],
  }),
  component: () => <HomePage />,
});
