import { useSubmission, SubmissionFields } from "./SubmissionFields";
import { Link } from "@tanstack/react-router";
import { brand } from "@/lib/site-content";

const columns = [
  {
    title: "Company",
    links: [
      { label: "About", to: "/about" },
      { label: "Contact", to: "/contact" },
      { label: "Projects", to: "/work" },
      { label: "Request Staffing Support", to: "/start-project" },
    ],
  },
  {
    title: "Services",
    links: [
      { label: "Placement & Staffing", to: "/staffing" },
      { label: "Talent Consulting", to: "/talent-consulting" },
      { label: "Recruitment Support", to: "/services" },
      { label: "All Services", to: "/services" },
      { label: "Technology Services", to: "/services" },
    ],
  },
  {
    title: "Locations",
    links: [
      { label: "San Antonio (USA)", to: "/locations/san-antonio" },
    ],
  },
  {
    title: "Legal",
    links: [
      { label: "Privacy Policy", to: "/privacy" },
      { label: "Terms", to: "/terms" },
      { label: "Disclaimer", to: "/disclaimer" },
    ],
  },
];

export function SiteFooter() {
  const { sent, pending, error, submit } = useSubmission("newsletter");
  return (
    <footer className="dark bg-background text-foreground">
      <div className="mx-auto w-full max-w-[1400px] px-5 py-16 sm:px-8">
        <div className="border-b border-border pb-12 text-center">
          <Link to="/" aria-label="Syntrix Global home" className="inline-block">
            <img
              src="/syntrix-logo-light.svg"
              alt={brand.name}
              width="520"
              height="136"
              className="mx-auto h-auto w-[260px] max-w-full sm:w-[340px]"
            />
          </Link>
          <p className="mt-4 text-[10px] uppercase tracking-[0.18em] text-muted-foreground sm:text-xs">
            People · Consulting · Global Opportunities
          </p>
          <p className="label-xs mt-3 text-muted-foreground">
            USA staffing & consulting — San Antonio primary · India office for company contact.
          </p>
          <p className="label-xs mt-2 text-muted-foreground">{brand.locationLine}</p>
          <div className="mt-4 grid gap-4 text-left sm:mx-auto sm:max-w-md sm:grid-cols-2">
            {brand.offices.map((office) => (
              <address key={office.label} className="not-italic text-sm text-muted-foreground">
                <span className="label-xs block text-foreground/80">{office.label}</span>
                {office.lines.map((line) => (
                  <span key={line} className="mt-1 block">
                    {line}
                  </span>
                ))}
              </address>
            ))}
          </div>
          <a
            href="mailto:contact@syntrixglobal.in"
            className="mt-4 inline-block text-sm underline underline-offset-4"
          >
            contact@syntrixglobal.in
          </a>
          <p className="mt-4 text-sm text-muted-foreground">
            Looking for a career?{" "}
            <a
              href={brand.careersUrl}
              className="underline underline-offset-4 hover:text-foreground"
              rel="noopener noreferrer"
            >
              careers.syntrixglobal.in
            </a>
          </p>
        </div>

        <div className="grid gap-10 border-b border-border py-12 sm:grid-cols-2 lg:grid-cols-3">
          {columns.map((col) => (
            <div key={col.title}>
              <h3 className="label-xs text-muted-foreground">{col.title}</h3>
              <ul className="mt-4 space-y-2">
                {col.links.map((link) => (
                  <li key={link.label}>
                    <Link
                      to={link.to}
                      className="text-sm text-foreground/80 transition-colors hover:text-foreground"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="grid gap-8 py-12 md:grid-cols-[minmax(0,1fr)_auto] md:items-end">
          <div className="max-w-md">
            <h3 className="font-display text-2xl uppercase">Stay in Touch</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              Request occasional updates about our staffing and consulting services.
            </p>
            <form className="mt-5 flex flex-wrap gap-2" onSubmit={submit}>
              <label htmlFor="newsletter-email" className="sr-only">
                Email address
              </label>
              <input
                id="newsletter-email"
                name="email"
                type="email"
                required
                maxLength={255}
                placeholder="Your email address"
                className="min-w-0 flex-1 border border-border bg-transparent px-4 py-3 text-sm placeholder:text-muted-foreground"
              />
              <button type="submit" disabled={pending} className="bg-foreground px-5 py-3 label-xs text-background">
                Request updates
              </button>
              <SubmissionFields pending={pending} error={error} />
            </form>
            {sent && (
              <p role="status" className="mt-3 text-sm">
                Your request for email updates has been sent.
              </p>
            )}
          </div>
        </div>

        <p className="border-t border-border pt-8 text-center label-xs text-muted-foreground">
          © {new Date().getFullYear()} {brand.name}. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
