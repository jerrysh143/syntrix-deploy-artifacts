import { FeaturedProject } from "@/components/site/FeaturedProject";
import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { FaqSection } from "@/components/site/FaqSection";
import { CtaLink, Eyebrow, Section, SectionHeading } from "@/components/site/primitives";
import { itProcess, serviceGroups, servicesFaqs, staffingServices } from "@/lib/site-content";
import { faqPageJsonLd } from "@/lib/seo-schema";

const title = "Staffing, Placement & Talent Consulting | Syntrix Global";
const description =
  "Contract and permanent placement, talent consulting and recruitment support for employers — with software, AI and cloud when an engagement needs build work.";

const comparison = [
  {
    title: "Staffing",
    points: [
      "You already know the role (or have a draft brief)",
      "You need contract or permanent candidates shortlisted",
      "Outcome focus: qualified shortlists and placement support",
    ],
    to: "/staffing",
    cta: "Explore staffing",
  },
  {
    title: "Talent consulting",
    points: [
      "Roles or workforce plan still need definition",
      "You want hiring strategy or interview process design",
      "Outcome focus: clearer briefs and hiring process",
    ],
    to: "/talent-consulting",
    cta: "Explore consulting",
  },
];

export const Route = createFileRoute("/services/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://syntrixglobal.in/services" },
      { name: "twitter:card", content: "summary_large_image" },
      {
        property: "og:image",
        content:
          "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/syntrixglobal-og-image.png",
      },
      {
        name: "twitter:image",
        content:
          "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/syntrixglobal-og-image.png",
      },
    ],
    links: [{ rel: "canonical", href: "https://syntrixglobal.in/services" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify(faqPageJsonLd(servicesFaqs)),
      },
    ],
  }),
  component: ServicesPage,
});

function ServicesPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />

      <Section>
        <SectionHeading
          as="h1"
          eyebrow="Staffing & Consulting"
          title="Staffing & Consulting for Employers"
          intro="Primary offerings for USA employers: placement, talent consulting and recruitment. Technology services are grouped second for engagements that also need build work."
        />
        <div className="mt-10">
          <FeaturedProject />
        </div>

        <div className="mt-14">
          <SectionHeading
            eyebrow="Compare"
            title="Staffing vs consulting — which engagement"
            intro="Pick staffing when you need people placed. Pick consulting when you need role and process clarity first. Many employers use both."
          />
          <div className="mt-10 grid gap-px border border-border bg-border md:grid-cols-2">
            {comparison.map((col) => (
              <article key={col.title} className="bg-background p-8">
                <Eyebrow>{col.title}</Eyebrow>
                <ul className="mt-6 space-y-3 text-sm leading-relaxed text-muted-foreground">
                  {col.points.map((pt) => (
                    <li key={pt}>— {pt}</li>
                  ))}
                </ul>
                <div className="mt-8">
                  <CtaLink to={col.to} variant="outline">
                    {col.cta}
                  </CtaLink>
                </div>
              </article>
            ))}
          </div>
        </div>

        <div className="mt-14">
          <SectionHeading
            eyebrow="Employer outcomes"
            title="What staffing support delivers"
            intro="Staffing work is framed around employer outcomes — clearer briefs, usable shortlists and coordinated interviews — not invented placement metrics."
          />
          <div className="mt-10 grid gap-px border border-border bg-border sm:grid-cols-3">
            {staffingServices.map((s) => (
              <article key={s.title} className="bg-background p-8">
                <Eyebrow>{s.no}</Eyebrow>
                <h3 className="mt-4 font-display text-xl uppercase">{s.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{s.desc}</p>
              </article>
            ))}
          </div>
        </div>

        <div className="mt-14 grid gap-10">
          {serviceGroups.map((group) => (
            <div key={group.no} className="border border-border">
              <div className="border-b border-border bg-background p-8">
                <Eyebrow>{group.no}</Eyebrow>
                <h2 className="mt-4 font-display text-3xl uppercase">{group.title}</h2>
                <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted-foreground">{group.desc}</p>
                {group.no === "02" ? (
                  <p className="mt-3 max-w-2xl text-sm font-medium text-muted-foreground">
                    Technology services stay secondary — available when an engagement also needs build work.
                  </p>
                ) : null}
                <div className="mt-6">
                  <CtaLink to={group.ctaTo} variant="outline">
                    {group.ctaLabel}
                  </CtaLink>
                </div>
              </div>
              <div className="grid gap-px bg-border sm:grid-cols-2 lg:grid-cols-3">
                {group.services.map((s) => (
                  <article key={s.title} className="bg-background p-8">
                    <Eyebrow>{s.no}</Eyebrow>
                    <h3 className="mt-4 font-display text-xl uppercase">{s.title}</h3>
                    <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{s.desc}</p>
                  </article>
                ))}
              </div>
            </div>
          ))}
        </div>
      </Section>

      <Section>
        <SectionHeading eyebrow="Process" title="How We Engage" />
        <ol className="mt-12 grid gap-px border border-border bg-border sm:grid-cols-2 lg:grid-cols-3">
          {itProcess.map((p) => (
            <li key={p.no} className="bg-background p-8">
              <Eyebrow>{p.no}</Eyebrow>
              <p className="mt-4 font-display text-2xl uppercase">{p.title}</p>
            </li>
          ))}
        </ol>
        <div className="mt-12 flex flex-wrap gap-3">
          <CtaLink to="/start-project">Request Staffing Support</CtaLink>
          <CtaLink to="/staffing" variant="outline">
            IT Staffing
          </CtaLink>
          <CtaLink to="/talent-consulting" variant="outline">
            Talent Consulting
          </CtaLink>
          <CtaLink to="/work" variant="outline">
            View Projects
          </CtaLink>
        </div>
      </Section>

      <FaqSection
        faqs={servicesFaqs}
        intro="Honest answers about choosing staffing, consulting or supporting technology services."
      />

      <SiteFooter />
    </div>
  );
}
