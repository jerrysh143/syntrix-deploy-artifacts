export type FaqItem = { q: string; a: string };

export function faqPageJsonLd(faqs: FaqItem[]) {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((f) => ({
      "@type": "Question",
      name: f.q,
      acceptedAnswer: {
        "@type": "Answer",
        text: f.a,
      },
    })),
  };
}

export function professionalServiceJsonLd(opts: {
  name: string;
  url: string;
  description: string;
  areaServed?: Array<{ "@type": string; name: string }>;
}) {
  return {
    "@context": "https://schema.org",
    "@type": "ProfessionalService",
    name: opts.name,
    url: opts.url,
    description: opts.description,
    areaServed: opts.areaServed ?? [
      { "@type": "Country", name: "United States" },
    ],
    provider: {
      "@type": "Organization",
      name: "Syntrix Global",
      url: "https://syntrixglobal.in",
    },
  };
}
