import { FeaturedProject } from "./FeaturedProject";
import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { SiteHeader } from "./SiteHeader";
import { SiteFooter } from "./SiteFooter";
import { CtaLink, Eyebrow, Marquee, Section, SectionHeading } from "./primitives";
import { brand, itFaqs, itIndustries, itProcess, serviceGroups, work } from "@/lib/site-content";
import techTeam from "@/assets/tech-team-branded.jpg";
import aiAbstract from "@/assets/ai-abstract-branded.jpg";
import analytics from "@/assets/analytics-branded.jpg";

const heroCards = [
  { no: "01", a: "Staffing &", b: "Placement" },
  { no: "02", a: "Talent", b: "Consulting" },
  { no: "03", a: "Recruitment", b: "Support" },
];

function Hero() {
  return (
    <section className="border-b border-border">
      <div className="mx-auto w-full max-w-[1400px] px-5 pt-14 pb-20 sm:px-8">
        <div className="grid gap-10 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)] lg:items-start">
          <div className="fade-up">
            <h1 className="display-xl">
              Hire Talent.
              <br />
              Build Teams.
              <br />
              Grow With Clarity.
            </h1>
            <p className="mt-6 max-w-md text-lg leading-relaxed text-muted-foreground">
              Syntrix Global is a consultancy and staffing firm — recruitment, placement and
              talent consulting for employers, with technology services available when you need
              them.
            </p>
            <p className="label-xs mt-6 text-foreground">Staffing. Consulting. Placement. Technology support.</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <CtaLink to="/start-project">Hire Talent</CtaLink>
              <CtaLink to="/contact" variant="outline">
                Talk to a Consultant
              </CtaLink>
              <a
                href="#services"
                className="group inline-flex items-center gap-3 border border-border px-6 py-4 label-xs transition-colors hover:bg-foreground hover:text-background"
              >
                Explore Staffing Services
                <span aria-hidden="true" className="transition-transform group-hover:translate-x-1">
                  →
                </span>
              </a>
            </div>
            <p className="mt-6 text-sm text-muted-foreground">
              Looking for a career or featured USA roles?{" "}
              <a
                href={brand.careersJobsUrl}
                className="underline underline-offset-4 transition-colors hover:text-foreground"
                rel="noopener noreferrer"
              >
                careers.syntrixglobal.in/jobs
              </a>
            </p>
          </div>

          <div className="relative">
            <img
              src={techTeam}
              alt="Professional team collaborating in a modern office"
              width={1200}
              height={912}
              className="aspect-4/3 w-full border border-border object-cover"
            />
            <div className="mt-6 grid gap-px bg-border sm:grid-cols-3">
              {heroCards.map((c) => (
                <article
                  key={c.no}
                  className="group bg-background p-5 transition-colors hover:bg-foreground hover:text-background"
                >
                  <Eyebrow>{c.no}</Eyebrow>
                  <h2 className="mt-6 font-display text-lg leading-tight uppercase">
                    {c.a}
                    <br />
                    {c.b}
                  </h2>
                  <Link to="/services" className="mt-6 inline-block text-sm underline">
                    Explore services →
                  </Link>
                </article>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function About() {
  return (
    <section className="dark border-b border-border bg-background text-foreground">
      <Marquee items={["Staffing", "Consulting", "Recruitment", "Placement", "Technology", "Partnership"]} />
      <div id="about" className="mx-auto w-full max-w-[1400px] px-5 py-20 sm:px-8 md:py-28">
        <div className="grid gap-12 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.2fr)]">
          <div>
            <Eyebrow>About</Eyebrow>
            <h2 className="display-lg mt-4">
              Consultancy
              <br />
              &amp; Staffing
              <br />
              First.
            </h2>
            <p className="mt-6 max-w-sm text-base leading-relaxed text-muted-foreground">
              We help USA employers find and place talent, and advise on hiring strategy — with San
              Antonio as our primary USA presence. Software, AI and cloud remain available as
              supporting offerings.
            </p>
            <div className="mt-8">
              <CtaLink to="/contact" variant="outline">
                Start a Conversation
              </CtaLink>
            </div>
          </div>
          <img
            src={aiAbstract}
            alt="Abstract professional network visual"
            loading="lazy"
            width={1200}
            height={912}
            className="aspect-16/10 w-full border border-border object-cover"
          />
        </div>
        <p className="mt-14 max-w-4xl font-display text-xl uppercase leading-tight md:text-3xl">
          Professional staffing and consulting — without invented metrics or guarantees
        </p>
      </div>
    </section>
  );
}

function Services() {
  return (
    <Section id="services">
      <SectionHeading
        eyebrow="What we do"
        title="Staffing & Consulting"
        intro="Primary focus: placement, talent consulting and recruitment. Technology services follow when an engagement needs build work."
      />
      <div className="mt-12 grid gap-px bg-border lg:grid-cols-2">
        {serviceGroups.map((group) => (
          <article
            key={group.no}
            className="group flex min-h-56 flex-col justify-between bg-background p-8 transition-colors duration-300 hover:bg-foreground hover:text-background"
          >
            <div>
              <Eyebrow>{group.no}</Eyebrow>
              <h3 className="mt-6 font-display text-3xl leading-tight uppercase">{group.title}</h3>
              <p className="mt-3 text-sm text-muted-foreground group-hover:text-background/70">{group.desc}</p>
              <ul className="mt-6 space-y-2">
                {group.services.map((s) => (
                  <li key={s.title} className="text-sm border-b border-border py-2 group-hover:border-background/20">
                    {s.title}
                  </li>
                ))}
              </ul>
            </div>
            <Link to={group.ctaTo} className="mt-8 inline-block text-sm underline">
              {group.ctaLabel} →
            </Link>
          </article>
        ))}
      </div>
    </Section>
  );
}

const supportCapabilities = [
  "Contract staffing",
  "Permanent placement",
  "Role definition",
  "Workforce planning",
  "Candidate screening",
  "Interview coordination",
  "Hiring process design",
  "Technology delivery support",
];

function Feature() {
  return (
    <section className="dark border-b border-border bg-background text-foreground">
      <div className="mx-auto grid w-full max-w-[1400px] gap-12 px-5 py-20 sm:px-8 md:py-28 lg:grid-cols-2 lg:items-center">
        <div>
          <Eyebrow>How we work</Eyebrow>
          <h2 className="display-lg mt-4">
            Clear Process.
            <br />
            Honest Scope.
            <br />
            No Invented Proof.
          </h2>
          <ul className="mt-8 grid grid-cols-2 gap-x-6 gap-y-2 text-sm text-muted-foreground">
            {supportCapabilities.map((i) => (
              <li key={i} className="border-b border-border py-2">
                {i}
              </li>
            ))}
          </ul>
          <p className="mt-6 max-w-md text-sm text-muted-foreground">
            We describe what we do and how we work — not fabricated testimonials, guarantees or vanity metrics.
          </p>
          <div className="mt-8">
            <CtaLink to="/contact" variant="outline">
              Talk to a Consultant
            </CtaLink>
          </div>
        </div>
        <img
          src={aiAbstract}
          alt="Abstract dark professional form"
          loading="lazy"
          width={1200}
          height={912}
          className="aspect-square w-full border border-border object-cover"
        />
      </div>
    </section>
  );
}

function Industries() {
  return (
    <Section id="industries">
      <SectionHeading
        eyebrow="Coverage"
        title="Industries"
        intro="Hiring and consulting context varies by domain — we adapt role briefs and sourcing to your industry."
      />
      <div className="-mx-5 mt-12 overflow-x-auto px-5 sm:-mx-8 sm:px-8">
        <ul className="flex w-max gap-px bg-border">
          {itIndustries.map((ind, i) => (
            <li key={ind} className="w-56 bg-background p-6">
              <Eyebrow>{String(i + 1).padStart(2, "0")}</Eyebrow>
              <p className="mt-10 font-display text-lg uppercase leading-tight">{ind}</p>
            </li>
          ))}
        </ul>
      </div>
    </Section>
  );
}

function Process() {
  return (
    <Section id="process">
      <SectionHeading
        eyebrow="Process"
        title={
          <>
            How We
            <br />
            Engage.
          </>
        }
      />
      <ol className="mt-12 grid gap-px bg-border sm:grid-cols-2 lg:grid-cols-3">
        {itProcess.map((s) => (
          <li key={s.no} className="bg-background p-6">
            <Eyebrow>{s.no}</Eyebrow>
            <p className="mt-10 font-display text-xl uppercase leading-tight">{s.title}</p>
          </li>
        ))}
      </ol>
    </Section>
  );
}

function Work() {
  return (
    <Section id="work">
      <SectionHeading
        eyebrow="Projects and capabilities"
        title="Work & Capabilities"
        intro="Staffing and consulting engagements lead; technology solution areas remain available when needed."
      />
      <div className="mt-10">
        <FeaturedProject />
      </div>
      <h3 className="mt-10 font-display text-2xl uppercase">Engagement areas</h3>
      <div className="mt-6 grid gap-px bg-border sm:grid-cols-2 lg:grid-cols-3">
        {work.map((p) => (
          <article
            key={p.title}
            className="group bg-background p-6 transition-colors hover:bg-foreground hover:text-background"
          >
            <Eyebrow>{p.tag}</Eyebrow>
            <h3 className="mt-10 font-display text-2xl uppercase leading-tight">{p.title}</h3>
            <p className="mt-4 text-sm text-muted-foreground">{p.desc}</p>
            <Link to="/start-project" className="mt-6 inline-block text-sm underline">
              Discuss this requirement →
            </Link>
          </article>
        ))}
      </div>
    </Section>
  );
}

function Faq() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <Section id="faq">
      <div className="grid gap-12 lg:grid-cols-[minmax(0,0.8fr)_minmax(0,1.2fr)]">
        <div>
          <h2 className="display-lg">FAQs</h2>
          <img
            src={analytics}
            alt="Laptop showing professional dashboards"
            loading="lazy"
            width={1200}
            height={912}
            className="mt-8 aspect-3/4 w-full border border-border object-cover"
          />
        </div>
        <div>
          {itFaqs.map((f, i) => {
            const isOpen = open === i;
            return (
              <div key={f.q} className="border-b border-border">
                <h3>
                  <button
                    type="button"
                    aria-expanded={isOpen}
                    onClick={() => setOpen(isOpen ? null : i)}
                    className="flex w-full items-center justify-between gap-6 py-5 text-left font-display text-lg uppercase leading-tight"
                  >
                    {f.q}
                    <span aria-hidden="true" className="text-muted-foreground">
                      {isOpen ? "–" : "+"}
                    </span>
                  </button>
                </h3>
                {isOpen ? (
                  <p className="pb-5 text-sm leading-relaxed text-muted-foreground">{f.a}</p>
                ) : null}
              </div>
            );
          })}
        </div>
      </div>
    </Section>
  );
}


function UsaRolesTeaser() {
  return (
    <section id="usa-roles" className="dark border-b border-border bg-background text-foreground">
      <div className="mx-auto w-full max-w-[1400px] px-5 py-16 sm:px-8 md:py-20">
        <div className="grid gap-8 rounded-2xl border border-border bg-card/30 p-6 sm:p-8 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)] lg:items-center">
          <div>
            <Eyebrow>Featured USA opportunities</Eyebrow>
            <h2 className="mt-4 font-display text-3xl uppercase leading-tight md:text-4xl">
              Hiring or exploring USA roles?
            </h2>
            <p className="mt-4 max-w-xl text-sm leading-relaxed text-muted-foreground md:text-base">
              Employers: engage us for USA staffing and placement support. Candidates exploring
              featured USA opportunities can review sample open roles on our careers site — not a
              live ATS feed, and placement is never guaranteed.
            </p>
          </div>
          <div className="flex flex-wrap gap-3 lg:justify-end">
            <Link
              to="/start-project"
              className="inline-flex items-center gap-3 rounded-full bg-primary px-6 py-4 label-xs text-primary-foreground transition-colors hover:bg-primary/90"
            >
              Hire for USA roles →
            </Link>
            <a
              href={brand.careersJobsUrl}
              className="inline-flex items-center gap-3 rounded-full border border-border px-6 py-4 label-xs transition-colors hover:bg-foreground hover:text-background"
              rel="noopener noreferrer"
            >
              View featured USA roles →
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

function FinalCta() {
  return (
    <section className="dark bg-background text-foreground">
      <div className="mx-auto w-full max-w-[1400px] px-5 py-24 sm:px-8">
        <h2 className="display-xl">
          Start a
          <br />
          Conversation.
        </h2>
        <div className="mt-10 flex flex-wrap gap-3">
          <Link
            to="/start-project"
            className="group inline-flex items-center gap-4 bg-foreground px-8 py-5 label-xs text-background transition-colors hover:bg-accent hover:text-accent-foreground"
          >
            Request Staffing Support
            <span aria-hidden="true" className="transition-transform group-hover:translate-x-1">
              →
            </span>
          </Link>
          <Link
            to="/contact"
            className="group inline-flex items-center gap-4 border border-border px-8 py-5 label-xs transition-colors hover:bg-foreground hover:text-background"
          >
            Talk to a Consultant
          </Link>
        </div>
      </div>
    </section>
  );
}

export function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main>
        <Hero />
        <About />
        <Services />
        <Feature />
        <Industries />
        <Process />
        <Work />
        <Faq />
        <UsaRolesTeaser />
        <FinalCta />
      </main>
      <SiteFooter />
      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background p-3 md:hidden">
        <Link to="/start-project" className="block bg-ink px-5 py-4 text-center label-xs text-ivory">
          Hire Talent
        </Link>
      </div>
    </div>
  );
}
