export const brand = {
  name: "Syntrix Global",
  tagline: "U.S. Placements & Career Support",
  mainUrl: "https://syntrixglobal.in",
  addressLines: [
    "12370 Potranco Rd",
    "Ste 207",
    "San Antonio, TX 78253",
    "United States",
  ],
};

export const nav = [
  { label: "Home", to: "/" },
  { label: "About", to: "/about" },
  { label: "Career Services", to: "/career-services" },
  { label: "Open Roles", to: "/jobs" },
  { label: "Contact", to: "/contact" },
];

export const careerServices = [
  { no: "01", title: "U.S. Placements", desc: "Placement assistance across the United States, from search to offer." },
  { no: "02", title: "OPT / STEM OPT Career Support", desc: "Specialized guidance for international graduates on OPT and STEM OPT pathways." },
  { no: "03", title: "Recruitment & Staffing", desc: "Healthcare and IT staffing, supporting candidate sourcing and role matching." },
  { no: "04", title: "Resume Marketing", desc: "ATS-ready resumes marketed to recruiters and hiring managers." },
  { no: "05", title: "Interview Support", desc: "Mock interviews, technical guidance and behavioral preparation with feedback." },
  { no: "06", title: "Career Consultation", desc: "One-to-one guidance shaped around your profile and goals." },
  { no: "07", title: "LinkedIn Optimization", desc: "A clearer profile that presents your experience, skills and target roles." },
  { no: "08", title: "Recruiter Outreach", desc: "Planning relevant recruiter contacts and professional outreach." },
  { no: "09", title: "Job Search Support", desc: "Search strategy, targeting and application planning." },
  { no: "10", title: "Professional Branding", desc: "A consistent, credible professional narrative." },
];

export const careerIndustries = [
  "Information Technology",
  "Software Engineering",
  "Data Analytics",
  "Data Science",
  "AI / Machine Learning",
  "Business Analysis",
  "Cybersecurity",
  "Cloud & DevOps",
  "Healthcare",
  "Clinical Research",
  "Pharmaceutical",
  "EHR",
  "Public Health",
  "Biotechnology",
  "Engineering",
  "Other Professional Roles",
];

export const careerProcess = [
  { no: "01", title: "Initial Consultation" },
  { no: "02", title: "Profile Assessment" },
  { no: "03", title: "Career Strategy" },
  { no: "04", title: "Resume & LinkedIn" },
  { no: "05", title: "Interview Preparation" },
  { no: "06", title: "Recruiter Outreach" },
  { no: "07", title: "Application Support" },
  { no: "08", title: "Ongoing Guidance" },
];

export const candidateTypes = [
  "Recent Graduates",
  "International Graduates",
  "Experienced Professionals",
  "Career Switchers",
  "Technology Professionals",
  "Healthcare Professionals",
];

export const candidateJourneys = [
  { title: "Graduate Data Career Planning", tag: "Data", desc: "Identify entry-level roles and present coursework, projects and analytical skills clearly." },
  { title: "Cloud Career Transition Planning", tag: "Cloud", desc: "Map transferable skills, identify learning priorities and prepare a focused cloud-role profile." },
  { title: "Clinical Research Positioning", tag: "Healthcare", desc: "Organize relevant qualifications and experience for clinical-research applications." },
  { title: "Software Engineer Interview Prep", tag: "Engineering", desc: "Practice technical explanations, project discussions and behavioral interview questions." },
  { title: "Business Analyst Profile Reset", tag: "Business", desc: "Highlight requirements gathering, stakeholder communication and business problem-solving." },
  { title: "Cybersecurity Job Search Plan", tag: "Security", desc: "Define target roles and organize a practical application and interview-preparation plan." },
];

export const careerFaqs = [
  { q: "Who can use your career services?", a: "Graduates and professionals pursuing roles across the United States, in both technology and non-technology fields." },
  { q: "Do you work with recent graduates?", a: "Yes. Graduate career support is a core part of what we do, including first-role positioning." },
  { q: "Which industries do you support?", a: "IT, software, data, AI, cybersecurity, cloud, healthcare, clinical research, pharma, public health and other professional roles." },
  { q: "How does your career consultation work?", a: "We assess your profile, define a target role, then build a roadmap covering positioning, preparation and search execution." },
  { q: "Do you provide resume support?", a: "Yes — resume optimization, LinkedIn positioning and professional branding." },
  { q: "Do you guarantee job placement?", a: "We provide professional career consulting, job-search support and placement assistance. Employment decisions are made by employers, so job placement cannot be guaranteed." },
  { q: "How does recruiter outreach work?", a: "We help prepare your profile and plan outreach to recruiters relevant to your target role." },
  { q: "Do you help with interview preparation?", a: "Yes — mock interviews, technical guidance and behavioral preparation with feedback." },
];


/** Featured / example USA roles — not a live ATS feed. */
export const featuredJobsNote =
  "Featured opportunities — examples of USA roles Syntrix commonly supports. This is not a live job board; openings change and placement is never guaranteed.";

export const featuredJobs = [
  {
    title: "Software Engineer",
    location: "Remote / USA",
    type: "Full-time",
    blurb: "Build and ship product features with modern stacks. Strong fundamentals and clear communication matter more than a single framework.",
    ctaTo: "/start-consultation" as const,
    ctaLabel: "Discuss this role",
  },
  {
    title: "Data Analyst",
    location: "USA",
    type: "Full-time",
    blurb: "Turn data into decisions — SQL, dashboards and stakeholder storytelling for product, ops or business teams.",
    ctaTo: "/start-consultation" as const,
    ctaLabel: "Discuss this role",
  },
  {
    title: "Cloud / DevOps Engineer",
    location: "USA",
    type: "Full-time / Contract",
    blurb: "Own cloud infrastructure, CI/CD and reliability. AWS, Azure or GCP experience with automation-minded delivery.",
    ctaTo: "/start-consultation" as const,
    ctaLabel: "Discuss this role",
  },
  {
    title: "Healthcare IT / EHR Analyst",
    location: "USA",
    type: "Full-time",
    blurb: "Support EHR workflows, implementations and clinical-ops tooling. Familiarity with major EHR platforms is a plus.",
    ctaTo: "/contact" as const,
    ctaLabel: "Apply / Discuss",
  },
  {
    title: "Business Analyst",
    location: "USA",
    type: "Full-time",
    blurb: "Bridge stakeholders and delivery teams — requirements, process mapping and clear acceptance criteria.",
    ctaTo: "/start-consultation" as const,
    ctaLabel: "Discuss this role",
  },
  {
    title: "Cybersecurity Analyst",
    location: "USA",
    type: "Full-time",
    blurb: "Monitor, assess and strengthen security posture. Practical risk thinking and clear incident communication.",
    ctaTo: "/start-consultation" as const,
    ctaLabel: "Discuss this role",
  },
];

export const disclaimer =
  "Employment outcomes depend on individual qualifications, market conditions, employer requirements and candidate performance. Our services provide career consulting and placement assistance and do not guarantee employment.";
