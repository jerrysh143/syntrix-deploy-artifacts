# Get Cash Now — Lead Funnel Site

Production Node.js / Express app for **getcashnow.cc**: USA personal loan lead marketplace (not a lender), short apply form, thank-you page, legal/content pages, and a secure admin dashboard.

## Stack

- Express (Node >= 18)
- `express-session` + `bcryptjs` (pure JS) admin auth
- File-based storage in `data/` (`leads.json`, `admin.json`) with atomic writes
- `helmet`, `express-rate-limit`, `uuid`
- Static marketing pages in `public/`

## Pages

| Path | Purpose |
|------|---------|
| `/` | Hero + short form (first, last, ZIP, phone + consents) |
| `/how-it-works` | 3-step process + eligibility |
| `/offers` | Post-submit landing: partner / advertiser disclosure, APR / repayment / example slots |
| `/rates-fees` | APR range education (~10%–36% with caveats) |
| `/disclosure` | Referral / advertising disclosure ( `/disclaimer` → 301 here) |
| `/privacy` `/terms` `/e-consent` | Legal + electronic records consent |
| `/thank-you` | Post-submit confirmation |
| `/admin` | Secure lead dashboard |

## Environment variables

| Variable | Required | Description |
|----------|----------|-------------|
| `PORT` | No | Listen port (default `3000`) |
| `SESSION_SECRET` | **Yes** | Long random string for session cookies (min 16 chars) |
| `ADMIN_USER` | No | Admin username on first boot (default `admin`) |
| `ADMIN_PASSWORD` | **Yes** on first boot | Plain password used once to create `data/admin.json` hash |
| `NODE_ENV` | No | Set `production` on Hostinger for secure cookies |

| `GOOGLE_TAG_ID` | No | Google tag ID (`AW-XXXXXXXXX` or `G-XXXXXXXX`). `GOOGLE_ADS_ID` accepted as alias. Empty = gtag not loaded |
| `GOOGLE_ADS_CONVERSION_SEND_TO` | No | Ads conversion target `AW-XXXXXXXXX/label`. Alternatively `GOOGLE_ADS_CONVERSION_ID` + `GOOGLE_ADS_CONVERSION_LABEL` |
| `META_PIXEL_ID` | No | Meta Pixel ID. Empty = Pixel not loaded |

Copy `.env.example` and fill values for local use (do not commit `.env`).

## Ads / pixel tracking

- Env IDs (public pixel IDs only; leave empty until real IDs exist, never invent them): `GOOGLE_TAG_ID` (alias `GOOGLE_ADS_ID`), `GOOGLE_ADS_CONVERSION_SEND_TO` (or `GOOGLE_ADS_CONVERSION_ID` + `GOOGLE_ADS_CONVERSION_LABEL`), `META_PIXEL_ID`.
- `public/js/ads.js` is inlined into every public page (not `/admin`) together with the env IDs. With empty IDs it makes **no** third-party requests and `GcnAds.trackLead()` is a no-op.
- With IDs: Google tag `config` and Meta `PageView` fire on page load.
- **Conversions:** the Google Ads `conversion` (`send_to`) and Meta `Lead` fire **only** in `public/js/main.js`, after `POST /api/leads` returns `ok` and before the redirect to `/offers`. Nothing fires on `/offers` page load; that page is publicly linked.
- Meta automatic configuration is turned off (`fbq('set','autoConfig',false,id)`). Also switch off *Automatic advanced matching* in Meta Events Manager so the Pixel never reads form fields.
- `GET /api/ads-config` returns the same public IDs (fallback when not inlined).
- **CSP:** third-party hosts live in the single `CSP_ALLOW` object at the top of `server.js` (`script`, `connect`, `img`, `frame`). Add new Google Ads / Meta domains there. Inline scripts are allowed through automatic sha256 hashes, not `unsafe-inline`.

**Setting IDs on Hostinger:** use `hosting_replaceNode_jsEnvironmentVariablesV1`. It is a **full replace**, so send the complete set (`NODE_ENV`, `SESSION_SECRET`, `ADMIN_USER`, `ADMIN_PASSWORD` with their real values, plus the ad keys). Listing env returns masked values that must never be copied back. Rebuild or restart the Node app after changing env.

## Compliance figures (Google US personal loans / Meta financial products)

All figures and business details live in **one file: `config/compliance.json`** (committed, all empty by default). Fill in real values from Jerry / the lending partners only, commit, and redeploy. Nothing else needs editing.

| Field | Type | Shown on | Notes |
|-------|------|----------|-------|
| `maxApr` | number (percent, e.g. `35.99`) | `/rates-fees`, `/offers` ("Maximum APR" box) | Required by Google for US personal-loan ads |
| `minApr` | number | same box ("APRs range from … to …") | Optional; only shown when `maxApr` is also set |
| `minRepaymentDays` | number (days) | "Repayment period" box | **Must be 61 or more** (Google disallows ads for loans repayable in 60 days or less); **ideally 91+**. The server logs a warning at boot if it is under 61 |
| `maxRepaymentMonths` | number (months) | "Repayment period" box | Box appears only when both repayment fields are set |
| `representativeExample.amount` | number (USD) | "Representative example" box | Box appears only when **all six** example fields are set |
| `representativeExample.termMonths` | number | 〃 | |
| `representativeExample.apr` | number (percent) | 〃 | |
| `representativeExample.monthlyPayment` | number (USD) | 〃 | |
| `representativeExample.totalRepaid` | number (USD) | 〃 | |
| `representativeExample.totalCost` | number (USD; interest + fees) | 〃 | |
| `businessContact.legalName` | string | footer on every public page, `/privacy` Contact | Contact block appears when any contact field is set; each line appears only if filled |
| `businessContact.address` | string | 〃 | |
| `businessContact.email` | string | 〃 (mailto link) | |
| `businessContact.phone` | string | 〃 (tel link) | |

How it works: pages are rendered on the server at boot (`lib/site-info.js`). Blocks are wrapped in `<!--slot-block:NAME--> … <!--/slot-block:NAME-->` with `<span data-slot="field"></span>` value spans. When a block's values are empty the whole block is **removed** from the HTML (it also carries `hidden` as a safety net), so the public never sees placeholder text. Raw `*.html` URLs redirect to the clean routes so they cannot bypass rendering. `GET /api/site-info` returns the current values (all `null` until filled). Numbers are formatted automatically (`%`, `$`); strings are shown as written.

## Local run

```bash
npm install
export SESSION_SECRET='your-long-random-secret'
export ADMIN_PASSWORD='your-strong-password'
# optional: export ADMIN_USER=admin
# optional: export NODE_ENV=development
npm start
```

App listens on `0.0.0.0:$PORT`.

- Public site: http://localhost:3000/
- Admin: http://localhost:3000/admin

On first boot, if `data/admin.json` is missing, the server hashes `ADMIN_PASSWORD` and stores it. Later boots reuse the stored hash (changing the env password alone will not rotate it — update `data/admin.json` or delete it to re-bootstrap).

## Lead form (v1)

- First name, last name, ZIP, phone
- Privacy/Terms/E-Consent acknowledgment + TCPA-style contact consent
- `POST /api/leads` (rate-limited)

## Admin features

- Session login (httpOnly cookie; `secure` when `NODE_ENV=production`)
- Lead list with search + status filter
- Detail drawer: status (`new` / `contacted` / `qualified` / `rejected`) + notes
- CSV export: `/api/admin/export.csv`
- Public form POST rate-limited; `/admin` not listed in robots

## Deploy (Hostinger Node)

1. Upload source (or deploy zip) — **exclude** `node_modules`, `data/*.json`, `.git`
2. Set env: `PORT`, `SESSION_SECRET`, `ADMIN_PASSWORD`, `NODE_ENV=production`, optional `ADMIN_USER`
3. `npm install --omit=dev` then `npm start` (or Hostinger’s Node start command pointing at `server.js`)
4. Ensure the app binds to the platform `PORT` (already handled)

## API (summary)

- `POST /api/leads` — public lead capture
- `POST /api/admin/login` · `POST /api/admin/logout` · `GET /api/admin/me`
- `GET /api/admin/leads` · `GET /api/admin/leads/:id` · `PATCH /api/admin/leads/:id`
- `GET /api/admin/export.csv`

## Legal note

Site copy states clearly that Get Cash Now is **not a lender**, does **not** guarantee approval, and that “as soon as one business day” funding is **conditional** on lender approval.
