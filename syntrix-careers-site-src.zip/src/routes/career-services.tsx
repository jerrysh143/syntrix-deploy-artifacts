import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { CtaLink, Eyebrow, Section, SectionHeading } from "@/components/site/primitives";
import { candidateTypes, careerProcess, careerServices, disclaimer } from "@/lib/site-content";

const title = "Career Services: Resume, Interview & Placement | Syntrix Global";
const description =
  "Structured USA career support — placements, OPT/STEM OPT guidance, resume marketing, interview prep, LinkedIn and recruiter outreach. Personalized; employment not guaranteed.";

export const Route = createFileRoute("/career-services")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://careers.syntrixglobal.in/career-services" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/careers-syntrixglobal-og-image.png" },
      { name: "twitter:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/careers-syntrixglobal-og-image.png" },
    ],
    links: [{ rel: "canonical", href: "https://careers.syntrixglobal.in/career-services" }],
  }),
  component: CareerServicesPage,
});

function CareerServicesPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />

      <Section>
        <SectionHeading as="h1"
          eyebrow="Career Consultancy"
          title="Career Services for USA Job Seekers"
          intro="From first positioning to final offer conversations — structured, personal guidance for graduates and experienced professionals across the United States."
        />
        <div className="mt-14 grid gap-px border border-border bg-border sm:grid-cols-2 lg:grid-cols-3">
          {careerServices.map((s) => (
            <article key={s.no} className="group bg-background p-8">
              <div className="flex items-start justify-between gap-4">
                <Eyebrow>{s.no}</Eyebrow>
                
              </div>
              <h2 className="mt-6 font-display text-2xl uppercase">{s.title}</h2>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{s.desc}</p>
              <div className="mt-6"><CtaLink to="/start-consultation" variant="outline">Discuss this service</CtaLink></div>
            </article>
          ))}
        </div>
      </Section>

      <Section>
        <SectionHeading eyebrow="Journey" title="Your Roadmap" />
        <ol className="mt-12 grid gap-px border border-border bg-border sm:grid-cols-2 lg:grid-cols-4">
          {careerProcess.map((p) => (
            <li key={p.no} className="bg-background p-8">
              <Eyebrow>{p.no}</Eyebrow>
              <p className="mt-4 font-display text-xl uppercase">{p.title}</p>
            </li>
          ))}
        </ol>
      </Section>

      <Section>
        <SectionHeading eyebrow="Who we help" title="Candidates We Work With" />
        <ul className="mt-10 flex flex-wrap gap-3">
          {candidateTypes.map((c) => (
            <li key={c} className="border border-border px-5 py-3 label-xs">{c}</li>
          ))}
        </ul>
        <div className="mt-12 flex flex-wrap gap-3">
          <CtaLink to="/start-consultation">Get Consultation</CtaLink>
          <CtaLink to="/" variant="outline">Career Home</CtaLink>
        </div>
        <p className="mt-10 max-w-3xl text-xs leading-relaxed text-muted-foreground">{disclaimer}</p>
      </Section>

      <SiteFooter />
    </div>
  );
}
