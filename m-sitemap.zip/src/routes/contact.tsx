import { createFileRoute } from "@tanstack/react-router";
import { brand } from "@/lib/site-content";
import { useSubmission, SubmissionFields } from "@/components/site/SubmissionFields";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { Eyebrow, Section } from "@/components/site/primitives";

const title = "Contact — Staffing & Consulting Enquiries | Syntrix Global";
const description =
  "Start a conversation about staffing support, talent consulting or recruitment. Share your needs and we will reply with next steps.";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://syntrixglobal.in/contact" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/syntrixglobal-og-image.png" },
      { name: "twitter:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/syntrixglobal-og-image.png" },
    ],
    links: [{ rel: "canonical", href: "https://syntrixglobal.in/contact" }],
  }),
  component: ContactPage,
});

const field =
  "w-full border border-border bg-transparent px-4 py-3 text-sm placeholder:text-muted-foreground";
const labelCls = "label-xs block text-muted-foreground";

function Field({
  id,
  label,
  type = "text",
  required,
  maxLength = 200,
}: {
  id: string;
  label: string;
  type?: string;
  required?: boolean;
  maxLength?: number;
}) {
  return (
    <div className="grid gap-2">
      <label htmlFor={id} className={labelCls}>
        {label}
      </label>
      <input id={id} name={id} type={type} required={required} maxLength={maxLength} className={field} />
    </div>
  );
}

function ProjectForm() {
  const { sent, pending, error, submit } = useSubmission("project-enquiry");
  if (sent) {
    return (
      <p role="status" className="border border-border p-6 text-sm">
        Thank you — your enquiry has been sent. We&apos;ll be in touch shortly.
      </p>
    );
  }
  return (
    <form className="grid gap-5 sm:grid-cols-2" onSubmit={submit}>
      <SubmissionFields pending={pending} error={error} />
      <Field id="name" label="Name" required />
      <Field id="company" label="Company" />
      <Field id="email" label="Email" type="email" required maxLength={255} />
      <Field id="phone" label="Phone" type="tel" maxLength={30} />
      <div className="grid gap-2">
        <label htmlFor="service" className={labelCls}>
          How can we help?
        </label>
        <select id="service" name="service" className={field} required defaultValue="">
          <option value="" disabled>
            Select an option
          </option>
          {[
            "Placement & Staffing",
            "Talent Consulting",
            "Recruitment Support",
            "Technology Services",
            "General Enquiry",
            "Other",
          ].map((o) => (
            <option key={o} value={o}>
              {o}
            </option>
          ))}
        </select>
      </div>
      <div className="grid gap-2">
        <label htmlFor="budget" className={labelCls}>
          Approximate Scope / Budget
        </label>
        <select id="budget" name="budget" className={field} defaultValue="">
          <option value="">Prefer not to say</option>
          {["Exploring options", "Under $5,000", "$5,000–$10,000", "$10,000–$25,000", "$25,000–$50,000", "$50,000+"].map(
            (o) => (
              <option key={o} value={o}>
                {o}
              </option>
            ),
          )}
        </select>
      </div>
      <Field id="timeline" label="Expected Timeline" />
      <div className="grid gap-2 sm:col-span-2">
        <label htmlFor="description" className={labelCls}>
          Tell us what you need
        </label>
        <textarea id="description" name="description" rows={5} maxLength={2000} required className={field} />
      </div>
      <button type="submit" disabled={pending} className="bg-ink px-6 py-4 label-xs text-ivory sm:col-span-2">
        Start a Conversation
      </button>
    </form>
  );
}

function ContactPage() {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main>
        <Section>
          <Eyebrow>Contact</Eyebrow>
          <h1 className="display-lg mt-4">
            Start a
            <br />
            Conversation.
          </h1>
          <p className="mt-6 max-w-md text-base text-muted-foreground">
            Share a little about the roles you are hiring for, the consulting question you have, or
            any supporting technology needs. We reply with next steps.
          </p>

          <div className="mt-12 grid gap-12 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,0.6fr)]">
            <div>
              <ProjectForm />
            </div>
            <aside className="border-t border-border pt-8 lg:border-t-0 lg:border-l lg:pt-0 lg:pl-8">
              <h2 className="label-xs text-muted-foreground">Contact</h2>
              <a href="mailto:contact@syntrixglobal.in" className="mt-3 block text-sm underline">
                contact@syntrixglobal.in
              </a>
              <h2 className="label-xs mt-8 text-muted-foreground">Offices</h2>
              <div className="mt-3 grid gap-5">
                {brand.offices.map((office) => (
                  <address key={office.label} className="not-italic text-sm text-muted-foreground">
                    <span className="label-xs block text-foreground/80">{office.label}</span>
                    {office.lines.map((line) => (
                      <span key={line} className="mt-1 block">
                        {line}
                      </span>
                    ))}
                  </address>
                ))}
              </div>
              <h2 className="label-xs mt-8 text-muted-foreground">Looking for a career?</h2>
              <p className="mt-3 text-sm text-muted-foreground">
                USA candidates can visit{" "}
                <a href={brand.careersUrl} className="underline" rel="noopener noreferrer">
                  careers.syntrixglobal.in
                </a>
                . This page is for employer and consulting enquiries.
              </p>
              <h2 className="label-xs mt-8 text-muted-foreground">What happens next</h2>
              <p className="mt-3 text-sm text-muted-foreground">
                We review your enquiry and contact you to discuss scope, timing and next steps.
              </p>
            </aside>
          </div>
        </Section>
      </main>
      <SiteFooter />
    </div>
  );
}
