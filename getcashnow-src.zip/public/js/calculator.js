/**
 * Get Cash Now: homepage personal loan calculator (illustration only).
 * - Standard amortization, identical to scripts/compute-example.js:
 *     M = P*r / (1 - (1+r)^-n), r = APR/100/12; monthly = round2(M),
 *     total = round2(M*n), interest = round2(M*n - P)
 * - Limits come from config/compliance.json (window.__GCN_SITE__ inlined by the server,
 *   or GET /api/site-info as a fallback).
 * - No tracking of any kind here: conversions fire only after a successful POST /api/leads (main.js).
 */
(function () {
  'use strict';

  var root = document.getElementById('loanCalc');
  if (!root) return;

  var AMOUNT = { min: 500, max: 35000, step: 100, def: 5000 };
  var TERM = { min: 2, max: 72, step: 1, def: 36 };
  var APR = { min: 5.99, max: 35.99, step: 0.01, def: 20 };

  var round2 = function (x) { return Math.round((x + Number.EPSILON) * 100) / 100; };
  var usd = function (v, cents) {
    return '$' + v.toLocaleString('en-US', { minimumFractionDigits: cents ? 2 : 0, maximumFractionDigits: cents ? 2 : 0 });
  };
  var clamp = function (v, lo, hi) { return Math.min(hi, Math.max(lo, v)); };
  var snap = function (v, step, lo) { return lo + Math.round((v - lo) / step) * step; };

  function compute(P, n, apr) {
    var r = apr / 100 / 12;
    var M = r === 0 ? P / n : (P * r) / (1 - Math.pow(1 + r, -n));
    return { monthly: round2(M), total: round2(M * n), interest: round2(M * n - P) };
  }

  var el = function (id) { return document.getElementById(id); };
  var amountRange = el('calcAmountRange'), amountInput = el('calcAmount');
  var termRange = el('calcTermRange'), termInput = el('calcTerm');
  var aprRange = el('calcAprRange'), aprInput = el('calcApr');
  var out = { monthly: el('calcMonthly'), total: el('calcTotal'), interest: el('calcInterest') };
  var live = el('calcLive');
  var liveTimer;

  function applyLimits(site) {
    if (!site || typeof site !== 'object') return;
    var maxApr = Number(site.maxApr), minApr = Number(site.minApr);
    if (isFinite(maxApr) && maxApr > 0) APR.max = maxApr;
    if (site.minApr !== null && site.minApr !== '' && isFinite(minApr) && minApr > 0 && minApr < APR.max) APR.min = minApr;
    var minDays = Number(site.minRepaymentDays), maxMonths = Number(site.maxRepaymentMonths);
    if (isFinite(minDays) && minDays > 0) TERM.min = Math.max(1, Math.round(minDays / 30.4375)); // 61 days -> 2 months
    if (isFinite(maxMonths) && maxMonths >= TERM.min) TERM.max = maxMonths;
    APR.def = clamp(APR.def, APR.min, APR.max);
    TERM.def = clamp(TERM.def, TERM.min, TERM.max);
    [[aprRange, APR], [aprInput, APR], [termRange, TERM], [termInput, TERM]].forEach(function (p) {
      p[0].min = String(p[1].min); p[0].max = String(p[1].max);
    });
    var setText = function (id, t) { var n = el(id); if (n) n.textContent = t; };
    setText('calcAprMin', APR.min + '%');
    setText('calcAprMax', APR.max + '%');
    setText('calcTermMin', TERM.min + ' months');
    setText('calcTermMax', TERM.max + ' months');
  }

  function parseAmount(s) { return Number(String(s).replace(/[^0-9.]/g, '')); }

  function read() {
    return {
      P: clamp(snap(parseAmount(amountInput.value) || AMOUNT.def, AMOUNT.step, 0), AMOUNT.min, AMOUNT.max),
      n: clamp(Math.round(Number(termInput.value) || TERM.def), TERM.min, TERM.max),
      apr: clamp(round2(Number(aprInput.value) || APR.def), APR.min, APR.max),
    };
  }

  function render(v, announce) {
    var res = compute(v.P, v.n, v.apr);
    out.monthly.textContent = usd(res.monthly, true);
    out.total.textContent = usd(res.total, true);
    out.interest.textContent = usd(res.interest, true);
    amountRange.setAttribute('aria-valuetext', usd(v.P));
    termRange.setAttribute('aria-valuetext', v.n + ' months');
    aprRange.setAttribute('aria-valuetext', v.apr + ' percent APR');
    if (announce !== false) {
      clearTimeout(liveTimer);
      liveTimer = setTimeout(function () {
        live.textContent = 'Estimated monthly payment ' + usd(res.monthly, true) + ' for ' + usd(v.P) + ' over ' + v.n +
          ' months at ' + v.apr + '% APR. Total repaid ' + usd(res.total, true) + ', total interest ' + usd(res.interest, true) + '.';
      }, 600);
    }
    return res;
  }

  // Normalise every field to its clamped value (on change/blur and at start).
  function commit(announce) {
    var v = read();
    amountInput.value = v.P.toLocaleString('en-US');
    amountRange.value = String(v.P);
    termInput.value = String(v.n);
    termRange.value = String(v.n);
    aprInput.value = String(v.apr);
    aprRange.value = String(v.apr);
    return render(v, announce);
  }

  // Live updates while typing/dragging (without rewriting what the user is typing).
  function onRange(range, input, fmt) {
    range.addEventListener('input', function () { input.value = fmt(range.value); render(read()); });
  }
  onRange(amountRange, amountInput, function (x) { return Number(x).toLocaleString('en-US'); });
  onRange(termRange, termInput, String);
  onRange(aprRange, aprInput, String);

  function onTyped(input, range, parse, lim) {
    input.addEventListener('input', function () {
      var x = parse(input.value);
      if (isFinite(x) && x >= lim.min && x <= lim.max) { range.value = String(x); render(read()); }
    });
    input.addEventListener('change', function () { commit(); });
    input.addEventListener('blur', function () { commit(false); });
  }
  onTyped(amountInput, amountRange, parseAmount, AMOUNT);
  onTyped(termInput, termRange, Number, TERM);
  onTyped(aprInput, aprRange, Number, APR);

  root.addEventListener('submit', function (e) { e.preventDefault(); commit(); });

  // CTA: scroll to the lead form and focus it. Prefill an amount field only if the form has one.
  // Deliberately no tracking calls here.
  var cta = el('calcCta');
  if (cta) {
    cta.addEventListener('click', function (e) {
      var target = document.getElementById('apply');
      if (!target) return;
      e.preventDefault();
      var v = read();
      var amountField = document.querySelector('#leadForm [name="amount"], #leadForm #amount');
      if (amountField) amountField.value = String(v.P);
      var smooth = !(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
      target.scrollIntoView({ behavior: smooth ? 'smooth' : 'auto', block: 'start' });
      var first = document.getElementById('firstName');
      if (first) setTimeout(function () { first.focus({ preventScroll: true }); }, smooth ? 450 : 0);
      if (history.replaceState) history.replaceState(null, '', '#apply');
    });
  }

  function start(site) { applyLimits(site); commit(false); root.setAttribute('data-ready', '1'); }

  if (window.__GCN_SITE__) {
    start(window.__GCN_SITE__);
  } else {
    start(null);
    fetch('/api/site-info', { credentials: 'same-origin' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (site) { if (site) start(site); })
      .catch(function () {});
  }

  // Test hook (no side effects): window.GcnCalc.compute(5000, 36, 20)
  window.GcnCalc = { compute: compute, limits: function () { return { AMOUNT: AMOUNT, TERM: TERM, APR: APR }; } };
})();
