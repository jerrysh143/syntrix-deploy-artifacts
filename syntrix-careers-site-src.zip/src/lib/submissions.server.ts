import nodemailer from "nodemailer";
import { createHash, randomUUID } from "node:crypto";

const ORIGIN = "https://careers.syntrixglobal.in";
const MAX_BODY = 6 * 1024 * 1024;
const attempts = new Map<string, { count: number; until: number }>();
const fields = new Set("name company email phone service budget timeline description details firstName lastName cemail cphone location state education university graduation experience skill targetRole industry status preferred linkedin portfolio github message role goals support consent".split(" "));
const types = new Set(["project-enquiry", "project-brief", "candidate", "consultation", "newsletter"]);
const json = (status: number, body: object) => Response.json(body, { status, headers: { "Cache-Control": "no-store" } });

function allow(key: string, limit: number) {
  const now = Date.now();
  for (const [k, item] of attempts) if (item.until <= now) attempts.delete(k);
  const value = attempts.get(key) ?? { count: 0, until: now + 3600000 };
  value.count++;
  if (attempts.size >= 5000 && !attempts.has(key)) return false;
  attempts.set(key, value);
  return value.count <= limit;
}

export async function deliverSubmission(message: {email: string; type: string; text: string; attachment?: {filename: string; content: Buffer}}) {
  const { SMTP_HOST, SMTP_USER, SMTP_PASS, FORM_TO_EMAIL, FORM_FROM_EMAIL } = process.env;
  if (!SMTP_HOST || !SMTP_USER || !SMTP_PASS || !FORM_TO_EMAIL) throw new Error("Mail delivery is not configured");
  const port = Number(process.env.SMTP_PORT || "465");
  if (![465, 587].includes(port)) throw new Error("Use a TLS SMTP port");
  const transport = nodemailer.createTransport({
    host: SMTP_HOST, port, secure: port === 465, requireTLS: true,
    auth: { user: SMTP_USER, pass: SMTP_PASS },
    connectionTimeout: 15000, greetingTimeout: 15000, socketTimeout: 30000,
    disableFileAccess: true, disableUrlAccess: true,
  });
  const result = await transport.sendMail({
    from: FORM_FROM_EMAIL || SMTP_USER,
    to: FORM_TO_EMAIL,
    replyTo: message.email,
    subject: `Syntrix Global: ${message.type}`,
    text: message.text,
    attachments: message.attachment ? [message.attachment] : [],
  });
  if (!result.accepted?.length || result.rejected?.length) throw new Error("Mail server did not accept delivery");
}

export async function handleSubmission(request: Request, deliver = deliverSubmission, origin = ORIGIN) {
  if (request.method !== "POST") return json(405, {error:"Use POST to submit the form."});
  if (request.headers.get("origin") !== origin) return json(403, {error:"Please submit using the website form."});
  if (!request.headers.get("content-type")?.startsWith("multipart/form-data")) return json(415, {error:"Invalid form format."});
  const ip = request.headers.get("x-real-ip") || request.headers.get("x-forwarded-for")?.split(",")[0] || "unknown";
  const key = createHash("sha256").update(ip).digest("hex");
  if (!allow(`ip:${key}`, 20) || !allow("total", 200)) return json(429, {error:"Too many requests. Please try again later."});
  try {
    if (Number(request.headers.get("content-length")) > MAX_BODY) return json(413, {error:"Your upload is too large. Resume limit: 5 MB."});
    const reader = request.body?.getReader();
    if (!reader) return json(400, {error:"No form data received."});
    const chunks: Uint8Array[] = []; let size = 0;
    while (true) {
      const item = await reader.read(); if (item.done) break;
      size += item.value.length;
      if (size > MAX_BODY) { await reader.cancel(); return json(413, {error:"Your upload is too large. Resume limit: 5 MB."}); }
      chunks.push(item.value);
    }
    const data = await new Response(Buffer.concat(chunks), {headers:{"Content-Type":request.headers.get("content-type")!}}).formData();
    if (data.get("website")) return json(200, {ok:true});
    const type = String(data.get("formType") || "");
    if (!types.has(type)) return json(400, {error:"Unknown form."});
    const email = String(data.get("email") || data.get("cemail") || "").trim();
    if (email.length > 254 || !/^[^\s@<>\r\n]+@[^\s@<>\r\n]+\.[^\s@<>\r\n]+$/.test(email)) return json(400, {error:"Enter a valid email address."});
    const required = type === "candidate" ? ["firstName","lastName","consent"] : type === "newsletter" ? [] : ["name"];
    if (required.some(k => typeof data.get(k) !== "string" || !String(data.get(k)).trim())) return json(400, {error:"Complete all required fields and consent."});
    if (type === "project-enquiry" && !String(data.get("description") || "").trim()) return json(400, {error:"Please describe your project."});
    const values: string[] = [];
    for (const [name, value] of data.entries()) {
      if (["formType","website","resume"].includes(name)) continue;
      if (!fields.has(name) || typeof value !== "string" || value.length > 2000) return json(400, {error:"One or more form fields are invalid or too long."});
      values.push(`${name}: ${value.trim()}`);
    }
    let attachment: {filename: string; content: Buffer} | undefined;
    const resume = data.get("resume");
    if (resume instanceof File && resume.size) {
      if (type !== "candidate" || resume.size > 5 * 1024 * 1024) return json(413, {error:"Resume must be 5 MB or smaller."});
      const content = Buffer.from(await resume.arrayBuffer());
      const pdf = /\.pdf$/i.test(resume.name) && content.subarray(0,5).toString() === "%PDF-";
      const docx = /\.docx$/i.test(resume.name) && content[0] === 0x50 && content[1] === 0x4b && content[2] === 3 && content[3] === 4;
      if (!pdf && !docx) return json(400, {error:"Upload a valid PDF or DOCX resume."});
      attachment = {filename: pdf ? "candidate-resume.pdf" : "candidate-resume.docx", content};
    }
    if (!allow(`email:${createHash("sha256").update(email.toLowerCase()).digest("hex")}`, 5)) return json(429, {error:"Too many submissions for this email. Please try later."});
    const reference = randomUUID();
    try {
      await deliver({email, type, attachment, text:`Website: ${origin}\nForm: ${type}\nReference: ${reference}\nReceived: ${new Date().toISOString()}\n\n${values.join("\n")}`});
    } catch {
      console.error("Submission delivery failed", reference);
      return json(503, {error:"We couldn't send your submission. Your form has been kept so you can try again."});
    }
    return json(200, {ok:true, reference});
  } catch { return json(400, {error:"We couldn't read the form. Please check your details and try again."}); }
}
