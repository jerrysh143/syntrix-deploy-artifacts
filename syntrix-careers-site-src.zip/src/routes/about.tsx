import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { CtaLink, Eyebrow, Section, SectionHeading } from "@/components/site/primitives";
import { careerIndustries, candidateTypes } from "@/lib/site-content";
import careerPeople from "@/assets/career-professionals-branded.jpg";

const title = "About Syntrix Global — Career Support";
const description =
  "Syntrix Global provides career support for opportunities in the United States guiding graduates and professionals from profile positioning through interview preparation and placement support.";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://careers.syntrixglobal.in/about" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/careers-syntrixglobal-og-image.png" },
      { name: "twitter:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/careers-syntrixglobal-og-image.png" },
    ],
    links: [{ rel: "canonical", href: "https://careers.syntrixglobal.in/about" }],
  }),
  component: AboutPage,
});

const values = [
  { no: "01", title: "Clarity", desc: "Plain language, an honest assessment, no inflated promises." },
  { no: "02", title: "Craft", desc: "Considered positioning and preparation, not template resumes." },
  { no: "03", title: "Accountability", desc: "A named consultant, visible milestones, honest status." },
  { no: "04", title: "Longevity", desc: "Careers built to hold up over years, not one lucky application." },
];

function AboutPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />

      <Section>
        <SectionHeading as="h1"
          eyebrow="About"
          title={
            <>
              People First.
              <br />
              Careers Built.
            </>
          }
          intro="We help graduates and professionals build careers in the United States — with structured preparation, credible positioning and consistent search support."
        />
        <div className="mt-14 grid gap-10 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
          <img
            src={careerPeople}
            alt="Illustrative professional consultation scene"
            loading="lazy"
            className="w-full border border-border object-cover"
          />
          <div className="grid content-start gap-6">
            <p className="text-base leading-relaxed text-muted-foreground">
              Syntrix Global provides career support for opportunities in the United States. We work one-to-one with candidates on
              career strategy, resume and LinkedIn positioning, interview preparation, recruiter
              outreach and ongoing job-search guidance.
            </p>
            <p className="text-base leading-relaxed text-muted-foreground">
              Share your background, target roles and the support you need. A consultation can help
              identify practical next steps for your job search.
            </p>
            <div className="flex flex-wrap gap-3">
              <CtaLink to="/start-consultation">Start a Consultation</CtaLink>
              <CtaLink to="/contact" variant="outline">Talk to Us</CtaLink>
            </div>
          </div>
        </div>
      </Section>

      <Section>
        <SectionHeading eyebrow="What we value" title="Principles" />
        <div className="mt-12 grid gap-px border border-border bg-border sm:grid-cols-2 lg:grid-cols-4">
          {values.map((v) => (
            <div key={v.no} className="bg-background p-8">
              <Eyebrow>{v.no}</Eyebrow>
              <h3 className="mt-4 font-display text-2xl uppercase">{v.title}</h3>
              <p className="mt-3 text-sm text-muted-foreground">{v.desc}</p>
            </div>
          ))}
        </div>
      </Section>

      <Section>
        <SectionHeading eyebrow="Coverage" title="Who We Support" />
        <div className="mt-12 grid gap-10 md:grid-cols-2">
          <div>
            <Eyebrow>Candidates</Eyebrow>
            <ul className="mt-4 grid gap-2">
              {candidateTypes.map((i) => (
                <li key={i} className="border-b border-border py-2 text-sm">{i}</li>
              ))}
            </ul>
          </div>
          <div>
            <Eyebrow>Industries</Eyebrow>
            <ul className="mt-4 grid gap-2 sm:grid-cols-2">
              {careerIndustries.map((i) => (
                <li key={i} className="border-b border-border py-2 text-sm">{i}</li>
              ))}
            </ul>
          </div>
        </div>
      </Section>

      <SiteFooter />
    </div>
  );
}
