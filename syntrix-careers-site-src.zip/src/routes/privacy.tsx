import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/site/LegalPage";

const title = "Privacy Policy — Syntrix Global";
const description =
  "How Syntrix Global collects, uses, stores and protects personal information submitted through our website and services.";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://careers.syntrixglobal.in/privacy" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/careers-syntrixglobal-og-image.png" },
      { name: "twitter:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/careers-syntrixglobal-og-image.png" },
    ],
    links: [{ rel: "canonical", href: "https://careers.syntrixglobal.in/privacy" }],
  }),
  component: () => (
    <LegalPage
      eyebrow="Legal"
      title="Privacy Policy"
      intro="We collect only what we need to respond to enquiries and deliver our services, and we never sell personal data."
      sections={[
        {
          heading: "Information We Collect",
          body: [
            "We receive the details you submit through candidate registration, consultation and email-update forms, including your contact information, education, experience, career interests and any resume you choose to attach.",
            "Our hosting provider processes technical request information to operate the website. The form service uses temporary request limits to reduce spam.",
          ],
        },
        {
          heading: "How We Use Information",
          body: [
            "To respond to enquiries, prepare proposals, deliver contracted services, provide career consulting support and send updates you have opted into.",
          ],
        },
        {
          heading: "Sharing",
          body: [
            "Website submissions and optional resumes are sent to contact@syntrixglobal.in using our hosting and email providers. Submitting a form does not automatically publish your profile or send it to employers.",
          ],
        },
        {
          heading: "Retention & Security",
          body: [
            "We retain information only as long as necessary for the purpose it was collected or as required by law, and apply reasonable technical and organisational safeguards.",
          ],
        },
        {
          heading: "Your Rights",
          body: [
            "Contact contact@syntrixglobal.in to request access, correction or deletion of information you have submitted, or to stop receiving email updates.",
          ],
        },
      ]}
    />
  ),
});
