'use strict';

const path = require('path');
const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const { bootstrapAdmin } = require('./lib/admin-bootstrap');
const leadsRouter = require('./routes/leads');
const adminRouter = require('./routes/admin');

const PORT = Number(process.env.PORT) || 3000;
const NODE_ENV = process.env.NODE_ENV || 'development';
const isProd = NODE_ENV === 'production';

if (!process.env.SESSION_SECRET || String(process.env.SESSION_SECRET).length < 16) {
  console.error('SESSION_SECRET env var is required (min 16 characters)');
  process.exit(1);
}

bootstrapAdmin();

const app = express();
app.set('trust proxy', 1);

app.use(
  helmet({
    contentSecurityPolicy: {
      useDefaults: true,
      directives: {
        "default-src": ["'self'"],
        "script-src": ["'self'"],
        "style-src": ["'self'", "'unsafe-inline'"],
        "img-src": ["'self'", "data:"],
        "font-src": ["'self'", "data:"],
        "connect-src": ["'self'"],
        "frame-ancestors": ["'none'"],
      },
    },
    crossOriginEmbedderPolicy: false,
  })
);

app.use(express.json({ limit: '64kb' }));
app.use(express.urlencoded({ extended: false, limit: '64kb' }));
app.use(cookieParser());

app.use(
  session({
    name: 'gcn.sid',
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: isProd,
      sameSite: 'lax',
      maxAge: 8 * 60 * 60 * 1000,
    },
  })
);

app.use('/api', leadsRouter);
app.use('/api/admin', adminRouter);

const publicDir = path.join(__dirname, 'public');
app.use(express.static(publicDir, { index: false, maxAge: isProd ? '1h' : 0 }));

function sendPage(res, file) {
  res.sendFile(path.join(publicDir, file));
}

app.get('/', (req, res) => sendPage(res, 'index.html'));
app.get('/how-it-works', (req, res) => sendPage(res, 'how-it-works.html'));
app.get('/offers', (req, res) => sendPage(res, 'offers.html'));
app.get('/rates-fees', (req, res) => sendPage(res, 'rates-fees.html'));
app.get('/disclosure', (req, res) => sendPage(res, 'disclosure.html'));
app.get('/disclaimer', (req, res) => res.redirect(301, '/disclosure'));
app.get('/privacy', (req, res) => sendPage(res, 'privacy.html'));
app.get('/terms', (req, res) => sendPage(res, 'terms.html'));
app.get('/e-consent', (req, res) => sendPage(res, 'e-consent.html'));
app.get('/thank-you', (req, res) => sendPage(res, 'thank-you.html'));
app.get('/admin', (req, res) => sendPage(res, 'admin.html'));
app.get('/admin/', (req, res) => res.redirect(301, '/admin'));

app.get('/robots.txt', (req, res) => {
  res.type('text/plain').send(
    [
      'User-agent: *',
      'Allow: /',
      'Disallow: /admin',
      'Disallow: /api/',
      'Sitemap: https://getcashnow.cc/sitemap.xml',
      '',
    ].join('\n')
  );
});

app.get('/sitemap.xml', (req, res) => {
  const urls = [
    '/',
    '/how-it-works',
    '/offers',
    '/rates-fees',
    '/disclosure',
    '/privacy',
    '/terms',
    '/e-consent',
    '/thank-you',
  ];
  const body = urls
    .map(
      (u) =>
        `  <url>\n    <loc>https://getcashnow.cc${u === '/' ? '/' : u}</loc>\n    <changefreq>weekly</changefreq>\n  </url>`
    )
    .join('\n');
  res.type('application/xml').send(
    `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${body}\n</urlset>\n`
  );
});

app.use((req, res) => {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ ok: false, error: 'Not found' });
  }
  res.status(404).sendFile(path.join(publicDir, '404.html'));
});

app.use((err, req, res, next) => {
  console.error(err);
  if (req.path.startsWith('/api/')) {
    return res.status(500).json({ ok: false, error: 'Server error' });
  }
  res.status(500).send('Something went wrong');
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Get Cash Now listening on 0.0.0.0:${PORT} (${NODE_ENV})`);
});
