'use strict';

const express = require('express');
const { v4: uuidv4 } = require('uuid');
const rateLimit = require('express-rate-limit');
const store = require('../lib/store');
const { validateLead } = require('../lib/validation');

const router = express.Router();

const formLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { ok: false, error: 'Too many submissions. Please try again later.' },
});

router.post('/leads', formLimiter, (req, res) => {
  const result = validateLead(req.body || {});
  if (!result.ok) {
    return res.status(400).json({ ok: false, errors: result.errors });
  }

  const lead = {
    id: uuidv4(),
    ...result.data,
    status: 'new',
    notes: '',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    ip: req.ip || '',
    userAgent: String(req.get('user-agent') || '').slice(0, 300),
  };

  store.addLead(lead);
  return res.status(201).json({ ok: true, id: lead.id });
});

module.exports = router;
