import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/site/LegalPage";

const title = "Disclaimer — Syntrix Global";
const description =
  "Important information about project estimates, third-party services and website content accuracy.";

export const Route = createFileRoute("/disclaimer")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://syntrixglobal.in/disclaimer" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/syntrixglobal-og-image.png" },
      { name: "twitter:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/syntrixglobal-og-image.png" },
    ],
    links: [{ rel: "canonical", href: "https://syntrixglobal.in/disclaimer" }],
  }),
  component: () => (
    <LegalPage
      eyebrow="Legal"
      title="Disclaimer"
      intro="Please read the following before relying on any information or service outcome described on this site."
      sections={[
        {
          heading: "Third-Party Services",
          body: [
            "Projects may rely on third-party platforms, APIs and hosting providers. We are not responsible for outages, pricing changes or policy changes made by those providers.",
          ],
        },
        {
          heading: "Website Content",
          body: [
            "Content on this site is provided for general information. While we work to keep it accurate and current, we make no warranty of completeness for any particular purpose.",
          ],
        },
        {
          heading: "Project Estimates",
          body: [
            "Timelines and costs referenced on this site are indicative. Binding figures are provided only in a written proposal after a discovery conversation.",
          ],
        },
      ]}
    />
  ),
});
