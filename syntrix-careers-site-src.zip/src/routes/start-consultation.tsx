import { createFileRoute } from "@tanstack/react-router";
import { useSubmission, SubmissionFields } from "@/components/site/SubmissionFields";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { Eyebrow, Section, SectionHeading } from "@/components/site/primitives";
import { careerProcess, careerServices, careerIndustries, disclaimer } from "@/lib/site-content";

const title = "Start a USA Career Consultation | Syntrix Global";
const description =
  "Share your background and target role. Syntrix replies within two business days with an assessment and suggested career roadmap. Employment not guaranteed.";

export const Route = createFileRoute("/start-consultation")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://careers.syntrixglobal.in/start-consultation" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/careers-syntrixglobal-og-image.png" },
      { name: "twitter:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/careers-syntrixglobal-og-image.png" },
    ],
    links: [{ rel: "canonical", href: "https://careers.syntrixglobal.in/start-consultation" }],
  }),
  component: StartConsultationPage,
});

const field =
  "w-full border border-border bg-transparent px-4 py-3 text-sm placeholder:text-muted-foreground focus:border-ink focus:outline-none";
const labelCls = "label-xs block text-muted-foreground";

function StartConsultationPage() {
  const {sent,pending,error,submit} = useSubmission("consultation");

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />

      <Section>
        <SectionHeading as="h1"
          eyebrow="Start a Consultation"
          title="Start a Career Consultation"
          intro="Share your background and target role. We reply within two business days with an assessment and a suggested career roadmap."
        />

        <div className="mt-14 grid gap-12 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)]">
          <form
            className="grid gap-5"
            onSubmit={submit}
          >
      <SubmissionFields pending={pending} error={error} />
            <div className="grid gap-5 sm:grid-cols-2">
              <div>
                <label className={labelCls} htmlFor="sc-name">Full name</label>
                <input id="sc-name" name="name" required maxLength={100} className={`${field} mt-2`} placeholder="Your name" />
              </div>
              <div>
                <label className={labelCls} htmlFor="sc-email">Email</label>
                <input id="sc-email" name="email" type="email" required maxLength={255} className={`${field} mt-2`} placeholder="Your email address" />
              </div>
              <div>
                <label className={labelCls} htmlFor="sc-phone">Phone</label>
                <input id="sc-phone" name="phone" maxLength={30} className={`${field} mt-2`} placeholder="Phone number with country code" />
              </div>
              <div>
                <label className={labelCls} htmlFor="sc-location">Current location</label>
                <input id="sc-location" name="location" maxLength={120} className={`${field} mt-2`} placeholder="City, State / Country" />
              </div>
            </div>

            <div>
              <label className={labelCls} htmlFor="sc-service">Service needed</label>
              <select id="sc-service" name="service" className={`${field} mt-2`} defaultValue="">
                <option value="" disabled>Select a service</option>
                {careerServices.map((s) => (
                  <option key={s.no} value={s.title}>{s.title}</option>
                ))}
              </select>
            </div>

            <div className="grid gap-5 sm:grid-cols-2">
              <div>
                <label className={labelCls} htmlFor="sc-industry">Target industry</label>
                <select id="sc-industry" name="industry" className={`${field} mt-2`} defaultValue="">
                  <option value="" disabled>Select an industry</option>
                  {careerIndustries.map((i) => (
                    <option key={i} value={i}>{i}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className={labelCls} htmlFor="sc-experience">Experience level</label>
                <select id="sc-experience" name="experience" className={`${field} mt-2`} defaultValue="">
                  <option value="" disabled>Select a level</option>
                  <option>Recent graduate</option>
                  <option>0 – 2 years</option>
                  <option>2 – 5 years</option>
                  <option>5 – 10 years</option>
                  <option>10+ years</option>
                </select>
              </div>
            </div>

            <div className="grid gap-5 sm:grid-cols-2">
              <div>
                <label className={labelCls} htmlFor="sc-role">Target role</label>
                <input id="sc-role" name="role" maxLength={120} className={`${field} mt-2`} placeholder="e.g. Data Analyst" />
              </div>
              <div>
                <label className={labelCls} htmlFor="sc-timeline">Job search timeline</label>
                <select id="sc-timeline" name="timeline" className={`${field} mt-2`} defaultValue="">
                  <option value="" disabled>Select a timeline</option>
                  <option>Immediately</option>
                  <option>1 – 3 months</option>
                  <option>3 – 6 months</option>
                  <option>Exploring options</option>
                </select>
              </div>
            </div>

            <div>
              <label className={labelCls} htmlFor="sc-goals">Career goals</label>
              <textarea id="sc-goals" name="goals" rows={6} maxLength={2000} className={`${field} mt-2`} placeholder="Background, current status, target companies, visa or relocation notes..." />
            </div>

            <button type="submit" disabled={pending} className="justify-self-start bg-ink px-6 py-4 label-xs text-ivory transition-colors hover:bg-accent hover:text-accent-foreground">
              Request Consultation
            </button>

            {sent ? (
              <p aria-live="polite" className="border border-border px-4 py-3 text-sm text-muted-foreground">
                Thanks — your request has been received. We&apos;ll be in touch shortly.
              </p>
            ) : null}
          </form>

          <aside className="border border-border p-8">
            <Eyebrow>How the engagement works</Eyebrow>
            <ul className="mt-6 space-y-5">
              {careerProcess.map((p) => (
                <li key={p.no} className="flex gap-4 border-b border-border pb-4 last:border-0">
                  <span className="label-xs text-muted-foreground">{p.no}</span>
                  <span className="font-display text-lg uppercase">{p.title}</span>
                </li>
              ))}
            </ul>
            <p className="mt-8 text-sm text-muted-foreground">{disclaimer}</p>
          </aside>
        </div>
      </Section>

      <SiteFooter />
    </div>
  );
}
