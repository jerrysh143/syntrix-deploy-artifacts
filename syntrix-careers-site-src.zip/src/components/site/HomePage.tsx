import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { SiteHeader } from "./SiteHeader";
import { SiteFooter } from "./SiteFooter";
import { CtaLink, Eyebrow, Marquee, Section, SectionHeading } from "./primitives";
import { OpenRolesSection } from "./OpenRolesSection";
import {
  careerFaqs,
  careerIndustries,
  careerProcess,
  careerServices,
  candidateJourneys,
  candidateTypes,
  disclaimer,
} from "@/lib/site-content";
import careerPeople from "@/assets/career-professionals-branded.jpg";
import analytics from "@/assets/analytics-branded.jpg";

const heroCards = [
  { no: "01", a: "Career", b: "Consulting" },
  { no: "02", a: "Resume &", b: "LinkedIn" },
  { no: "03", a: "Placement", b: "Assistance" },
];

function Hero() {
  return (
    <section className="border-b border-border">
      <div className="mx-auto w-full max-w-[1400px] px-5 pt-14 pb-20 sm:px-8">
        <div className="grid gap-10 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)] lg:items-start">
          <div className="fade-up">
            <h1 className="display-xl">
              From
              <br />
              Graduation
              <br />
              to Career.
            </h1>
            <p className="mt-6 max-w-md text-lg leading-relaxed text-muted-foreground">
              Strategic career guidance and placement assistance for graduates and professionals
              pursuing opportunities across the United States.
            </p>
            <p className="label-xs mt-6 text-foreground">Profile. Prepare. Connect. Grow.</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <CtaLink to="/start-consultation">Get Career Consultation</CtaLink>
              <a
                href="#process"
                className="group inline-flex items-center gap-3 border border-border px-6 py-4 label-xs transition-colors hover:bg-foreground hover:text-background"
              >
                View Our Process
                <span aria-hidden="true" className="transition-transform group-hover:translate-x-1">
                  →
                </span>
              </a>
              <a
                href="#jobs"
                className="group inline-flex items-center gap-3 border border-border px-6 py-4 label-xs transition-colors hover:bg-foreground hover:text-background"
              >
                Open Roles
                <span aria-hidden="true" className="transition-transform group-hover:translate-x-1">
                  →
                </span>
              </a>
            </div>
            <p className="mt-5 max-w-md text-sm text-muted-foreground">{disclaimer}</p>
          </div>

          <div className="relative">
            <img
              src={careerPeople}
              alt="Diverse professionals in a corporate lobby"
              width={1200}
              height={912}
              className="aspect-4/3 w-full border border-border object-cover"
            />
            <div className="mt-6 grid gap-px bg-border sm:grid-cols-3">
              {heroCards.map((c) => (
                <article key={c.no} className="group bg-background p-5 transition-colors hover:bg-foreground hover:text-background">
                  <Eyebrow>{c.no}</Eyebrow>
                  <h2 className="mt-6 font-display text-lg leading-tight uppercase">
                    {c.a}
                    <br />
                    {c.b}
                  </h2>
                  <Link to="/career-services" className="mt-6 inline-block text-sm underline">Explore services →</Link>
                </article>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function About() {
  return (
    <section className="dark border-b border-border bg-background text-foreground">
      <Marquee items={["Careers", "Strategy", "Opportunities", "Growth", "Success"]} />
      <div id="about" className="mx-auto w-full max-w-[1400px] px-5 py-20 sm:px-8 md:py-28">
        <div className="grid gap-12 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.2fr)]">
          <div>
            <Eyebrow>About</Eyebrow>
            <h2 className="display-lg mt-4">
              Career
              <br />
              Strategy Built
              <br />
              for the USA.
            </h2>
            <p className="mt-6 max-w-sm text-base leading-relaxed text-muted-foreground">
              We support graduates and professionals with structured career preparation, profile
              positioning, recruiter outreach and job-search guidance for opportunities across the
              United States.
            </p>
            <div className="mt-8">
              <CtaLink to="/contact" variant="outline">
                Talk to a Consultant
              </CtaLink>
            </div>
          </div>
          <img
            src={careerPeople}
            alt="Professionals meeting in a modern office"
            loading="lazy"
            width={1200}
            height={912}
            className="aspect-16/10 w-full border border-border object-cover"
          />
        </div>
        <p className="mt-14 max-w-4xl font-display text-xl uppercase leading-tight md:text-3xl">
          Career support designed around your profile, skills and goals.
        </p>
      </div>
    </section>
  );
}

function Services() {
  return (
    <Section id="services">
      <SectionHeading
        eyebrow="Career services"
        title="Career Services"
        intro="Each service is personalized to your experience, education, skills and target industry."
      />
      <div className="mt-12 grid gap-px bg-border sm:grid-cols-2 lg:grid-cols-3">
        {careerServices.map((s) => (
          <article
            key={s.no}
            className="group flex min-h-56 flex-col justify-between bg-background p-6 transition-colors duration-300 hover:bg-foreground hover:text-background"
          >
            <Eyebrow>{s.no}</Eyebrow>
            <div className="mt-8">
              <h3 className="font-display text-2xl leading-tight uppercase">{s.title}</h3>
              <p className="mt-3 text-sm text-muted-foreground group-hover:text-background/70">{s.desc}</p>
            </div>
            <Link to="/start-consultation" className="mt-6 inline-block text-sm underline">Discuss your goals →</Link>
          </article>
        ))}
      </div>
    </Section>
  );
}

function Feature() {
  return (
    <section className="dark border-b border-border bg-background text-foreground">
      <div className="mx-auto grid w-full max-w-[1400px] gap-12 px-5 py-20 sm:px-8 md:py-28 lg:grid-cols-2 lg:items-center">
        <div>
          <Eyebrow>Who we work with</Eyebrow>
          <h2 className="display-lg mt-4">
            Who We
            <br />
            Work With
          </h2>
          <ul className="mt-8 grid grid-cols-2 gap-x-6 gap-y-2 text-sm text-muted-foreground">
            {candidateTypes.map((i) => (
              <li key={i} className="border-b border-border py-2">
                {i}
              </li>
            ))}
          </ul>
          <p className="mt-6 max-w-md text-sm text-muted-foreground">
            Our services are personalized based on experience, education, skills, career objectives
            and target industry.
          </p>
          <div className="mt-8">
            <CtaLink to="/contact" variant="outline">
              Register as a Candidate
            </CtaLink>
          </div>
        </div>
        <img
          src={analytics}
          alt="Analytics dashboard on a laptop"
          loading="lazy"
          width={1200}
          height={912}
          className="aspect-square w-full border border-border object-cover"
        />
      </div>
    </section>
  );
}

function Industries() {
  return (
    <Section id="industries">
      <SectionHeading
        eyebrow="Coverage"
        title="Industries"
        intro="Domain context shapes everything — from role targeting to career positioning."
      />
      <div className="-mx-5 mt-12 overflow-x-auto px-5 sm:-mx-8 sm:px-8">
        <ul className="flex w-max gap-px bg-border">
          {careerIndustries.map((ind, i) => (
            <li key={ind} className="w-56 bg-background p-6">
              <Eyebrow>{String(i + 1).padStart(2, "0")}</Eyebrow>
              <p className="mt-10 font-display text-lg uppercase leading-tight">{ind}</p>
            </li>
          ))}
        </ul>
      </div>
    </Section>
  );
}

function Process() {
  return (
    <Section id="process">
      <SectionHeading
        eyebrow="Process"
        title={
          <>
            From Profile
            <br />
            to Opportunity.
          </>
        }
      />
      <ol className="mt-12 grid gap-px bg-border sm:grid-cols-2 lg:grid-cols-4">
        {careerProcess.map((s) => (
          <li key={s.no} className="bg-background p-6">
            <Eyebrow>{s.no}</Eyebrow>
            <p className="mt-10 font-display text-xl uppercase leading-tight">{s.title}</p>
          </li>
        ))}
      </ol>
      <p className="mt-8 max-w-3xl border-l-2 border-accent pl-4 text-sm text-muted-foreground">{disclaimer}</p>
    </Section>
  );
}

function Journeys() {
  return (
    <Section id="journeys">
      <SectionHeading
        eyebrow="Career support"
        title="Career Planning Areas"
        intro="Explore areas where structured profile preparation, interview practice and job-search guidance can support your next step."
      />
      <div className="mt-12 grid gap-px bg-border sm:grid-cols-2 lg:grid-cols-3">
        {candidateJourneys.map((p) => (
          <article key={p.title} className="group bg-background p-6 transition-colors hover:bg-foreground hover:text-background">
            <Eyebrow>{p.tag}</Eyebrow>
            <h3 className="mt-10 font-display text-2xl uppercase leading-tight">{p.title}</h3>
            <p className="mt-4 text-sm text-muted-foreground">{p.desc}</p>
            <Link to="/start-consultation" className="mt-6 inline-block text-sm underline">Discuss your goals →</Link>
          </article>
        ))}
      </div>
    </Section>
  );
}

function Faq() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <Section id="faq">
      <div className="grid gap-12 lg:grid-cols-[minmax(0,0.8fr)_minmax(0,1.2fr)]">
        <div>
          <h2 className="display-lg">FAQs</h2>
          <img
            src={careerPeople}
            alt="Professionals in conversation"
            loading="lazy"
            width={1200}
            height={912}
            className="mt-8 aspect-3/4 w-full border border-border object-cover"
          />
        </div>
        <div>
          {careerFaqs.map((f, i) => {
            const isOpen = open === i;
            return (
              <div key={f.q} className="border-b border-border">
                <h3>
                  <button
                    type="button"
                    aria-expanded={isOpen}
                    onClick={() => setOpen(isOpen ? null : i)}
                    className="flex w-full items-center justify-between gap-6 py-5 text-left font-display text-lg uppercase leading-tight"
                  >
                    {f.q}
                    <span aria-hidden="true" className="text-muted-foreground">
                      {isOpen ? "–" : "+"}
                    </span>
                  </button>
                </h3>
                {isOpen ? <p className="pb-5 text-sm leading-relaxed text-muted-foreground">{f.a}</p> : null}
              </div>
            );
          })}
        </div>
      </div>
    </Section>
  );
}

function FinalCta() {
  return (
    <section className="dark bg-background text-foreground">
      <div className="mx-auto w-full max-w-[1400px] px-5 py-24 sm:px-8">
        <h2 className="display-xl">
          Ready for
          <br />
          Your Next
          <br />
          Career Move?
        </h2>
        <div className="mt-10">
          <Link
            to="/start-consultation"
            className="group inline-flex items-center gap-4 bg-foreground px-8 py-5 label-xs text-background transition-colors hover:bg-accent hover:text-accent-foreground"
          >
            Book a Consultation
            <span aria-hidden="true" className="transition-transform group-hover:translate-x-1">
              →
            </span>
          </Link>
        </div>
      </div>
    </section>
  );
}

export function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main>
        <Hero />
        <About />
        <Services />
        <OpenRolesSection />
        <Feature />
        <Industries />
        <Process />
        <Journeys />
        <Faq />
        <FinalCta />
      </main>
      <SiteFooter />
      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background p-3 md:hidden">
        <Link to="/start-consultation" className="block bg-ink px-5 py-4 text-center label-xs text-ivory">
          Get Career Consultation
        </Link>
      </div>
    </div>
  );
}
