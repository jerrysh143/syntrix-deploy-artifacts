// Local-only headless check of conversion->redirect timing with gtag/fbq stubs (all third-party requests aborted).
// Needs local servers on :3999 (no pixel) and :3998 (META_PIXEL_ID set) and playwright-core + Chrome.
const { chromium } = require('/workspace/syntrix-shot-run/node_modules/playwright-core');
const SCEN = [
  { name: 'A no-pixel, gtag cb @120ms', port: 3999, cb: 120 },
  { name: 'B no-pixel, gtag cb never ', port: 3999, cb: null },
  { name: 'C pixel,    gtag cb @50ms ', port: 3998, cb: 50 },
  { name: 'D pixel,    gtag cb never ', port: 3998, cb: null },
  { name: 'E no-pixel, gtag cb @700ms', port: 3999, cb: 700 },
  { name: 'F pixel,    gtag cb @450ms', port: 3998, cb: 450 },
];
(async () => {
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  for (const sc of SCEN) {
    const ctx = await browser.newContext(); const page = await ctx.newPage();
    const ev = []; const navs = []; let thirdParty = 0;
    await ctx.route(/googletagmanager|facebook|google-analytics|doubleclick|googleadservices|google\.com|googlesyndication/, (r) => { thirdParty++; r.abort(); });
    await ctx.route('**/offers', async (r) => { navs.push(Date.now()); await new Promise((x) => setTimeout(x, 1500)); r.continue(); });
    page.on('console', (m) => { const t = m.text(); if (t.startsWith('EV ')) ev.push(JSON.parse(t.slice(3))); });
    await ctx.addInitScript((cb) => {
      const path = location.pathname;
      window.fbq = function () { console.log('EV ' + JSON.stringify({ k: 'fbq', a: [].slice.call(arguments, 0, 2), path, t: Date.now() })); };
      let dl; Object.defineProperty(window, 'dataLayer', { configurable: true, get: () => dl, set: (v) => { dl = v; const p = v.push.bind(v);
        v.push = (a) => {
          if (a && a[0] === 'event') {
            const o = a[2] || {};
            console.log('EV ' + JSON.stringify({ k: 'gtag', ev: a[1], send_to: o.send_to, transport_type: o.transport_type, event_timeout: o.event_timeout, cb: typeof o.event_callback, path, t: Date.now() }));
            if (cb !== null && typeof o.event_callback === 'function') setTimeout(() => { console.log('EV ' + JSON.stringify({ k: 'cb', path, t: Date.now() })); o.event_callback(); }, cb);
          }
          return p(a);
        }; } });
    }, sc.cb);
    await page.goto(`http://localhost:${sc.port}/`);
    await page.fill('#firstName', 'Timing'); await page.fill('#lastName', 'Test'); await page.fill('#zip', '10001'); await page.fill('#phone', '2125550100');
    await page.check('#consentPrivacy'); await page.check('#consentContact');
    await page.click('#submitBtn');
    await page.waitForTimeout(2600); // covers 1.5s /offers hold + late callbacks
    await page.waitForLoadState('load').catch(() => {});
    await page.waitForTimeout(400);
    const conv = ev.filter((e) => e.k === 'gtag' && e.ev === 'conversion');
    const lead = ev.filter((e) => e.k === 'fbq' && e.a[1] === 'Lead');
    const c = conv[0];
    const gap = c && navs[0] ? navs[0] - c.t : null;
    console.log(`${sc.name} | conversions=${conv.length} (on ${conv.map((x) => x.path)}) fbqLead=${lead.length} | redirects=${navs.length} | conv->redirect=${gap}ms | beacon=${c && c.transport_type} timeout=${c && c.event_timeout} cb=${c && c.cb} | url=${new URL(page.url()).pathname} | 3p-aborted=${thirdParty}`);
    await ctx.close();
  }
  await browser.close();
})().catch((e) => { console.error('FAIL', e); process.exit(1); });
