import { createFileRoute } from "@tanstack/react-router";
import { HomePage } from "@/components/site/HomePage";

const title = "USA Career Consultancy & Placement Support | Syntrix Global";
const description =
  "Career consulting for grads and professionals in the USA — resume & LinkedIn, interviews, recruiter outreach, OPT/STEM OPT guidance and placement assistance. No employment guarantee.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://careers.syntrixglobal.in/" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/careers-syntrixglobal-og-image.png" },
      { name: "twitter:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/careers-syntrixglobal-og-image.png" },
    ],
    links: [{ rel: "canonical", href: "https://careers.syntrixglobal.in/" }],
  }),
  component: () => <HomePage />,
});
