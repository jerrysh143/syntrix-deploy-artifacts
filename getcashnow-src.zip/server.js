'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const { bootstrapAdmin } = require('./lib/admin-bootstrap');
const { loadComplianceConfig, renderSlots, publicSiteInfo } = require('./lib/site-info');
const leadsRouter = require('./routes/leads');
const adminRouter = require('./routes/admin');

/**
 * Third-party hosts allowed by the Content Security Policy.
 * To allow a new Google Ads / Meta domain, add it to the right array here — nothing else to edit.
 * ('self', data: and the inline-script hashes are added automatically below.)
 */
const CSP_ALLOW = {
  script: [
    'https://www.googletagmanager.com',
    'https://www.googleadservices.com',
    'https://www.google.com',
    'https://connect.facebook.net',
    'https://www.facebook.com',
  ],
  connect: [
    'https://www.google-analytics.com',
    'https://www.google.com',
    'https://www.googleadservices.com',
    'https://www.googletagmanager.com',
    'https://googleads.g.doubleclick.net',
    'https://ad.doubleclick.net',
    'https://pagead2.googlesyndication.com',
    'https://www.facebook.com',
    'https://connect.facebook.net',
  ],
  img: [
    'https://www.google-analytics.com',
    'https://www.googletagmanager.com',
    'https://www.googleadservices.com',
    'https://googleads.g.doubleclick.net',
    'https://pagead2.googlesyndication.com',
    'https://www.google.com',
    'https://www.facebook.com',
    'https://connect.facebook.net',
  ],
  frame: ['https://www.googletagmanager.com', 'https://www.facebook.com', 'https://www.youtube.com'],
};

const PORT = Number(process.env.PORT) || 3000;
const NODE_ENV = process.env.NODE_ENV || 'development';
const isProd = NODE_ENV === 'production';

if (!process.env.SESSION_SECRET || String(process.env.SESSION_SECRET).length < 16) {
  console.error('SESSION_SECRET env var is required (min 16 characters)');
  process.exit(1);
}

bootstrapAdmin();

const publicDir = path.join(__dirname, 'public');
// Page templates live outside public/ so the host's static file server can never serve them raw.
const viewsDir = path.join(__dirname, 'views');

/* ---------- Ads config (public pixel IDs from env; empty by default) ---------- */
function adsConfig() {
  const googleTagId = String(process.env.GOOGLE_TAG_ID || process.env.GOOGLE_ADS_ID || '').trim();
  let googleAdsSendTo = String(process.env.GOOGLE_ADS_CONVERSION_SEND_TO || '').trim();
  if (!googleAdsSendTo) {
    const cid = String(process.env.GOOGLE_ADS_CONVERSION_ID || '').trim();
    const label = String(process.env.GOOGLE_ADS_CONVERSION_LABEL || '').trim();
    if (cid && label) googleAdsSendTo = `${cid}/${label}`;
  }
  const metaPixelId = String(process.env.META_PIXEL_ID || '').trim();
  // Public IDs only, in their expected shapes; anything else is dropped (never injected).
  const ok = (v, re) => (re.test(v) ? v : '');
  return {
    googleTagId: ok(googleTagId, /^(AW|G|GT|DC)-[A-Za-z0-9]{4,20}$/),
    googleAdsSendTo: ok(googleAdsSendTo, /^AW-[0-9]{4,20}\/[A-Za-z0-9_-]{1,64}$/),
    metaPixelId: ok(metaPixelId, /^[0-9]{5,20}$/),
  };
}

/* ---------- Page rendering (once at boot) ----------
 * - compliance slots filled or removed (config/compliance.json)
 * - /js/ads.js + /js/main.js inlined so pages work even if the CDN challenges
 *   static asset requests; CSP allows them via sha256 hashes (no unsafe-inline).
 */
const compliance = loadComplianceConfig();
const ADS = adsConfig();
const inlineHashes = new Set();

function inlineScript(code) {
  inlineHashes.add(`'sha256-${crypto.createHash('sha256').update(code, 'utf8').digest('base64')}'`);
  return `<script>${code}</script>`;
}

const adsInline =
  'window.__GCN_ADS__=' + JSON.stringify(ADS).replace(/</g, '\\u003c') + ';\n' +
  fs.readFileSync(path.join(publicDir, 'js', 'ads.js'), 'utf8');
const mainInline = fs.readFileSync(path.join(publicDir, 'js', 'main.js'), 'utf8');
const ADS_TAG = inlineScript(adsInline);
// Meta <noscript> fallback: PageView only, pixel ID only (no user data); Referrer-Policy is no-referrer.
const META_NOSCRIPT = ADS.metaPixelId
  ? `<noscript><img height="1" width="1" style="display:none" alt="" src="https://www.facebook.com/tr?id=${ADS.metaPixelId}&amp;ev=PageView&amp;noscript=1" /></noscript>`
  : '';
const MAIN_TAG = inlineScript(mainInline);
// Calculator: limits from config/compliance.json (public figures only), inlined like main.js.
const siteLimits = {
  maxApr: compliance.maxApr,
  minApr: compliance.minApr,
  minRepaymentDays: compliance.minRepaymentDays,
  maxRepaymentMonths: compliance.maxRepaymentMonths,
};
const CALC_TAG = inlineScript(
  'window.__GCN_SITE__=' + JSON.stringify(siteLimits).replace(/</g, '\\u003c') + ';\n' +
  fs.readFileSync(path.join(publicDir, 'js', 'calculator.js'), 'utf8')
);

const PAGES = {
  '/': 'index.html',
  '/how-it-works': 'how-it-works.html',
  '/offers': 'offers.html',
  '/rates-fees': 'rates-fees.html',
  '/disclosure': 'disclosure.html',
  '/privacy': 'privacy.html',
  '/terms': 'terms.html',
  '/e-consent': 'e-consent.html',
  '/thank-you': 'thank-you.html',
};

function renderPage(file) {
  let html = fs.readFileSync(path.join(viewsDir, file), 'utf8');
  html = renderSlots(html, compliance);
  html = html
    .replace('<script src="/js/ads.js" defer></script>', () => ADS_TAG + META_NOSCRIPT)
    .replace('<script src="/js/main.js" defer></script>', () => MAIN_TAG)
    .replace('<script src="/js/calculator.js" defer></script>', () => CALC_TAG);
  return html;
}

const rendered = {};
for (const file of new Set([...Object.values(PAGES), '404.html'])) rendered[file] = renderPage(file);

/* ---------- App ---------- */
const uniq = (arr) => [...new Set(arr)];

const app = express();
app.set('trust proxy', 1);

app.use(
  helmet({
    contentSecurityPolicy: {
      useDefaults: true,
      directives: {
        'default-src': ["'self'"],
        'script-src': uniq(["'self'", ...inlineHashes, ...CSP_ALLOW.script]),
        'style-src': ["'self'", "'unsafe-inline'"],
        'img-src': uniq(["'self'", 'data:', ...CSP_ALLOW.img]),
        'font-src': ["'self'", 'data:'],
        'connect-src': uniq(["'self'", ...CSP_ALLOW.connect]),
        'frame-src': uniq(["'self'", ...CSP_ALLOW.frame]),
        'frame-ancestors': ["'none'"],
      },
    },
    crossOriginEmbedderPolicy: false,
  })
);

app.use(express.json({ limit: '64kb' }));
app.use(express.urlencoded({ extended: false, limit: '64kb' }));
app.use(cookieParser());

app.use(
  session({
    name: 'gcn.sid',
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: isProd,
      sameSite: 'lax',
      maxAge: 8 * 60 * 60 * 1000,
    },
  })
);

app.get('/api/ads-config', (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json(ADS);
});

app.get('/api/site-info', (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json(publicSiteInfo(compliance));
});

app.use('/api', leadsRouter);
app.use('/api/admin', adminRouter);

// Old *.html URLs: send public pages to their clean URL.
app.use((req, res, next) => {
  if (!req.path.endsWith('.html') || req.path === '/admin.html') return next();
  const clean = Object.keys(PAGES).find((k) => PAGES[k] === req.path.slice(1));
  if (clean) return res.redirect(301, clean);
  return res.status(404).type('html').send(rendered['404.html']);
});

app.use(express.static(publicDir, { index: false, maxAge: isProd ? '1h' : 0 }));

function sendRendered(res, file, status = 200) {
  res.status(status).type('html');
  res.set('Cache-Control', 'no-cache');
  res.send(rendered[file]);
}

for (const [route, file] of Object.entries(PAGES)) {
  app.get(route, (req, res) => sendRendered(res, file));
}
app.get('/disclaimer', (req, res) => res.redirect(301, '/disclosure'));
app.get('/admin', (req, res) => res.sendFile(path.join(publicDir, 'admin.html')));
app.get('/admin/', (req, res) => res.redirect(301, '/admin'));

app.get('/robots.txt', (req, res) => {
  res.type('text/plain').send(
    [
      'User-agent: *',
      'Allow: /',
      'Disallow: /admin',
      'Disallow: /api/',
      'Sitemap: https://getcashnow.cc/sitemap.xml',
      '',
    ].join('\n')
  );
});

app.get('/sitemap.xml', (req, res) => {
  const urls = Object.keys(PAGES);
  const body = urls
    .map((u) => `  <url>\n    <loc>https://getcashnow.cc${u}</loc>\n    <changefreq>weekly</changefreq>\n  </url>`)
    .join('\n');
  res.type('application/xml').send(
    `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${body}\n</urlset>\n`
  );
});

app.use((req, res) => {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ ok: false, error: 'Not found' });
  }
  sendRendered(res, '404.html', 404);
});

app.use((err, req, res, next) => {
  console.error(err);
  if (req.path.startsWith('/api/')) {
    return res.status(500).json({ ok: false, error: 'Server error' });
  }
  res.status(500).send('Something went wrong');
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Get Cash Now listening on 0.0.0.0:${PORT} (${NODE_ENV})`);
});
