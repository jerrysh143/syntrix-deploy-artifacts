import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { CtaLink, Section, SectionHeading } from "@/components/site/primitives";
import { FeaturedProject } from "@/components/site/FeaturedProject";
import { work } from "@/lib/site-content";

const title = "Projects & Capabilities | Syntrix Global";
const description =
  "Staffing and consulting capabilities plus selected technology projects from Syntrix Global.";


export const Route = createFileRoute("/work")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://syntrixglobal.in/work" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/syntrixglobal-og-image.png" },
      { name: "twitter:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/syntrixglobal-og-image.png" },
    ],
    links: [{ rel: "canonical", href: "https://syntrixglobal.in/work" }],
  }),
  component: WorkPage,
});

function WorkPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />

      <Section>
        <SectionHeading as="h1" eyebrow="Projects" title="Engagements & Capabilities" intro="Staffing and consulting engagements lead. Technology projects are supporting showcases when build work is part of an engagement." />
        <div className="mt-12">
          <p className="mb-4 label-xs text-muted-foreground">Supporting technology showcase (secondary)</p>
          <FeaturedProject />
        </div>
        <h2 className="mt-12 font-display text-3xl uppercase">Engagement & Solution Areas</h2>
        <p className="mt-3 text-sm text-muted-foreground">Discuss staffing, consulting or technology requirements in these areas.</p>
        <div className="mt-8 grid gap-6 sm:grid-cols-2">
          {work.map(project => <article key={project.title} className="border border-border p-8">
            <h3 className="font-display text-2xl uppercase">{project.title}</h3>
            <p className="mt-4 text-sm text-muted-foreground">{project.desc}</p>
            <div className="mt-6"><CtaLink to="/start-project" variant="outline">Discuss this requirement</CtaLink></div>
          </article>)}
        </div>
        <div className="mt-12">
          <CtaLink to="/start-project">Request Staffing Support</CtaLink>
        </div>
      </Section>

      <SiteFooter />
    </div>
  );
}
