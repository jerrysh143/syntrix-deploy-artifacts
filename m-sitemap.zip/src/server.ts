import { faviconResponse } from "./lib/favicon";
import { handleSubmission } from "./lib/submissions.server";
import "./lib/error-capture";

import { consumeLastCapturedError } from "./lib/error-capture";
import { renderErrorPage } from "./lib/error-page";
import { OG_IMAGE_PNG_BASE64 } from "./lib/og-image-data";
import { sitemapResponse } from "./lib/sitemap";

type ServerEntry = {
  fetch: (request: Request, env: unknown, ctx: unknown) => Promise<Response> | Response;
};

let serverEntryPromise: Promise<ServerEntry> | undefined;

async function getServerEntry(): Promise<ServerEntry> {
  if (!serverEntryPromise) {
    serverEntryPromise = import("@tanstack/react-start/server-entry").then(
      (m) => (m.default ?? m) as ServerEntry,
    );
  }
  return serverEntryPromise;
}

// h3 swallows in-handler throws into a normal 500 Response with body
// {"unhandled":true,"message":"HTTPError"} — try/catch alone never fires for those.
async function normalizeCatastrophicSsrResponse(response: Response): Promise<Response> {
  if (response.status < 500) return response;
  const contentType = response.headers.get("content-type") ?? "";
  if (!contentType.includes("application/json")) return response;

  const body = await response.clone().text();
  if (!isH3SwallowedErrorBody(body)) return response;

  console.error(consumeLastCapturedError() ?? new Error(`h3 swallowed SSR error: ${body}`));
  return new Response(renderErrorPage(), {
    status: 500,
    headers: { "content-type": "text/html; charset=utf-8" },
  });
}

function isH3SwallowedErrorBody(body: string): boolean {
  try {
    const payload = JSON.parse(body) as { unhandled?: unknown; message?: unknown };
    return payload.unhandled === true && payload.message === "HTTPError";
  } catch {
    return false;
  }
}


/** Retire Ahmedabad service-city + India–USA staffing pages (301). */
function legacyGeoRedirect(request: Request): Response | null {
  const url = new URL(request.url);
  const path = url.pathname.replace(/\/+$/, "") || "/";
  if (path === "/locations/ahmedabad") {
    url.pathname = "/services";
    return Response.redirect(url.toString(), 301);
  }
  if (path === "/services/india-usa-staffing") {
    url.pathname = "/staffing";
    return Response.redirect(url.toString(), 301);
  }
  return null;
}

/** App-level www→apex: strip leading www. and keep path/query. */
function wwwRedirect(request: Request): Response | null {
  const url = new URL(request.url);
  const host = (request.headers.get("host") ?? url.host).split(":")[0].toLowerCase();
  if (!host.startsWith("www.")) return null;
  url.protocol = "https:";
  url.host = host.slice(4);
  return Response.redirect(url.toString(), 301);
}

/** Serve OG image from inlined bytes — never via Nitro publicAssets (Passenger 500). */
function ogImageResponse(): Response {
  const body = Buffer.from(OG_IMAGE_PNG_BASE64, "base64");
  return new Response(body, {
    status: 200,
    headers: {
      "content-type": "image/png",
      "cache-control": "public, max-age=86400",
      "content-length": String(body.byteLength),
    },
  });
}

function isSitemapPath(pathname: string): boolean {
  return (
    pathname === "/sitemap" ||
    pathname === "/sitemap.xml" ||
    pathname === "/api/sitemap" ||
    pathname === "/api/sitemap.xml"
  );
}

export default {
  async fetch(request: Request, env: unknown, ctx: unknown) {
    const redirected = wwwRedirect(request);
    if (redirected) return redirected;

    const geoRedirected = legacyGeoRedirect(request);
    if (geoRedirected) return geoRedirected;

    const pathname = new URL(request.url).pathname;
    // Serve sitemap + og-image from memory — never via Nitro publicAssets readFile.
    // Hostinger Passenger was 500ing on static assets while HTML worked because Nitro
    // claimed the public asset before this SSR short-circuit.
    if (pathname === "/syntrix-icon.png") return faviconResponse();
    if (pathname === "/og-image.png") return ogImageResponse();
    if (isSitemapPath(pathname)) return sitemapResponse();
    if (pathname === "/api/submissions") return handleSubmission(request);
    try {
      const handler = await getServerEntry();
      const response = await handler.fetch(request, env, ctx);
      return await normalizeCatastrophicSsrResponse(response);
    } catch (error) {
      console.error(error);
      return new Response(renderErrorPage(), {
        status: 500,
        headers: { "content-type": "text/html; charset=utf-8" },
      });
    }
  },
};
