/**
 * Get Cash Now: Google tag / Google Ads + Meta Pixel (env-gated).
 *
 * Env (public pixel IDs only; never invent live IDs):
 *   GOOGLE_TAG_ID=                  # AW-XXXXXXXXX or G-XXXXXXXX (alias: GOOGLE_ADS_ID)
 *   GOOGLE_ADS_CONVERSION_SEND_TO=  # AW-XXXXXXXXX/label (or GOOGLE_ADS_CONVERSION_ID + _LABEL)
 *   META_PIXEL_ID=
 *
 * Behaviour:
 *   - IDs empty: no third-party scripts, no network calls; trackLead() is a no-op.
 *   - IDs set: gtag config / Meta PageView on every public page.
 *   - Conversion + Meta Lead fire ONLY from trackLead(), which main.js calls after
 *     POST /api/leads returns ok and before the redirect. No page-load conversions.
 *
 * Config comes from window.__GCN_ADS__ (inlined by the server) or GET /api/ads-config.
 */
(function () {
  'use strict';

  var config = { googleTagId: '', googleAdsSendTo: '', metaPixelId: '' };

  function loadExternalScript(src) {
    return new Promise(function (resolve) {
      var s = document.createElement('script');
      s.async = true;
      s.src = src;
      s.onload = resolve;
      s.onerror = resolve; // blocked/offline: stay silent
      document.head.appendChild(s);
    });
  }

  function initGtag(id) {
    window.dataLayer = window.dataLayer || [];
    window.gtag = function () {
      window.dataLayer.push(arguments);
    };
    window.gtag('js', new Date());
    window.gtag('config', id);
    loadExternalScript('https://www.googletagmanager.com/gtag/js?id=' + encodeURIComponent(id));
  }

  function initMeta(id) {
    if (!window.fbq) {
      var n = (window.fbq = function () {
        n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments);
      });
      if (!window._fbq) window._fbq = n;
      n.push = n;
      n.loaded = true;
      n.version = '2.0';
      n.queue = [];
      loadExternalScript('https://connect.facebook.net/en_US/fbevents.js');
    }
    // No automatic event/metadata collection; only PageView and explicit Lead.
    window.fbq('set', 'autoConfig', false, id);
    window.fbq('init', id);
    window.fbq('track', 'PageView');
  }

  function applyConfig(data) {
    config = {
      googleTagId: (data && data.googleTagId) || '',
      googleAdsSendTo: (data && data.googleAdsSendTo) || '',
      metaPixelId: (data && data.metaPixelId) || '',
    };
    if (config.googleTagId) initGtag(config.googleTagId);
    if (config.metaPixelId) initMeta(config.metaPixelId);
  }

  var ready;
  if (window.__GCN_ADS__ && typeof window.__GCN_ADS__ === 'object') {
    applyConfig(window.__GCN_ADS__);
    ready = Promise.resolve();
  } else {
    ready = fetch('/api/ads-config', { credentials: 'same-origin' })
      .then(function (res) { return res.ok ? res.json() : {}; })
      .then(applyConfig)
      .catch(function () { /* stay no-op */ });
  }

  window.GcnAds = {
    /**
     * Call ONLY after a successful lead submission. Fires the Google Ads conversion
     * and Meta Lead when configured; otherwise resolves immediately (no-op).
     */
    trackLead: function () {
      return ready.then(function () {
        var fired = false;
        if (config.googleTagId && config.googleAdsSendTo && typeof window.gtag === 'function') {
          window.gtag('event', 'conversion', { send_to: config.googleAdsSendTo });
          fired = true;
        }
        if (config.metaPixelId && typeof window.fbq === 'function') {
          window.fbq('track', 'Lead');
          fired = true;
        }
        if (!fired) return;
        // Short window for beacons to leave before navigation.
        return new Promise(function (r) { setTimeout(r, 400); });
      });
    },
  };
})();
