import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { CtaLink, Eyebrow, Section, SectionHeading } from "@/components/site/primitives";
import { brand, itIndustries } from "@/lib/site-content";
import techTeam from "@/assets/tech-team-branded.jpg";

const title = "About Syntrix Global — Consultancy & Staffing Firm";
const description =
  "Syntrix Global is a consultancy and staffing firm serving USA employers — recruitment, placement and talent consulting from San Antonio, with technology services as a supporting offering.";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://syntrixglobal.in/about" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/syntrixglobal-og-image.png" },
      { name: "twitter:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/syntrixglobal-og-image.png" },
    ],
    links: [{ rel: "canonical", href: "https://syntrixglobal.in/about" }],
  }),
  component: AboutPage,
});

const values = [
  { no: "01", title: "Clarity", desc: "Plain language, written scope, no surprises mid-engagement." },
  { no: "02", title: "Process", desc: "Structured sourcing and consulting — not invented metrics." },
  { no: "03", title: "Accountability", desc: "Named owners, visible milestones, honest status." },
  { no: "04", title: "Partnership", desc: "Employer-first staffing and consulting with long-term relationships." },
];

function AboutPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />

      <Section>
        <SectionHeading as="h1"
          eyebrow="About"
          title={
            <>
              Consultancy
              <br />
              &amp; Staffing.
            </>
          }
          intro="Syntrix Global helps USA employers hire talent and plan workforce needs — San Antonio is our primary geo. Our India office remains company contact NAP only. Software, AI and cloud remain available as supporting services."
        />
        <div className="mt-14 grid gap-10 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
          <img
            src={techTeam}
            alt="Illustrative professional collaboration scene"
            loading="lazy"
            className="w-full border border-border object-cover"
          />
          <div className="grid content-start gap-6">
            <p className="text-base leading-relaxed text-muted-foreground">
              We are a consultancy and staffing firm. Our primary work is recruitment support,
              placement and talent consulting for employers who need clear process — not inflated
              claims.
            </p>
            <p className="text-base leading-relaxed text-muted-foreground">
              When an engagement also needs product or systems work, our technology team can support
              software, AI and cloud delivery. Candidates seeking USA career support should use{" "}
              <a href={brand.careersUrl} className="underline" rel="noopener noreferrer">
                careers.syntrixglobal.in
              </a>
              .
            </p>
            <div className="flex flex-wrap gap-3">
              <CtaLink to="/start-project">Request Staffing Support</CtaLink>
              <CtaLink to="/contact" variant="outline">
                Talk to a Consultant
              </CtaLink>
            </div>
          </div>
        </div>
      </Section>

      <Section>
        <SectionHeading eyebrow="What we value" title="Principles" />
        <div className="mt-12 grid gap-px border border-border bg-border sm:grid-cols-2 lg:grid-cols-4">
          {values.map((v) => (
            <div key={v.no} className="bg-background p-8">
              <Eyebrow>{v.no}</Eyebrow>
              <h3 className="mt-4 font-display text-2xl uppercase">{v.title}</h3>
              <p className="mt-3 text-sm text-muted-foreground">{v.desc}</p>
            </div>
          ))}
        </div>
      </Section>

      <Section>
        <SectionHeading eyebrow="Coverage" title="Industry Applications" />
        <ul className="mt-12 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {itIndustries.map((i) => (
            <li key={i} className="border-b border-border py-2 text-sm">
              {i}
            </li>
          ))}
        </ul>
      </Section>

      <SiteFooter />
    </div>
  );
}
