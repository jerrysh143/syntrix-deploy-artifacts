import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/site/LegalPage";
import { disclaimer } from "@/lib/site-content";

const title = "Disclaimer — Syntrix Global";
const description =
  "Important information about employment outcomes, career consultancy services and website content accuracy.";

export const Route = createFileRoute("/disclaimer")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://careers.syntrixglobal.in/disclaimer" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/careers-syntrixglobal-og-image.png" },
      { name: "twitter:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/careers-syntrixglobal-og-image.png" },
    ],
    links: [{ rel: "canonical", href: "https://careers.syntrixglobal.in/disclaimer" }],
  }),
  component: () => (
    <LegalPage
      eyebrow="Legal"
      title="Disclaimer"
      intro="Please read the following before relying on any information or service outcome described on this site."
      sections={[
        {
          heading: "Employment Outcomes",
          body: [disclaimer],
        },
        {
          heading: "Hiring Decisions",
          body: [
            "We provide career consulting, preparation and placement assistance. We are not the employer and do not make hiring decisions.",
          ],
        },
        {
          heading: "Website Content",
          body: [
            "Content on this site is provided for general information. While we work to keep it accurate and current, we make no warranty of completeness for any particular purpose.",
          ],
        },
        {
          heading: "Service Scope",
          body: [
            "The support provided, service fees and any schedule are defined in the applicable service agreement after discussing your requirements.",
          ],
        },
      ]}
    />
  ),
});
