import { SiteHeader } from "./SiteHeader";
import { SiteFooter } from "./SiteFooter";
import { Section, SectionHeading } from "./primitives";

export type LegalSection = { heading: string; body: string[] };

export function LegalPage({
  eyebrow,
  title,
  intro,
  sections,
}: {
  eyebrow: string;
  title: string;
  intro: string;
  sections: LegalSection[];
}) {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />

      <Section>
        <SectionHeading as="h1" eyebrow={eyebrow} title={title} intro={intro} />
        <div className="mt-14 grid max-w-3xl gap-10">
          {sections.map((s) => (
            <section key={s.heading}>
              <h2 className="font-display text-2xl uppercase">{s.heading}</h2>
              {s.body.map((p, i) => (
                <p key={i} className="mt-3 text-sm leading-relaxed text-muted-foreground">
                  {p}
                </p>
              ))}
            </section>
          ))}
        </div>
      </Section>

      <SiteFooter />
    </div>
  );
}
