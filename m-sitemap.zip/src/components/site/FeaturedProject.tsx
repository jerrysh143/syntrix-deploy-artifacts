import { Eyebrow } from "./primitives";

export function FeaturedProject() {
  return (
    <article id="yomora" className="grid gap-8 border border-border p-6 sm:p-10 lg:grid-cols-[1fr_1.4fr]">
      <div className="flex min-h-56 flex-col justify-between bg-ink p-8 text-ivory">
        <Eyebrow>Supporting showcase · E-commerce</Eyebrow>
        <h2 className="font-display text-5xl tracking-wide">YOMORA</h2>
        <p className="text-sm">Silver jewellery · Online storefront</p>
      </div>
      <div>
        <h3 className="font-display text-3xl uppercase">A digital storefront for silver jewellery.</h3>
        <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
          YOMORA is the silver jewellery brand of Nehalbhai Devika Jewellers. Its online store
          brings jewellery collections, product information and shopping tools together in one place.
        </p>
        <ul className="mt-6 grid gap-3 text-sm sm:grid-cols-2">
          <li>Category-based jewellery browsing</li>
          <li>Product images, descriptions and INR pricing</li>
          <li>Customer accounts, wishlist and cart</li>
          <li>Black Signature membership information</li>
          <li>Custom-jewellery enquiries</li>
          <li>Order tracking and customer-help pages</li>
        </ul>
        <a href="https://yomora.in/" target="_blank" rel="noopener noreferrer" className="mt-8 inline-flex border border-border px-6 py-4 label-xs hover:bg-foreground hover:text-background">
          Visit YOMORA ↗<span className="sr-only"> (opens in a new tab)</span>
        </a>
      </div>
    </article>
  );
}
