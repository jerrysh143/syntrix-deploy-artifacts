import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/site/LegalPage";

const title = "Terms of Service — Syntrix Global";
const description =
  "The terms that apply to use of the Syntrix Global website and technology services.";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://syntrixglobal.in/terms" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/syntrixglobal-og-image.png" },
      { name: "twitter:image", content: "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/syntrixglobal-og-image.png" },
    ],
    links: [{ rel: "canonical", href: "https://syntrixglobal.in/terms" }],
  }),
  component: () => (
    <LegalPage
      eyebrow="Legal"
      title="Terms of Service"
      intro="By using this website or engaging our services you agree to the terms set out below."
      sections={[
        {
          heading: "Use of the Site",
          body: [
            "You agree to use this website lawfully and not to attempt to disrupt, reverse engineer or gain unauthorised access to any part of it.",
          ],
        },
        {
          heading: "Services & Engagements",
          body: [
            "Technology projects are governed by a separate written proposal or statement of work covering scope, deliverables, timeline and fees.",
          ],
        },
        {
          heading: "Fees & Payment",
          body: [
            "Fees, milestones and payment terms are defined per engagement. Unless stated otherwise, invoices are payable within the period specified on the invoice.",
          ],
        },
        {
          heading: "Intellectual Property",
          body: [
            "Site content, branding and materials remain the property of Syntrix Global. Ownership of project deliverables transfers as defined in the applicable agreement, typically on full payment.",
          ],
        },
        {
          heading: "Limitation of Liability",
          body: [
            "To the extent permitted by law, our liability arising from an engagement is limited to the fees paid for that engagement. We are not liable for indirect or consequential loss.",
          ],
        },
      ]}
    />
  ),
});
