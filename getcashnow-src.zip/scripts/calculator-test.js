// Local-only headless check of the homepage loan calculator (values, clamping, keyboard, CTA, no tracking) + screenshots.
// Needs a local server on :3998 and playwright-core + Chrome; writes to /workspace/gcn-calc/.
const { chromium } = require('/workspace/syntrix-shot-run/node_modules/playwright-core');
(async () => {
  const b = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const ctx = await b.newContext({ viewport: { width: 1280, height: 900 } });
  await ctx.route(/googletagmanager|facebook|google-analytics|doubleclick|googleadservices|google\.com|googlesyndication/, (r) => r.abort());
  await ctx.addInitScript(() => {
    window.__ev = [];
    let real; Object.defineProperty(window, 'fbq', { configurable: true, get: () => real, set: (f) => {
      real = function () { window.__ev.push(['fbq', ...[].slice.call(arguments, 0, 2)]); return f.apply(this, arguments); }; Object.assign(real, f); real.queue = f.queue; real.push = real; } });
    let dl; Object.defineProperty(window, 'dataLayer', { configurable: true, get: () => dl, set: (v) => { dl = v; const p = v.push.bind(v);
      v.push = (a) => { if (a && a[0] === 'event') window.__ev.push(['gtag', a[1]]); return p(a); }; } });
  });
  const page = await ctx.newPage(); const errs = []; const sameOrigin = [];
  page.on('console', (m) => { if (m.type() === 'error' && !/ERR_FAILED|net::/.test(m.text())) errs.push(m.text()); });
  page.on('pageerror', (e) => errs.push('pageerror ' + e.message));
  page.on('request', (r) => { const u = new URL(r.url()); if (u.host.startsWith('localhost') && /\/js\/|site-info/.test(u.pathname)) sameOrigin.push(u.pathname); });
  await page.goto('http://localhost:3998/'); await page.waitForTimeout(300);
  const res = async () => page.evaluate(() => ({ m: calcMonthly.textContent, t: calcTotal.textContent, i: calcInterest.textContent,
    amt: calcAmount.value, term: calcTerm.value, apr: calcApr.value, ar: calcAmountRange.value, tr: calcTermRange.value, pr: calcAprRange.value }));
  console.log('defaults         ', JSON.stringify(await res()));
  console.log('limits           ', JSON.stringify(await page.evaluate(() => window.GcnCalc.limits())), '| site cfg', JSON.stringify(await page.evaluate(() => window.__GCN_SITE__)));
  const setField = async (id, val) => { await page.fill('#' + id, String(val)); await page.press('#' + id, 'Tab'); await page.waitForTimeout(50); };
  for (const [id, val, label] of [['calcAmount', '35000', 'amount 35000'], ['calcAmount', '100', 'amount 100->clamp'], ['calcAmount', '99,999', 'amount 99999->clamp'], ['calcAmount', '12,345', 'amount 12345->snap 100'],
    ['calcTerm', '1', 'term 1->clamp'], ['calcTerm', '100', 'term 100->clamp'], ['calcApr', '50', 'apr 50->clamp'], ['calcApr', '1', 'apr 1->clamp'], ['calcApr', '', 'apr empty->default'], ['calcTerm', '2', 'term 2 (min)']]) {
    await setField(id, val); console.log(label.padEnd(17), JSON.stringify(await res()));
  }
  // keyboard on slider
  await setField('calcAmount', '5000'); await setField('calcTerm', '36'); await setField('calcApr', '20');
  await page.focus('#calcAmountRange'); for (let k = 0; k < 5; k++) await page.keyboard.press('ArrowRight');
  console.log('slider +5 steps  ', JSON.stringify(await res()), '| valuetext', await page.getAttribute('#calcAmountRange', 'aria-valuetext'));
  await page.keyboard.press('End'); console.log('slider End       ', JSON.stringify(await res()));
  await page.keyboard.press('Home'); console.log('slider Home      ', JSON.stringify(await res()));
  await setField('calcAmount', '5000'); await page.waitForTimeout(700);
  console.log('aria-live text   ', await page.textContent('#calcLive'));
  console.log('note             ', await page.textContent('#calcNote'));
  console.log('term hint        ', await page.textContent('#calcTermHint'));
  // screenshots
  await page.evaluate(() => document.activeElement.blur()); await page.mouse.move(0, 0); await page.locator('#calculator').screenshot({ path: '/workspace/gcn-calc/calculator-desktop.png' });
  const ev0 = await page.evaluate(() => window.__ev.slice());
  await page.click('#calcCta'); await page.waitForTimeout(900);
  const after = await page.evaluate(() => ({ active: document.activeElement && document.activeElement.id, applyTop: Math.round(document.getElementById('apply').getBoundingClientRect().top), hash: location.hash, url: location.pathname, ev: window.__ev.slice() }));
  console.log('CTA              ', JSON.stringify({ active: after.active, applyTop: after.applyTop, hash: after.hash, url: after.url }));
  console.log('tracking events: before CTA', JSON.stringify(ev0), '| after CTA', JSON.stringify(after.ev));
  const m = await b.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  await m.route(/googletagmanager|facebook|google|doubleclick/, (r) => r.abort());
  const mp = await m.newPage(); mp.on('pageerror', (e) => errs.push('mobile pageerror ' + e.message));
  await mp.goto('http://localhost:3998/'); await mp.waitForTimeout(300);
  await mp.locator('#calculator').screenshot({ path: '/workspace/gcn-calc/calculator-mobile.png' });
  const ov = await mp.evaluate(() => document.documentElement.scrollWidth > window.innerWidth);
  console.log('mobile horizontal overflow:', ov);
  const hdr = await b.newPage({ viewport: { width: 1280, height: 120 } }); await hdr.route(/google|facebook/, (r) => r.abort());
  await hdr.goto('http://localhost:3998/'); await hdr.screenshot({ path: '/workspace/gcn-calc/header-desktop.png', clip: { x: 0, y: 0, width: 1280, height: 72 } });
  console.log('same-origin /js or site-info requests:', sameOrigin.length ? sameOrigin : 'none');
  console.log('console errors:', errs.length ? errs : 'none');
  await b.close();
})().catch((e) => { console.error('FAIL', e); process.exit(1); });
