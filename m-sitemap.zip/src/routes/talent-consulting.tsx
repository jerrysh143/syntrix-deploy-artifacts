import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { FaqSection } from "@/components/site/FaqSection";
import { CtaLink, Eyebrow, Section, SectionHeading } from "@/components/site/primitives";
import { brand, talentConsultingFaqs } from "@/lib/site-content";
import { faqPageJsonLd, professionalServiceJsonLd } from "@/lib/seo-schema";

const title = "Talent Consulting & Workforce Planning (USA) | Syntrix Global";
const description =
  "Employer talent consulting in the United States — role definition, hiring strategy and workforce planning.";
const pageUrl = "https://syntrixglobal.in/talent-consulting";
const ogImage =
  "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/syntrixglobal-og-image.png";

const focusAreas = [
  {
    title: "Role definition",
    desc: "Clarify skills, seniority and outcomes for the roles you need before sourcing starts — so briefs stay usable for hiring managers and recruiters.",
  },
  {
    title: "Workforce planning",
    desc: "Map near-term hiring needs against capacity, contract vs permanent mix, and constraints you already know — without inventing headcount forecasts.",
  },
  {
    title: "Interview process design",
    desc: "Structure screening stages, ownership and feedback loops so candidates and interviewers know what “good” looks like.",
  },
];

export const Route = createFileRoute("/talent-consulting")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: pageUrl },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: ogImage },
      { name: "twitter:image", content: ogImage },
    ],
    links: [{ rel: "canonical", href: pageUrl }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify(
          professionalServiceJsonLd({
            name: "Syntrix Global — Talent Consulting",
            url: pageUrl,
            description,
          }),
        ),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify(faqPageJsonLd(talentConsultingFaqs)),
      },
    ],
  }),
  component: TalentConsultingPage,
});

function TalentConsultingPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />

      <Section>
        <SectionHeading
          as="h1"
          eyebrow="Talent Consulting · USA"
          title="Talent Consulting for USA Hiring Teams"
          intro="Employer talent consulting in the United States — role definition, hiring strategy and workforce planning. No invented hiring metrics."
        />
        <p className="mt-6 max-w-2xl text-sm text-muted-foreground">
          Primary geo:{" "}
          <a href="/locations/san-antonio" className="underline underline-offset-4 hover:text-foreground">
            San Antonio, TX
          </a>
          . {brand.locationLine}. For placement and sourcing support, see{" "}
          <a href="/staffing" className="underline underline-offset-4 hover:text-foreground">
            IT Staffing
          </a>
          .
        </p>
      </Section>

      <Section>
        <SectionHeading
          eyebrow="Focus"
          title="What consulting covers"
          intro="Practical help for USA hiring teams that need clarity before or alongside staffing — not a replacement for your internal people function."
        />
        <div className="mt-12 grid gap-px border border-border bg-border sm:grid-cols-3">
          {focusAreas.map((item, i) => (
            <article key={item.title} className="bg-background p-8">
              <Eyebrow>{String(i + 1).padStart(2, "0")}</Eyebrow>
              <h3 className="mt-4 font-display text-xl uppercase">{item.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{item.desc}</p>
            </article>
          ))}
        </div>
      </Section>

      <Section>
        <SectionHeading
          eyebrow="Scope"
          title="When tech delivery is secondary"
          intro="If the primary need is people and process, consulting and staffing lead. Software, AI and cloud stay available when an engagement later needs build work — clearly secondary."
        />
        <div className="mt-10 grid gap-6 md:grid-cols-2">
          <article className="border border-border p-8">
            <h3 className="font-display text-xl uppercase">Primary</h3>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              Role definition, workforce planning, interview design and hiring strategy for USA employer teams.
            </p>
          </article>
          <article className="border border-border p-8">
            <h3 className="font-display text-xl uppercase">Secondary</h3>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              Technology services when delivery requires product or systems work — never positioned as the default lead offer on this page.
            </p>
          </article>
        </div>
      </Section>

      <Section dark>
        <SectionHeading
          eyebrow="Next step"
          title="Discuss a consulting engagement"
          intro="Share the hiring challenge and constraints. We reply with next steps after review — no invented SLAs."
        />
        <div className="mt-10 flex flex-wrap gap-3">
          <CtaLink to="/start-project">Start a Project</CtaLink>
          <CtaLink to="/staffing" variant="outline">
            IT Staffing
          </CtaLink>
          <CtaLink to="/locations/san-antonio" variant="outline">
            San Antonio
          </CtaLink>
          <CtaLink to="/services" variant="outline">
            All services
          </CtaLink>
        </div>
      </Section>

      <FaqSection
        faqs={talentConsultingFaqs}
        intro="Honest answers for USA employers evaluating talent consulting with Syntrix Global."
      />

      <SiteFooter />
    </div>
  );
}
