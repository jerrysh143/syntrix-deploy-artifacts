#!/usr/bin/env node
'use strict';
/**
 * Representative example via standard amortization:
 *   M = P * r / (1 - (1 + r)^-n), r = APR/12, n = months
 * monthlyPayment = round2(M); totalRepaid = round2(M * n); totalCost = round2(M * n - P)
 * Usage: node scripts/compute-example.js 5000 36 20 [--write]   (--write updates config/compliance.json)
 */
const fs = require('fs');
const path = require('path');

const round2 = (x) => Math.round((x + Number.EPSILON) * 100) / 100;

function computeExample(amount, termMonths, apr) {
  const P = Number(amount);
  const n = Number(termMonths);
  const r = Number(apr) / 100 / 12;
  const M = r === 0 ? P / n : (P * r) / (1 - Math.pow(1 + r, -n));
  return {
    amount: P,
    termMonths: n,
    apr: Number(apr),
    monthlyPayment: round2(M),
    totalRepaid: round2(M * n),
    totalCost: round2(M * n - P),
  };
}

module.exports = { computeExample };

if (require.main === module) {
  const [a, t, p] = process.argv.slice(2);
  const ex = computeExample(a || 5000, t || 36, p || 20);
  console.log(JSON.stringify(ex, null, 2));
  if (process.argv.includes('--write')) {
    const file = path.join(__dirname, '..', 'config', 'compliance.json');
    const cfg = JSON.parse(fs.readFileSync(file, 'utf8'));
    cfg.representativeExample = ex;
    fs.writeFileSync(file, JSON.stringify(cfg, null, 2) + '\n');
    console.log('written to', file);
  }
}
