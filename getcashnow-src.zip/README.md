# Get Cash Now — Lead Funnel Site

Production Node.js / Express app for **getcashnow.cc**: USA personal loan lead marketplace (not a lender), short apply form, thank-you page, legal/content pages, and a secure admin dashboard.

## Stack

- Express (Node >= 18)
- `express-session` + `bcryptjs` (pure JS) admin auth
- File-based storage in `data/` (`leads.json`, `admin.json`) with atomic writes
- `helmet`, `express-rate-limit`, `uuid`
- Static marketing pages in `public/`

## Pages

| Path | Purpose |
|------|---------|
| `/` | Hero + short form (first, last, ZIP, phone + consents) |
| `/how-it-works` | 3-step process + eligibility |
| `/offers` | Partner / advertiser disclosure framing |
| `/rates-fees` | APR range education (~10%–36% with caveats) |
| `/disclosure` | Referral / advertising disclosure ( `/disclaimer` → 301 here) |
| `/privacy` `/terms` `/e-consent` | Legal + electronic records consent |
| `/thank-you` | Post-submit confirmation |
| `/admin` | Secure lead dashboard |

## Environment variables

| Variable | Required | Description |
|----------|----------|-------------|
| `PORT` | No | Listen port (default `3000`) |
| `SESSION_SECRET` | **Yes** | Long random string for session cookies (min 16 chars) |
| `ADMIN_USER` | No | Admin username on first boot (default `admin`) |
| `ADMIN_PASSWORD` | **Yes** on first boot | Plain password used once to create `data/admin.json` hash |
| `NODE_ENV` | No | Set `production` on Hostinger for secure cookies |

Copy `.env.example` and fill values for local use (do not commit `.env`).

## Local run

```bash
npm install
export SESSION_SECRET='your-long-random-secret'
export ADMIN_PASSWORD='your-strong-password'
# optional: export ADMIN_USER=admin
# optional: export NODE_ENV=development
npm start
```

App listens on `0.0.0.0:$PORT`.

- Public site: http://localhost:3000/
- Admin: http://localhost:3000/admin

On first boot, if `data/admin.json` is missing, the server hashes `ADMIN_PASSWORD` and stores it. Later boots reuse the stored hash (changing the env password alone will not rotate it — update `data/admin.json` or delete it to re-bootstrap).

## Lead form (v1)

- First name, last name, ZIP, phone
- Privacy/Terms/E-Consent acknowledgment + TCPA-style contact consent
- `POST /api/leads` (rate-limited)

## Admin features

- Session login (httpOnly cookie; `secure` when `NODE_ENV=production`)
- Lead list with search + status filter
- Detail drawer: status (`new` / `contacted` / `qualified` / `rejected`) + notes
- CSV export: `/api/admin/export.csv`
- Public form POST rate-limited; `/admin` not listed in robots

## Deploy (Hostinger Node)

1. Upload source (or deploy zip) — **exclude** `node_modules`, `data/*.json`, `.git`
2. Set env: `PORT`, `SESSION_SECRET`, `ADMIN_PASSWORD`, `NODE_ENV=production`, optional `ADMIN_USER`
3. `npm install --omit=dev` then `npm start` (or Hostinger’s Node start command pointing at `server.js`)
4. Ensure the app binds to the platform `PORT` (already handled)

## API (summary)

- `POST /api/leads` — public lead capture
- `POST /api/admin/login` · `POST /api/admin/logout` · `GET /api/admin/me`
- `GET /api/admin/leads` · `GET /api/admin/leads/:id` · `PATCH /api/admin/leads/:id`
- `GET /api/admin/export.csv`

## Legal note

Site copy states clearly that Get Cash Now is **not a lender**, does **not** guarantee approval, and that “as soon as one business day” funding is **conditional** on lender approval.
