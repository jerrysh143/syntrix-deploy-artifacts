import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";

export function ArrowBox({ className = "" }: { className?: string }) {
  return (
    <span
      aria-hidden="true"
      className={`inline-grid size-11 shrink-0 place-items-center bg-ink text-ivory transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-1 ${className}`}
    >
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6">
        <path d="M4 12L12 4M6 4h6v6" />
      </svg>
    </span>
  );
}

export function Eyebrow({ children }: { children: ReactNode }) {
  return <p className="label-xs text-muted-foreground">{children}</p>;
}

export function Section({
  id,
  dark,
  className = "",
  children,
}: {
  id?: string;
  dark?: boolean;
  className?: string;
  children: ReactNode;
}) {
  return (
    <section
      id={id}
      className={`${dark ? "dark bg-background text-foreground" : ""} border-b border-border ${className}`}
    >
      <div className="mx-auto w-full max-w-[1400px] px-5 py-20 sm:px-8 md:py-28">{children}</div>
    </section>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  intro,
  as = "h2",
}: {
  eyebrow?: string;
  title: ReactNode;
  intro?: string;
  /** Page heroes should be h1; nested section titles can pass as="h2". */
  as?: "h1" | "h2";
}) {
  const Heading = as;
  return (
    <div className="grid gap-6 md:grid-cols-[minmax(0,1fr)_minmax(0,26rem)] md:items-end">
      <div>
        {eyebrow ? <Eyebrow>{eyebrow}</Eyebrow> : null}
        <Heading className="display-lg mt-4">{title}</Heading>
      </div>
      {intro ? <p className="text-base leading-relaxed text-muted-foreground">{intro}</p> : null}
    </div>
  );
}

export function CtaLink({
  to,
  children,
  variant = "solid",
}: {
  to: string;
  children: ReactNode;
  variant?: "solid" | "outline";
}) {
  const base =
    "group inline-flex items-center gap-3 px-6 py-4 label-xs transition-colors duration-300";
  const styles =
    variant === "solid"
      ? "bg-ink text-ivory hover:bg-accent hover:text-accent-foreground"
      : "border border-border text-foreground hover:bg-foreground hover:text-background";
  return (
    <Link to={to} className={`${base} ${styles}`}>
      {children}
      <span aria-hidden="true" className="transition-transform duration-300 group-hover:translate-x-1">
        →
      </span>
    </Link>
  );
}

export function Marquee({ items }: { items: string[] }) {
  const row = [...items, ...items];
  return (
    <div className="overflow-hidden border-y border-border py-4" aria-hidden="true">
      <div className="marquee-track gap-10">
        {row.map((item, i) => (
          <span key={i} className="display-lg shrink-0 text-transparent" style={{ WebkitTextStroke: "1px currentColor" }}>
            <span className="text-muted-foreground">{item}</span>
          </span>
        ))}
      </div>
    </div>
  );
}
