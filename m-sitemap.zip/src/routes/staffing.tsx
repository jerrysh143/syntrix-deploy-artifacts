import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { FaqSection } from "@/components/site/FaqSection";
import { CtaLink, Eyebrow, Section, SectionHeading } from "@/components/site/primitives";
import { brand, itIndustries, itProcess, staffingFaqs } from "@/lib/site-content";
import { faqPageJsonLd, professionalServiceJsonLd } from "@/lib/seo-schema";

const title = "IT Staffing & Placement Consultancy (USA) | Syntrix Global";
const description =
  "Contract and permanent IT staffing for employers in the United States — role definition, sourcing, screening and placement support from Syntrix Global.";
const pageUrl = "https://syntrixglobal.in/staffing";
const ogImage =
  "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/syntrixglobal-og-image.png";

const whoWeStaffFor = [
  {
    title: "Hiring managers",
    desc: "Teams that need a clear role brief, a shortlist that matches the brief, and coordination through interviews and offer stages.",
  },
  {
    title: "People & talent leads",
    desc: "HR and talent partners who want process support without inventing headcount metrics or promising outcomes we cannot control.",
  },
  {
    title: "Founders & operators",
    desc: "Growing companies that need contract or permanent IT talent and prefer an honest placement partner over a volume recruiter.",
  },
];

const engagementTypes = [
  {
    title: "Contract",
    desc: "Time-bound roles when you need capacity for a project, surge, or specialist skill without a permanent seat yet.",
  },
  {
    title: "Contract-to-hire",
    desc: "A trial engagement that can convert if the fit works for both sides — still no guaranteed conversion.",
  },
  {
    title: "Permanent",
    desc: "Full-time placement support when the role is lasting and you want sourcing, screening and shortlist coordination.",
  },
];

export const Route = createFileRoute("/staffing")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: pageUrl },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: ogImage },
      { name: "twitter:image", content: ogImage },
    ],
    links: [{ rel: "canonical", href: pageUrl }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify(
          professionalServiceJsonLd({
            name: "Syntrix Global — IT Staffing & Placement",
            url: pageUrl,
            description,
          }),
        ),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify(faqPageJsonLd(staffingFaqs)),
      },
    ],
  }),
  component: StaffingPage,
});

function StaffingPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />

      <Section>
        <SectionHeading
          as="h1"
          eyebrow="IT Staffing · USA"
          title="IT Staffing & Placement for USA Employers"
          intro="Contract and permanent IT staffing for employers in the United States — role definition, sourcing, screening and placement support. We do not invent placement metrics or guarantee hire outcomes."
        />
        <p className="mt-6 max-w-2xl text-sm text-muted-foreground">
          Primary geo:{" "}
          <a href="/locations/san-antonio" className="underline underline-offset-4 hover:text-foreground">
            San Antonio, TX
          </a>
          . {brand.locationLine}.{" "}
          <a
            href={brand.careersUrl}
            className="underline underline-offset-4 hover:text-foreground"
            rel="noopener noreferrer"
          >
            careers.syntrixglobal.in
          </a>{" "}
          is for candidates; this page is for USA employers hiring through Syntrix Global.
        </p>
      </Section>

      <Section>
        <SectionHeading
          eyebrow="Audience"
          title="Who we staff for"
          intro="USA employers only. We support hiring teams that need IT talent — not candidates seeking career coaching on this site."
        />
        <div className="mt-12 grid gap-px border border-border bg-border sm:grid-cols-3">
          {whoWeStaffFor.map((item, i) => (
            <article key={item.title} className="bg-background p-8">
              <Eyebrow>{String(i + 1).padStart(2, "0")}</Eyebrow>
              <h3 className="mt-4 font-display text-xl uppercase">{item.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{item.desc}</p>
            </article>
          ))}
        </div>
      </Section>

      <Section>
        <SectionHeading
          eyebrow="Engagement types"
          title="Contract vs permanent"
          intro="Choose the engagement that matches how long you need the role filled. We align sourcing and screening to that model."
        />
        <div className="mt-12 grid gap-px border border-border bg-border sm:grid-cols-3">
          {engagementTypes.map((item, i) => (
            <article key={item.title} className="bg-background p-8">
              <Eyebrow>{String(i + 1).padStart(2, "0")}</Eyebrow>
              <h3 className="mt-4 font-display text-xl uppercase">{item.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{item.desc}</p>
            </article>
          ))}
        </div>
      </Section>

      <Section>
        <SectionHeading
          eyebrow="Process"
          title="How engagement works"
          intro="The same six-step process we use across staffing engagements — discovery through placement support."
        />
        <ol className="mt-12 grid gap-px border border-border bg-border sm:grid-cols-2 lg:grid-cols-3">
          {itProcess.map((p) => (
            <li key={p.no} className="bg-background p-8">
              <Eyebrow>{p.no}</Eyebrow>
              <p className="mt-4 font-display text-2xl uppercase">{p.title}</p>
            </li>
          ))}
        </ol>
      </Section>

      <Section>
        <SectionHeading
          eyebrow="Industries"
          title="Where we place IT talent"
          intro="Information Technology leads. We also support adjacent USA employers when the roles are technical."
        />
        <ul className="mt-12 grid gap-px border border-border bg-border sm:grid-cols-2 lg:grid-cols-4">
          {itIndustries.map((name) => (
            <li key={name} className="bg-background p-6 font-display text-lg uppercase">
              {name}
            </li>
          ))}
        </ul>
      </Section>

      <Section dark>
        <SectionHeading
          eyebrow="Next step"
          title="Request staffing support"
          intro="Share the roles, engagement type and timeline. We reply with next steps after reviewing your enquiry — no invented SLAs."
        />
        <div className="mt-10 flex flex-wrap gap-3">
          <CtaLink to="/start-project">Start a Project</CtaLink>
          <CtaLink to="/locations/san-antonio" variant="outline">
            San Antonio
          </CtaLink>
          <CtaLink to="/services" variant="outline">
            View all services
          </CtaLink>
          <CtaLink to="/contact" variant="outline">
            Contact
          </CtaLink>
        </div>
      </Section>

      <FaqSection
        faqs={staffingFaqs}
        intro="Honest answers for USA employers evaluating IT staffing with Syntrix Global."
      />

      <SiteFooter />
    </div>
  );
}
