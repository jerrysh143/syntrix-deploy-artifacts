import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { FaqSection } from "@/components/site/FaqSection";
import { CtaLink, Eyebrow, Section, SectionHeading } from "@/components/site/primitives";
import { brand, sanAntonioFaqs } from "@/lib/site-content";
import { faqPageJsonLd, professionalServiceJsonLd } from "@/lib/seo-schema";

const title = "Staffing Consultancy in San Antonio, TX | Syntrix Global";
const description =
  "IT staffing and talent consulting for USA employers from Syntrix Global in San Antonio, TX — contract and permanent placement support without invented guarantees.";
const pageUrl = "https://syntrixglobal.in/locations/san-antonio";
const ogImage =
  "https://raw.githubusercontent.com/jerrysh143/syntrix-deploy-artifacts/main/assets/syntrixglobal-og-image.png";

const usOffice = brand.offices.find((o) => o.label === "United States")!;

export const Route = createFileRoute("/locations/san-antonio")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: pageUrl },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: ogImage },
      { name: "twitter:image", content: ogImage },
    ],
    links: [{ rel: "canonical", href: pageUrl }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify(
          professionalServiceJsonLd({
            name: "Syntrix Global — San Antonio Staffing",
            url: pageUrl,
            description,
          }),
        ),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify(faqPageJsonLd(sanAntonioFaqs)),
      },
    ],
  }),
  component: SanAntonioPage,
});

function SanAntonioPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />

      <Section>
        <SectionHeading
          as="h1"
          eyebrow="San Antonio · USA · Primary geo"
          title="Staffing & Talent Consulting in San Antonio"
          intro="Syntrix Global’s primary USA staffing and talent consulting page — contract and permanent IT placement support for USA employers from our San Antonio presence."
        />
      </Section>

      <Section>
        <SectionHeading
          eyebrow="NAP"
          title="United States office"
          intro="Name, address and contact match our site footer exactly."
        />
        <address className="mt-10 not-italic border border-border p-8">
          <Eyebrow>{usOffice.label}</Eyebrow>
          <p className="mt-4 font-display text-2xl uppercase">{brand.name}</p>
          {usOffice.lines.map((line) => (
            <span key={line} className="mt-2 block text-sm text-muted-foreground">
              {line}
            </span>
          ))}
          <a
            href="mailto:contact@syntrixglobal.in"
            className="mt-4 inline-block text-sm underline underline-offset-4"
          >
            contact@syntrixglobal.in
          </a>
        </address>
      </Section>

      <Section>
        <SectionHeading
          eyebrow="For employers"
          title="USA employer focus"
          intro="Contract and permanent IT staffing plus talent consulting for USA hiring teams. Technology delivery stays secondary when an engagement needs build work. Staffing geography is USA only — Ahmedabad is company contact NAP, not a service city."
        />
        <div className="mt-10 flex flex-wrap gap-3">
          <CtaLink to="/staffing">IT Staffing</CtaLink>
          <CtaLink to="/talent-consulting" variant="outline">
            Talent Consulting
          </CtaLink>
          <CtaLink to="/services" variant="outline">
            View services
          </CtaLink>
          <CtaLink to="/start-project" variant="outline">
            Start a Project
          </CtaLink>
        </div>
      </Section>

      <FaqSection
        faqs={sanAntonioFaqs}
        intro="Local questions for USA employers engaging Syntrix Global in San Antonio."
      />

      <SiteFooter />
    </div>
  );
}
